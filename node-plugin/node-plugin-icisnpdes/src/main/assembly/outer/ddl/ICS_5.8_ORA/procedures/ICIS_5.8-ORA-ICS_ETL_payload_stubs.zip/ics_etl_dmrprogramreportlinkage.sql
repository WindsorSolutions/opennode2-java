﻿
/*************************************************************************************************
** ObjectName: ics_etl_dmrprogramreportlinkage
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the DMRProgramReportLinkageSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_dmrprogramreportlinkage

AS

BEGIN
---------------------------- 
-- ICS_DMR_PROG_REP_LNK
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ics_dmr_prog_rep_lnk;


-- /ICS_DMR_PROG_REP_LNK
INSERT INTO ICS_FLOW_LOCAL.ics_dmr_prog_rep_lnk (
     ics_dmr_prog_rep_lnk_id
   , ics_payload_id
   , src_systm_ident
   , transaction_type
   , transaction_timestamp
   , prmt_ident
   , prmt_featr_ident
   , lmt_set_designator
   , mon_period_end_date
   , key_hash
   , data_hash)
SELECT 
     null /* no mapping */ --ics_dmr_prog_rep_lnk_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --prmt_featr_ident, PermittedFeatureIdentifier
   , null /* no mapping */ --lmt_set_designator, LimitSetDesignator
   , null /* no mapping */ --mon_period_end_date, MonitoringPeriodEndDate
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_DMR_PROG_REP_LNK/ICS_LNK_BS_REP
INSERT INTO ICS_FLOW_LOCAL.ics_lnk_bs_rep (
     ics_lnk_bs_rep_id
   , ics_cmpl_mon_lnk_id
   , ics_dmr_prog_rep_lnk_id
   , prmt_ident
   , rep_coverage_end_date
   , data_hash)
SELECT 
     null /* no mapping */ --ics_lnk_bs_rep_id, 
   , null /* no mapping */ --ics_cmpl_mon_lnk_id, 
   , null /* no mapping */ --ics_dmr_prog_rep_lnk_id, 
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --rep_coverage_end_date, ReportCoverageEndDate
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_DMR_PROG_REP_LNK/ICS_LNK_SW_EVT_REP
INSERT INTO ICS_FLOW_LOCAL.ics_lnk_sw_evt_rep (
     ics_lnk_sw_evt_rep_id
   , ics_cmpl_mon_lnk_id
   , ics_dmr_prog_rep_lnk_id
   , prmt_ident
   , date_strm_evt_smpl
   , sw_evt_id
   , data_hash)
SELECT 
     null /* no mapping */ --ics_lnk_sw_evt_rep_id, 
   , null /* no mapping */ --ics_cmpl_mon_lnk_id, 
   , null /* no mapping */ --ics_dmr_prog_rep_lnk_id, 
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --date_strm_evt_smpl, DateStormEventSampled
   , null /* no mapping */ --sw_evt_id, SWEventID
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

END;
