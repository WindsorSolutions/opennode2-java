﻿
/*************************************************************************************************
** ObjectName: ics_etl_scheduleeventviolation
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the ScheduleEventViolationSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_scheduleeventviolation

AS

BEGIN
---------------------------- 
-- ICS_SCHD_EVT_VIOL
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ics_schd_evt_viol;


-- /ICS_SCHD_EVT_VIOL
INSERT INTO ICS_FLOW_LOCAL.ics_schd_evt_viol (
     ics_schd_evt_viol_id
   , ics_payload_id
   , src_systm_ident
   , transaction_type
   , transaction_timestamp
   , rep_non_cmpl_resl_code
   , rep_non_cmpl_resl_date
   , key_hash
   , data_hash)
SELECT 
     null /* no mapping */ --ics_schd_evt_viol_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --rep_non_cmpl_resl_code, ReportableNonComplianceResolutionCode
   , null /* no mapping */ --rep_non_cmpl_resl_date, ReportableNonComplianceResolutionDate
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SCHD_EVT_VIOL/ICS_CMPL_SCHD_EVT_VIOL_ELEM
INSERT INTO ICS_FLOW_LOCAL.ics_cmpl_schd_evt_viol_elem (
     ics_cmpl_schd_evt_viol_elem_id
   , ics_schd_evt_viol_id
   , enfrc_actn_ident
   , final_order_ident
   , prmt_ident
   , cmpl_schd_num
   , schd_evt_code
   , schd_date
   , schd_viol_code
   , data_hash)
SELECT 
     null /* no mapping */ --ics_cmpl_schd_evt_viol_elem_id, 
   , null /* no mapping */ --ics_schd_evt_viol_id, 
   , null /* no mapping */ --enfrc_actn_ident, EnforcementActionIdentifier
   , null /* no mapping */ --final_order_ident, FinalOrderIdentifier
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --cmpl_schd_num, ComplianceScheduleNumber
   , null /* no mapping */ --schd_evt_code, ScheduleEventCode
   , null /* no mapping */ --schd_date, ScheduleDate
   , null /* no mapping */ --schd_viol_code, ScheduleViolationCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SCHD_EVT_VIOL/ICS_PRMT_SCHD_EVT_VIOL_ELEM
INSERT INTO ICS_FLOW_LOCAL.ics_prmt_schd_evt_viol_elem (
     ics_prmt_schd_evt_viol_elem_id
   , ics_schd_evt_viol_id
   , prmt_ident
   , narr_cond_num
   , schd_evt_code
   , schd_date
   , schd_viol_code
   , data_hash)
SELECT 
     null /* no mapping */ --ics_prmt_schd_evt_viol_elem_id, 
   , null /* no mapping */ --ics_schd_evt_viol_id, 
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --narr_cond_num, NarrativeConditionNumber
   , null /* no mapping */ --schd_evt_code, ScheduleEventCode
   , null /* no mapping */ --schd_date, ScheduleDate
   , null /* no mapping */ --schd_viol_code, ScheduleViolationCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

END;
