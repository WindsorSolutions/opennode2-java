﻿
/*************************************************************************************************
** ObjectName: ics_etl_swms4smallpermit
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the SWMS4SmallPermitSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_swms4smallpermit

AS

BEGIN
---------------------------- 
-- ICS_SWMS_4_SMALL_PRMT
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ics_swms_4_small_prmt;


-- /ICS_SWMS_4_SMALL_PRMT
INSERT INTO ICS_FLOW_LOCAL.ics_swms_4_small_prmt (
     ics_swms_4_small_prmt_id
   , ics_payload_id
   , src_systm_ident
   , transaction_type
   , transaction_timestamp
   , prmt_ident
   , st_wtr_body_name
   , rcvg_ms_4_name
   , impaired_wtr_ind
   , hist_prop_ind
   , hist_prop_crit_met_code
   , species_crit_habitat_ind
   , species_crit_met_code
   , indst_acty_size
   , legal_entity_type_code
   , ms_4_prmt_class_code
   , ms_4_type_code
   , ms_4_acreage_covered_num
   , ms_4_popl_served_num
   , urbanized_area_incrp_plce_name
   , ms_4_annul_expen_dollars
   , ms_4_annul_expen_year
   , ms_4_budget_dollars
   , ms_4_budget_year
   , proj_srcs_of_fund_code
   , major_outfall_est_meas_ind
   , major_outfall_num
   , minor_outfall_est_meas_ind
   , minor_outfall_num
   , qual_loc_prog_ind
   , qual_loc_prog_desc_txt
   , shared_resp_ind
   , shared_resp_desc_txt
   , key_hash
   , data_hash)
SELECT 
     null /* no mapping */ --ics_swms_4_small_prmt_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --st_wtr_body_name, StateWaterBodyName
   , null /* no mapping */ --rcvg_ms_4_name, ReceivingMS4Name
   , null /* no mapping */ --impaired_wtr_ind, ImpairedWaterIndicator
   , null /* no mapping */ --hist_prop_ind, HistoricPropertyIndicator
   , null /* no mapping */ --hist_prop_crit_met_code, HistoricPropertyCriterionMetCode
   , null /* no mapping */ --species_crit_habitat_ind, SpeciesCriticalHabitatIndicator
   , null /* no mapping */ --species_crit_met_code, SpeciesCriterionMetCode
   , null /* no mapping */ --indst_acty_size, IndustrialActivitySize
   , null /* no mapping */ --legal_entity_type_code, LegalEntityTypeCode
   , null /* no mapping */ --ms_4_prmt_class_code, MS4PermitClassCode
   , null /* no mapping */ --ms_4_type_code, MS4TypeCode
   , null /* no mapping */ --ms_4_acreage_covered_num, MS4AcreageCoveredNumber
   , null /* no mapping */ --ms_4_popl_served_num, MS4PopulationServedNumber
   , null /* no mapping */ --urbanized_area_incrp_plce_name, UrbanizedAreaIncorporatedPlaceName
   , null /* no mapping */ --ms_4_annul_expen_dollars, MS4AnnualExpenditureDollars
   , null /* no mapping */ --ms_4_annul_expen_year, MS4AnnualExpenditureYear
   , null /* no mapping */ --ms_4_budget_dollars, MS4BudgetDollars
   , null /* no mapping */ --ms_4_budget_year, MS4BudgetYear
   , null /* no mapping */ --proj_srcs_of_fund_code, ProjectSourcesOfFundingCode
   , null /* no mapping */ --major_outfall_est_meas_ind, MajorOutfallEstimatedMeasureIndicator
   , null /* no mapping */ --major_outfall_num, MajorOutfallNumber
   , null /* no mapping */ --minor_outfall_est_meas_ind, MinorOutfallEstimatedMeasureIndicator
   , null /* no mapping */ --minor_outfall_num, MinorOutfallNumber
   , null /* no mapping */ --qual_loc_prog_ind, QualifyingLocalProgramIndicator
   , null /* no mapping */ --qual_loc_prog_desc_txt, QualifyingLocalProgramDescriptionText
   , null /* no mapping */ --shared_resp_ind, SharedResponsibilitiesIndicator
   , null /* no mapping */ --shared_resp_desc_txt, SharedResponsibilitiesDescriptionText
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SWMS_4_SMALL_PRMT/ICS_ADDR
INSERT INTO ICS_FLOW_LOCAL.ics_addr (
     ics_addr_id
   , ics_fac_id
   , ics_basic_prmt_id
   , ics_prmt_featr_id
   , ics_bs_mgmt_practices_id
   , ics_bs_prmt_id
   , ics_cafo_prmt_id
   , ics_gnrl_prmt_id
   , ics_sw_cnst_prmt_id
   , ics_sw_evt_rep_id
   , ics_sw_indst_prmt_id
   , ics_swms_4_large_prmt_id
   , ics_swms_4_prog_rep_id
   , ics_swms_4_small_prmt_id
   , ics_unprmt_fac_id
   , affil_type_txt
   , org_frml_name
   , org_duns_num
   , mailing_addr_txt
   , suppl_addr_txt
   , mailing_addr_city_name
   , mailing_addr_st_code
   , mailing_addr_zip_code
   , county_name
   , mailing_addr_country_code
   , division_name
   , loc_province
   , elec_addr_txt
   , start_date_of_addr_assc
   , end_date_of_addr_assc
   , data_hash)
SELECT 
     null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --ics_bs_mgmt_practices_id, 
   , null /* no mapping */ --ics_bs_prmt_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_sw_cnst_prmt_id, 
   , null /* no mapping */ --ics_sw_evt_rep_id, 
   , null /* no mapping */ --ics_sw_indst_prmt_id, 
   , null /* no mapping */ --ics_swms_4_large_prmt_id, 
   , null /* no mapping */ --ics_swms_4_prog_rep_id, 
   , null /* no mapping */ --ics_swms_4_small_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --affil_type_txt, AffiliationTypeText
   , null /* no mapping */ --org_frml_name, OrganizationFormalName
   , null /* no mapping */ --org_duns_num, OrganizationDUNSNumber
   , null /* no mapping */ --mailing_addr_txt, MailingAddressText
   , null /* no mapping */ --suppl_addr_txt, SupplementalAddressText
   , null /* no mapping */ --mailing_addr_city_name, MailingAddressCityName
   , null /* no mapping */ --mailing_addr_st_code, MailingAddressStateCode
   , null /* no mapping */ --mailing_addr_zip_code, MailingAddressZipCode
   , null /* no mapping */ --county_name, CountyName
   , null /* no mapping */ --mailing_addr_country_code, MailingAddressCountryCode
   , null /* no mapping */ --division_name, DivisionName
   , null /* no mapping */ --loc_province, LocationProvince
   , null /* no mapping */ --elec_addr_txt, ElectronicAddressText
   , null /* no mapping */ --start_date_of_addr_assc, StartDateOfAddressAssociation
   , null /* no mapping */ --end_date_of_addr_assc, EndDateOfAddressAssociation
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SWMS_4_SMALL_PRMT/ICS_ADDR/ICS_TELEPH
INSERT INTO ICS_FLOW_LOCAL.ics_teleph (
     ics_teleph_id
   , ics_contact_id
   , ics_addr_id
   , ics_efflu_trade_prtner_addr_id
   , teleph_num_type_code
   , teleph_num
   , teleph_ext_num
   , data_hash)
SELECT 
     null /* no mapping */ --ics_teleph_id, 
   , null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_efflu_trade_prtner_addr_id, 
   , null /* no mapping */ --teleph_num_type_code, TelephoneNumberTypeCode
   , null /* no mapping */ --teleph_num, TelephoneNumber
   , null /* no mapping */ --teleph_ext_num, TelephoneExtensionNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SWMS_4_SMALL_PRMT/ICS_CONTACT
INSERT INTO ICS_FLOW_LOCAL.ics_contact (
     ics_contact_id
   , ics_fac_id
   , ics_basic_prmt_id
   , ics_prmt_featr_id
   , ics_bs_mgmt_practices_id
   , ics_bs_annul_prog_rep_id
   , ics_bs_prmt_id
   , ics_cafo_prmt_id
   , ics_cmpl_mon_id
   , ics_gnrl_prmt_id
   , ics_master_gnrl_prmt_id
   , ics_pretr_prmt_id
   , ics_sw_cnst_prmt_id
   , ics_sw_evt_rep_id
   , ics_sw_indst_prmt_id
   , ics_swms_4_large_prmt_id
   , ics_swms_4_prog_rep_id
   , ics_swms_4_small_prmt_id
   , ics_unprmt_fac_id
   , affil_type_txt
   , first_name
   , middle_name
   , last_name
   , indvl_title_txt
   , org_frml_name
   , st_code
   , rgn_code
   , elec_addr_txt
   , start_date_of_contact_assc
   , end_date_of_contact_assc
   , data_hash)
SELECT 
     null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --ics_bs_mgmt_practices_id, 
   , null /* no mapping */ --ics_bs_annul_prog_rep_id, 
   , null /* no mapping */ --ics_bs_prmt_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_cmpl_mon_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_master_gnrl_prmt_id, 
   , null /* no mapping */ --ics_pretr_prmt_id, 
   , null /* no mapping */ --ics_sw_cnst_prmt_id, 
   , null /* no mapping */ --ics_sw_evt_rep_id, 
   , null /* no mapping */ --ics_sw_indst_prmt_id, 
   , null /* no mapping */ --ics_swms_4_large_prmt_id, 
   , null /* no mapping */ --ics_swms_4_prog_rep_id, 
   , null /* no mapping */ --ics_swms_4_small_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --affil_type_txt, AffiliationTypeText
   , null /* no mapping */ --first_name, FirstName
   , null /* no mapping */ --middle_name, MiddleName
   , null /* no mapping */ --last_name, LastName
   , null /* no mapping */ --indvl_title_txt, IndividualTitleText
   , null /* no mapping */ --org_frml_name, OrganizationFormalName
   , null /* no mapping */ --st_code, StateCode
   , null /* no mapping */ --rgn_code, RegionCode
   , null /* no mapping */ --elec_addr_txt, ElectronicAddressText
   , null /* no mapping */ --start_date_of_contact_assc, StartDateOfContactAssociation
   , null /* no mapping */ --end_date_of_contact_assc, EndDateOfContactAssociation
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SWMS_4_SMALL_PRMT/ICS_CONTACT/ICS_TELEPH
INSERT INTO ICS_FLOW_LOCAL.ics_teleph (
     ics_teleph_id
   , ics_contact_id
   , ics_addr_id
   , ics_efflu_trade_prtner_addr_id
   , teleph_num_type_code
   , teleph_num
   , teleph_ext_num
   , data_hash)
SELECT 
     null /* no mapping */ --ics_teleph_id, 
   , null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_efflu_trade_prtner_addr_id, 
   , null /* no mapping */ --teleph_num_type_code, TelephoneNumberTypeCode
   , null /* no mapping */ --teleph_num, TelephoneNumber
   , null /* no mapping */ --teleph_ext_num, TelephoneExtensionNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SWMS_4_SMALL_PRMT/ICS_GPCF_CNST_WAIVER
INSERT INTO ICS_FLOW_LOCAL.ics_gpcf_cnst_waiver (
     ics_gpcf_cnst_waiver_id
   , ics_swms_4_small_prmt_id
   , cnst_waiver_auth_date
   , cnst_waiver_criteria_met_ind
   , cnst_waiver_eval_basis_code
   , cnst_waiver_eval_date
   , cnst_waiver_postmark_date
   , proj_isoerodent_value
   , proj_est_start_date
   , proj_est_completed_date
   , data_hash)
SELECT 
     null /* no mapping */ --ics_gpcf_cnst_waiver_id, 
   , null /* no mapping */ --ics_swms_4_small_prmt_id, 
   , null /* no mapping */ --cnst_waiver_auth_date, ConstructionWaiverAuthorizationDate
   , null /* no mapping */ --cnst_waiver_criteria_met_ind, ConstructionWaiverCriteriaMetIndicator
   , null /* no mapping */ --cnst_waiver_eval_basis_code, ConstructionWaiverEvaluationBasisCode
   , null /* no mapping */ --cnst_waiver_eval_date, ConstructionWaiverEvaluationDate
   , null /* no mapping */ --cnst_waiver_postmark_date, ConstructionWaiverPostmarkDate
   , null /* no mapping */ --proj_isoerodent_value, ProjectIsoerodentValue
   , null /* no mapping */ --proj_est_start_date, ProjectEstimatedStartDate
   , null /* no mapping */ --proj_est_completed_date, ProjectEstimatedCompletedDate
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

END;
