﻿
/*************************************************************************************************
** ObjectName: ics_etl_dischargemonitoringreport
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the DischargeMonitoringReportSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_dischargemonitoringreport

AS

BEGIN
---------------------------- 
-- ICS_DSCH_MON_REP
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ics_dsch_mon_rep;


-- /ICS_DSCH_MON_REP
INSERT INTO ICS_FLOW_LOCAL.ics_dsch_mon_rep (
     ics_dsch_mon_rep_id
   , ics_payload_id
   , src_systm_ident
   , transaction_type
   , transaction_timestamp
   , prmt_ident
   , prmt_featr_ident
   , lmt_set_designator
   , mon_period_end_date
   , elec_subm_type_code
   , sign_date
   , prncpl_exec_offcr_first_name
   , prncpl_exec_offcr_last_name
   , prncpl_exec_offcr_title
   , prncpl_exec_offcr_teleph
   , sign_first_name
   , sign_last_name
   , sign_teleph
   , rep_cmnt_txt
   , dmr_no_dsch_ind
   , dmr_no_dsch_rcvd_date
   , key_hash
   , data_hash)
SELECT 
     null /* no mapping */ --ics_dsch_mon_rep_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --prmt_featr_ident, PermittedFeatureIdentifier
   , null /* no mapping */ --lmt_set_designator, LimitSetDesignator
   , null /* no mapping */ --mon_period_end_date, MonitoringPeriodEndDate
   , null /* no mapping */ --elec_subm_type_code, ElectronicSubmissionTypeCode
   , null /* no mapping */ --sign_date, SignatureDate
   , null /* no mapping */ --prncpl_exec_offcr_first_name, PrincipalExecutiveOfficerFirstName
   , null /* no mapping */ --prncpl_exec_offcr_last_name, PrincipalExecutiveOfficerLastName
   , null /* no mapping */ --prncpl_exec_offcr_title, PrincipalExecutiveOfficerTitle
   , null /* no mapping */ --prncpl_exec_offcr_teleph, PrincipalExecutiveOfficerTelephone
   , null /* no mapping */ --sign_first_name, SignatoryFirstName
   , null /* no mapping */ --sign_last_name, SignatoryLastName
   , null /* no mapping */ --sign_teleph, SignatoryTelephone
   , null /* no mapping */ --rep_cmnt_txt, ReportCommentText
   , null /* no mapping */ --dmr_no_dsch_ind, DMRNoDischargeIndicator
   , null /* no mapping */ --dmr_no_dsch_rcvd_date, DMRNoDischargeReceivedDate
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_DSCH_MON_REP/ICS_CO_DSPL_SITE
INSERT INTO ICS_FLOW_LOCAL.ics_co_dspl_site (
     ics_co_dspl_site_id
   , ics_dsch_mon_rep_id
   , part_258_cmpl_ind
   , paint_filter_test_result
   , tclp_test_result
   , data_hash)
SELECT 
     null /* no mapping */ --ics_co_dspl_site_id, 
   , null /* no mapping */ --ics_dsch_mon_rep_id, 
   , null /* no mapping */ --part_258_cmpl_ind, Part258ComplianceIndicator
   , null /* no mapping */ --paint_filter_test_result, PaintFilterTestResult
   , null /* no mapping */ --tclp_test_result, TCLPTestResult
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_DSCH_MON_REP/ICS_INCIN
INSERT INTO ICS_FLOW_LOCAL.ics_incin (
     ics_incin_id
   , ics_dsch_mon_rep_id
   , beryllium_cmpl_ind
   , mercury_cmpl_ind
   , data_hash)
SELECT 
     null /* no mapping */ --ics_incin_id, 
   , null /* no mapping */ --ics_dsch_mon_rep_id, 
   , null /* no mapping */ --beryllium_cmpl_ind, BerylliumComplianceIndicator
   , null /* no mapping */ --mercury_cmpl_ind, MercuryComplianceIndicator
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE
INSERT INTO ICS_FLOW_LOCAL.ics_land_appl_site (
     ics_land_appl_site_id
   , ics_dsch_mon_rep_id
   , polut_met_for_land_appl
   , pathogen_reduction_ind
   , vector_reduction_ind
   , agronomic_gal_rate_for_fld
   , agronomic_dmt_rate_for_fld
   , class_a_alt_used
   , class_a_alts_txt
   , class_b_alt_used
   , class_b_alts_txt
   , var_alt_used
   , var_alts_txt
   , data_hash)
SELECT 
     null /* no mapping */ --ics_land_appl_site_id, 
   , null /* no mapping */ --ics_dsch_mon_rep_id, 
   , null /* no mapping */ --polut_met_for_land_appl, PollutantMetForLandApplication
   , null /* no mapping */ --pathogen_reduction_ind, PathogenReductionIndicator
   , null /* no mapping */ --vector_reduction_ind, VectorReductionIndicator
   , null /* no mapping */ --agronomic_gal_rate_for_fld, AgronomicGallonsRateForField
   , null /* no mapping */ --agronomic_dmt_rate_for_fld, AgronomicDMTRateForField
   , null /* no mapping */ --class_a_alt_used, ClassAAlternativeUsed
   , null /* no mapping */ --class_a_alts_txt, ClassAAlternativesText
   , null /* no mapping */ --class_b_alt_used, ClassBAlternativeUsed
   , null /* no mapping */ --class_b_alts_txt, ClassBAlternativesText
   , null /* no mapping */ --var_alt_used, VARAlternativeUsed
   , null /* no mapping */ --var_alts_txt, VARAlternativesText
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE/ICS_CROP_TYPES_HARVESTED
INSERT INTO ICS_FLOW_LOCAL.ics_crop_types_harvested (
     ics_crop_types_harvested_id
   , ics_land_appl_site_id
   , crop_types_harvested
   , data_hash)
SELECT 
     null /* no mapping */ --ics_crop_types_harvested_id, 
   , null /* no mapping */ --ics_land_appl_site_id, 
   , null /* no mapping */ --crop_types_harvested, CropTypesHarvested
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE/ICS_CROP_TYPES_PLANTED
INSERT INTO ICS_FLOW_LOCAL.ics_crop_types_planted (
     ics_crop_types_planted_id
   , ics_land_appl_site_id
   , crop_types_planted
   , data_hash)
SELECT 
     null /* no mapping */ --ics_crop_types_planted_id, 
   , null /* no mapping */ --ics_land_appl_site_id, 
   , null /* no mapping */ --crop_types_planted, CropTypesPlanted
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_DSCH_MON_REP/ICS_REP_PARAM
INSERT INTO ICS_FLOW_LOCAL.ics_rep_param (
     ics_rep_param_id
   , ics_dsch_mon_rep_id
   , param_code
   , mon_site_desc_code
   , lmt_season_num
   , rep_smpl_type_txt
   , rep_freq_code
   , rep_num_of_excursions
   , concen_num_rep_unit_meas_code
   , qty_num_rep_unit_meas_code
   , data_hash)
SELECT 
     null /* no mapping */ --ics_rep_param_id, 
   , null /* no mapping */ --ics_dsch_mon_rep_id, 
   , null /* no mapping */ --param_code, ParameterCode
   , null /* no mapping */ --mon_site_desc_code, MonitoringSiteDescriptionCode
   , null /* no mapping */ --lmt_season_num, LimitSeasonNumber
   , null /* no mapping */ --rep_smpl_type_txt, ReportSampleTypeText
   , null /* no mapping */ --rep_freq_code, ReportingFrequencyCode
   , null /* no mapping */ --rep_num_of_excursions, ReportNumberOfExcursions
   , null /* no mapping */ --concen_num_rep_unit_meas_code, ConcentrationNumericReportUnitMeasureCode
   , null /* no mapping */ --qty_num_rep_unit_meas_code, QuantityNumericReportUnitMeasureCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_DSCH_MON_REP/ICS_REP_PARAM/ICS_NUM_REP
INSERT INTO ICS_FLOW_LOCAL.ics_num_rep (
     ics_num_rep_id
   , ics_rep_param_id
   , num_rep_code
   , num_rep_rcvd_date
   , num_rep_no_dsch_ind
   , num_cond_qty
   , num_cond_adjusted_qty
   , num_cond_qualifier
   , data_hash)
SELECT 
     null /* no mapping */ --ics_num_rep_id, 
   , null /* no mapping */ --ics_rep_param_id, 
   , null /* no mapping */ --num_rep_code, NumericReportCode
   , null /* no mapping */ --num_rep_rcvd_date, NumericReportReceivedDate
   , null /* no mapping */ --num_rep_no_dsch_ind, NumericReportNoDischargeIndicator
   , null /* no mapping */ --num_cond_qty, NumericConditionQuantity
   , null /* no mapping */ --num_cond_adjusted_qty, NumericConditionAdjustedQuantity
   , null /* no mapping */ --num_cond_qualifier, NumericConditionQualifier
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_DSCH_MON_REP/ICS_SURF_DSPL_SITE
INSERT INTO ICS_FLOW_LOCAL.ics_surf_dspl_site (
     ics_surf_dspl_site_id
   , ics_dsch_mon_rep_id
   , pathogen_reduction_ind
   , vector_reduction_ind
   , mgmt_practices_ind
   , cert_statement_ind
   , cert_first_name
   , cert_last_name
   , class_a_alt_used
   , class_a_alts_txt
   , class_b_alt_used
   , class_b_alts_txt
   , var_alt_used
   , var_alts_txt
   , data_hash)
SELECT 
     null /* no mapping */ --ics_surf_dspl_site_id, 
   , null /* no mapping */ --ics_dsch_mon_rep_id, 
   , null /* no mapping */ --pathogen_reduction_ind, PathogenReductionIndicator
   , null /* no mapping */ --vector_reduction_ind, VectorReductionIndicator
   , null /* no mapping */ --mgmt_practices_ind, ManagementPracticesIndicator
   , null /* no mapping */ --cert_statement_ind, CertificationStatementIndicator
   , null /* no mapping */ --cert_first_name, CertifierFirstName
   , null /* no mapping */ --cert_last_name, CertifierLastName
   , null /* no mapping */ --class_a_alt_used, ClassAAlternativeUsed
   , null /* no mapping */ --class_a_alts_txt, ClassAAlternativesText
   , null /* no mapping */ --class_b_alt_used, ClassBAlternativeUsed
   , null /* no mapping */ --class_b_alts_txt, ClassBAlternativesText
   , null /* no mapping */ --var_alt_used, VARAlternativeUsed
   , null /* no mapping */ --var_alts_txt, VARAlternativesText
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

END;
