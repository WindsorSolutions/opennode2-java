﻿
/*************************************************************************************************
** ObjectName: ics_etl_dmrviolation
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the DMRViolationSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_dmrviolation

AS

BEGIN
---------------------------- 
-- ICS_DMR_VIOL
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ics_dmr_viol;


-- /ICS_DMR_VIOL
INSERT INTO ICS_FLOW_LOCAL.ics_dmr_viol (
     ics_dmr_viol_id
   , ics_payload_id
   , src_systm_ident
   , transaction_type
   , transaction_timestamp
   , prmt_ident
   , prmt_featr_ident
   , lmt_set_designator
   , mon_period_end_date
   , param_code
   , mon_site_desc_code
   , lmt_season_num
   , num_rep_code
   , num_rep_viol_code
   , rep_non_cmpl_detect_code
   , rep_non_cmpl_detect_date
   , rep_non_cmpl_resl_code
   , rep_non_cmpl_resl_date
   , key_hash
   , data_hash)
SELECT 
     null /* no mapping */ --ics_dmr_viol_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --prmt_featr_ident, PermittedFeatureIdentifier
   , null /* no mapping */ --lmt_set_designator, LimitSetDesignator
   , null /* no mapping */ --mon_period_end_date, MonitoringPeriodEndDate
   , null /* no mapping */ --param_code, ParameterCode
   , null /* no mapping */ --mon_site_desc_code, MonitoringSiteDescriptionCode
   , null /* no mapping */ --lmt_season_num, LimitSeasonNumber
   , null /* no mapping */ --num_rep_code, NumericReportCode
   , null /* no mapping */ --num_rep_viol_code, NumericReportViolationCode
   , null /* no mapping */ --rep_non_cmpl_detect_code, ReportableNonComplianceDetectionCode
   , null /* no mapping */ --rep_non_cmpl_detect_date, ReportableNonComplianceDetectionDate
   , null /* no mapping */ --rep_non_cmpl_resl_code, ReportableNonComplianceResolutionCode
   , null /* no mapping */ --rep_non_cmpl_resl_date, ReportableNonComplianceResolutionDate
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

END;
