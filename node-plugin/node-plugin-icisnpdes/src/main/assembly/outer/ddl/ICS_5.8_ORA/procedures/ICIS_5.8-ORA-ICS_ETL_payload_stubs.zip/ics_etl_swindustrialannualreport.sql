﻿
/*************************************************************************************************
** ObjectName: ics_etl_swindustrialannualreport
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the SWIndustrialAnnualReport module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_swindustrialannualreport

AS

BEGIN
---------------------------- 
-- ICS_SW_INDST_ANNUL_REP
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ics_sw_indst_annul_rep;


-- /ICS_SW_INDST_ANNUL_REP
INSERT INTO ICS_FLOW_LOCAL.ics_sw_indst_annul_rep (
     ics_sw_indst_annul_rep_id
   , ics_payload_id
   , src_systm_ident
   , transaction_type
   , transaction_timestamp
   , prmt_ident
   , indst_sw_annul_rep_rcvd_date
   , fac_insp_summ_txt
   , visual_assessment_summ_txt
   , no_further_reduction_summ_txt
   , corr_actn_summ_txt
   , key_hash
   , data_hash)
SELECT 
     null /* no mapping */ --ics_sw_indst_annul_rep_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --indst_sw_annul_rep_rcvd_date, IndustrialStormWaterAnnualReportReceivedDate
   , null /* no mapping */ --fac_insp_summ_txt, FacilityInspectionSummaryText
   , null /* no mapping */ --visual_assessment_summ_txt, VisualAssessmentSummaryText
   , null /* no mapping */ --no_further_reduction_summ_txt, NoFurtherReductionSummaryText
   , null /* no mapping */ --corr_actn_summ_txt, CorrectiveActionSummaryText
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

END;
