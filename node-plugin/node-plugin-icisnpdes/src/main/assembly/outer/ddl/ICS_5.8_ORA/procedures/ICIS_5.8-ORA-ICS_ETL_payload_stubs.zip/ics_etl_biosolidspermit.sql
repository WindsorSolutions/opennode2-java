﻿
/*************************************************************************************************
** ObjectName: ics_etl_biosolidspermit
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the BiosolidsPermitSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_biosolidspermit

AS

BEGIN
---------------------------- 
-- ICS_BS_PRMT
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ics_bs_prmt;


-- /ICS_BS_PRMT
INSERT INTO ICS_FLOW_LOCAL.ics_bs_prmt (
     ics_bs_prmt_id
   , ics_payload_id
   , src_systm_ident
   , transaction_type
   , transaction_timestamp
   , prmt_ident
   , eq_prod_dist_marketed_amt
   , land_applied_amt
   , incinerated_amt
   , codisposed_in_msw_landfill_amt
   , surf_dspl_amt
   , mnged_othr_mthds_amt
   , rcvd_offsite_srcs_amt
   , transferred_amt
   , disposed_out_of_st_amt
   , benef_used_out_of_st_amt
   , mnged_othr_mthds_out_of_st_amt
   , ttl_removed_amt
   , annul_dry_sldg_prod_num
   , key_hash
   , data_hash)
SELECT 
     null /* no mapping */ --ics_bs_prmt_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --eq_prod_dist_marketed_amt, EQProductDistributedMarketedAmount
   , null /* no mapping */ --land_applied_amt, LandAppliedAmount
   , null /* no mapping */ --incinerated_amt, IncineratedAmount
   , null /* no mapping */ --codisposed_in_msw_landfill_amt, CodisposedInMSWLandfillAmount
   , null /* no mapping */ --surf_dspl_amt, SurfaceDisposalAmount
   , null /* no mapping */ --mnged_othr_mthds_amt, ManagedOtherMethodsAmount
   , null /* no mapping */ --rcvd_offsite_srcs_amt, ReceivedOffsiteSourcesAmount
   , null /* no mapping */ --transferred_amt, TransferredAmount
   , null /* no mapping */ --disposed_out_of_st_amt, DisposedOutOfStateAmount
   , null /* no mapping */ --benef_used_out_of_st_amt, BeneficiallyUsedOutOfStateAmount
   , null /* no mapping */ --mnged_othr_mthds_out_of_st_amt, ManagedOtherMethodsOutOfStateAmount
   , null /* no mapping */ --ttl_removed_amt, TotalRemovedAmount
   , null /* no mapping */ --annul_dry_sldg_prod_num, AnnualDrySludgeProductionNumber
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BS_PRMT/ICS_ADDR
INSERT INTO ICS_FLOW_LOCAL.ics_addr (
     ics_addr_id
   , ics_fac_id
   , ics_basic_prmt_id
   , ics_prmt_featr_id
   , ics_bs_mgmt_practices_id
   , ics_bs_prmt_id
   , ics_cafo_prmt_id
   , ics_gnrl_prmt_id
   , ics_sw_cnst_prmt_id
   , ics_sw_evt_rep_id
   , ics_sw_indst_prmt_id
   , ics_swms_4_large_prmt_id
   , ics_swms_4_prog_rep_id
   , ics_swms_4_small_prmt_id
   , ics_unprmt_fac_id
   , affil_type_txt
   , org_frml_name
   , org_duns_num
   , mailing_addr_txt
   , suppl_addr_txt
   , mailing_addr_city_name
   , mailing_addr_st_code
   , mailing_addr_zip_code
   , county_name
   , mailing_addr_country_code
   , division_name
   , loc_province
   , elec_addr_txt
   , start_date_of_addr_assc
   , end_date_of_addr_assc
   , data_hash)
SELECT 
     null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --ics_bs_mgmt_practices_id, 
   , null /* no mapping */ --ics_bs_prmt_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_sw_cnst_prmt_id, 
   , null /* no mapping */ --ics_sw_evt_rep_id, 
   , null /* no mapping */ --ics_sw_indst_prmt_id, 
   , null /* no mapping */ --ics_swms_4_large_prmt_id, 
   , null /* no mapping */ --ics_swms_4_prog_rep_id, 
   , null /* no mapping */ --ics_swms_4_small_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --affil_type_txt, AffiliationTypeText
   , null /* no mapping */ --org_frml_name, OrganizationFormalName
   , null /* no mapping */ --org_duns_num, OrganizationDUNSNumber
   , null /* no mapping */ --mailing_addr_txt, MailingAddressText
   , null /* no mapping */ --suppl_addr_txt, SupplementalAddressText
   , null /* no mapping */ --mailing_addr_city_name, MailingAddressCityName
   , null /* no mapping */ --mailing_addr_st_code, MailingAddressStateCode
   , null /* no mapping */ --mailing_addr_zip_code, MailingAddressZipCode
   , null /* no mapping */ --county_name, CountyName
   , null /* no mapping */ --mailing_addr_country_code, MailingAddressCountryCode
   , null /* no mapping */ --division_name, DivisionName
   , null /* no mapping */ --loc_province, LocationProvince
   , null /* no mapping */ --elec_addr_txt, ElectronicAddressText
   , null /* no mapping */ --start_date_of_addr_assc, StartDateOfAddressAssociation
   , null /* no mapping */ --end_date_of_addr_assc, EndDateOfAddressAssociation
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BS_PRMT/ICS_ADDR/ICS_TELEPH
INSERT INTO ICS_FLOW_LOCAL.ics_teleph (
     ics_teleph_id
   , ics_contact_id
   , ics_addr_id
   , ics_efflu_trade_prtner_addr_id
   , teleph_num_type_code
   , teleph_num
   , teleph_ext_num
   , data_hash)
SELECT 
     null /* no mapping */ --ics_teleph_id, 
   , null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_efflu_trade_prtner_addr_id, 
   , null /* no mapping */ --teleph_num_type_code, TelephoneNumberTypeCode
   , null /* no mapping */ --teleph_num, TelephoneNumber
   , null /* no mapping */ --teleph_ext_num, TelephoneExtensionNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BS_PRMT/ICS_BS_END_USE_DSPL_TYPE
INSERT INTO ICS_FLOW_LOCAL.ics_bs_end_use_dspl_type (
     ics_bs_end_use_dspl_type_id
   , ics_bs_prmt_id
   , bs_end_use_dspl_type_code
   , data_hash)
SELECT 
     null /* no mapping */ --ics_bs_end_use_dspl_type_id, 
   , null /* no mapping */ --ics_bs_prmt_id, 
   , null /* no mapping */ --bs_end_use_dspl_type_code, BiosolidsEndUseDisposalTypeCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BS_PRMT/ICS_BS_TYPE
INSERT INTO ICS_FLOW_LOCAL.ics_bs_type (
     ics_bs_type_id
   , ics_bs_prmt_id
   , bs_type_code
   , data_hash)
SELECT 
     null /* no mapping */ --ics_bs_type_id, 
   , null /* no mapping */ --ics_bs_prmt_id, 
   , null /* no mapping */ --bs_type_code, BiosolidsTypeCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BS_PRMT/ICS_CONTACT
INSERT INTO ICS_FLOW_LOCAL.ics_contact (
     ics_contact_id
   , ics_fac_id
   , ics_basic_prmt_id
   , ics_prmt_featr_id
   , ics_bs_mgmt_practices_id
   , ics_bs_annul_prog_rep_id
   , ics_bs_prmt_id
   , ics_cafo_prmt_id
   , ics_cmpl_mon_id
   , ics_gnrl_prmt_id
   , ics_master_gnrl_prmt_id
   , ics_pretr_prmt_id
   , ics_sw_cnst_prmt_id
   , ics_sw_evt_rep_id
   , ics_sw_indst_prmt_id
   , ics_swms_4_large_prmt_id
   , ics_swms_4_prog_rep_id
   , ics_swms_4_small_prmt_id
   , ics_unprmt_fac_id
   , affil_type_txt
   , first_name
   , middle_name
   , last_name
   , indvl_title_txt
   , org_frml_name
   , st_code
   , rgn_code
   , elec_addr_txt
   , start_date_of_contact_assc
   , end_date_of_contact_assc
   , data_hash)
SELECT 
     null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --ics_bs_mgmt_practices_id, 
   , null /* no mapping */ --ics_bs_annul_prog_rep_id, 
   , null /* no mapping */ --ics_bs_prmt_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_cmpl_mon_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_master_gnrl_prmt_id, 
   , null /* no mapping */ --ics_pretr_prmt_id, 
   , null /* no mapping */ --ics_sw_cnst_prmt_id, 
   , null /* no mapping */ --ics_sw_evt_rep_id, 
   , null /* no mapping */ --ics_sw_indst_prmt_id, 
   , null /* no mapping */ --ics_swms_4_large_prmt_id, 
   , null /* no mapping */ --ics_swms_4_prog_rep_id, 
   , null /* no mapping */ --ics_swms_4_small_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --affil_type_txt, AffiliationTypeText
   , null /* no mapping */ --first_name, FirstName
   , null /* no mapping */ --middle_name, MiddleName
   , null /* no mapping */ --last_name, LastName
   , null /* no mapping */ --indvl_title_txt, IndividualTitleText
   , null /* no mapping */ --org_frml_name, OrganizationFormalName
   , null /* no mapping */ --st_code, StateCode
   , null /* no mapping */ --rgn_code, RegionCode
   , null /* no mapping */ --elec_addr_txt, ElectronicAddressText
   , null /* no mapping */ --start_date_of_contact_assc, StartDateOfContactAssociation
   , null /* no mapping */ --end_date_of_contact_assc, EndDateOfContactAssociation
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BS_PRMT/ICS_CONTACT/ICS_TELEPH
INSERT INTO ICS_FLOW_LOCAL.ics_teleph (
     ics_teleph_id
   , ics_contact_id
   , ics_addr_id
   , ics_efflu_trade_prtner_addr_id
   , teleph_num_type_code
   , teleph_num
   , teleph_ext_num
   , data_hash)
SELECT 
     null /* no mapping */ --ics_teleph_id, 
   , null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_efflu_trade_prtner_addr_id, 
   , null /* no mapping */ --teleph_num_type_code, TelephoneNumberTypeCode
   , null /* no mapping */ --teleph_num, TelephoneNumber
   , null /* no mapping */ --teleph_ext_num, TelephoneExtensionNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

END;
