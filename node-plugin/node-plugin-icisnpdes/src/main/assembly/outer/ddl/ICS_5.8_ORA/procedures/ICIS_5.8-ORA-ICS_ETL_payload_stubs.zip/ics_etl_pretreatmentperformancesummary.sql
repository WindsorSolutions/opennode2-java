﻿
/*************************************************************************************************
** ObjectName: ics_etl_pretreatmentperformancesummary
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the PretreatmentPerformanceSummarySubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_pretreatmentperformancesummary

AS

BEGIN
---------------------------- 
-- ICS_PRETR_PERF_SUMM
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ics_pretr_perf_summ;


-- /ICS_PRETR_PERF_SUMM
INSERT INTO ICS_FLOW_LOCAL.ics_pretr_perf_summ (
     ics_pretr_perf_summ_id
   , ics_payload_id
   , src_systm_ident
   , transaction_type
   , transaction_timestamp
   , prmt_ident
   , pretr_perf_summ_end_date
   , pretr_perf_summ_start_date
   , suo_ref
   , suo_date
   , acceptance_haz_waste
   , acceptance_non_haz_indst_waste
   , acceptance_huled_domstic_wstes
   , annul_pretr_budget_pp
   , inadequacy_smpl_insp_ind
   , adequacy_pretr_resources
   , dfcnc_idntfd_drng_iu_file_rviw
   , control_mech_dfcnc
   , legal_auth_dfcnc
   , dfcnc_intrprt_appl_pretr_stndr
   , dfcnc_dat_mgmt_pblc_prticipton
   , viol_iu_schd_rmd_msr
   , frml_rspn_viol_iu_schd_rmd_msr
   , annul_freq_influnt_toxcnt_smpl
   , annul_freq_efflu_toxcnt_smpl
   , annul_freq_sldg_toxcnt_smpl
   , num_si_us
   , si_us_without_control_mech
   , si_us_not_inspected
   , si_us_not_smpl
   , si_us_on_schd
   , si_us_snc_with_pretr_stndr
   , si_us_snc_with_rep_reqs
   , si_us_snc_with_pretr_schd
   , si_us_snc_publ_newspaper
   , viol_notices_issued_si_us
   , admin_orders_issued_si_us
   , civil_suts_fild_aginst_si_us
   , criminl_suts_fild_aginst_si_us
   , dollar_amt_pnlty_coll_pp
   , i_us_whc_pnlty_hav_bee_coll_pp
   , num_ci_us
   , ci_us_in_snc
   , pass_through_interference_ind
   , key_hash
   , data_hash)
SELECT 
     null /* no mapping */ --ics_pretr_perf_summ_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --pretr_perf_summ_end_date, PretreatmentPerformanceSummaryEndDate
   , null /* no mapping */ --pretr_perf_summ_start_date, PretreatmentPerformanceSummaryStartDate
   , null /* no mapping */ --suo_ref, SUOReference
   , null /* no mapping */ --suo_date, SUODate
   , null /* no mapping */ --acceptance_haz_waste, AcceptanceHazardousWaste
   , null /* no mapping */ --acceptance_non_haz_indst_waste, AcceptanceNonHazardousIndustrialWaste
   , null /* no mapping */ --acceptance_huled_domstic_wstes, AcceptanceHauledDomesticWastes
   , null /* no mapping */ --annul_pretr_budget_pp, AnnualPretreatmentBudgetPPS
   , null /* no mapping */ --inadequacy_smpl_insp_ind, InadequacySamplingInspectionIndicator
   , null /* no mapping */ --adequacy_pretr_resources, AdequacyPretreatmentResources
   , null /* no mapping */ --dfcnc_idntfd_drng_iu_file_rviw, DeficienciesIdentifiedDuringIUFileReview
   , null /* no mapping */ --control_mech_dfcnc, ControlMechanismDeficiencies
   , null /* no mapping */ --legal_auth_dfcnc, LegalAuthorityDeficiencies
   , null /* no mapping */ --dfcnc_intrprt_appl_pretr_stndr, DeficienciesInterpretationApplicationPretreatmentStandards
   , null /* no mapping */ --dfcnc_dat_mgmt_pblc_prticipton, DeficienciesDataManagementPublicParticipation
   , null /* no mapping */ --viol_iu_schd_rmd_msr, ViolationIUScheduleRemedialMeasures
   , null /* no mapping */ --frml_rspn_viol_iu_schd_rmd_msr, FormalResponseViolationIUScheduleRemedialMeasures
   , null /* no mapping */ --annul_freq_influnt_toxcnt_smpl, AnnualFrequencyInfluentToxicantSampling
   , null /* no mapping */ --annul_freq_efflu_toxcnt_smpl, AnnualFrequencyEffluentToxicantSampling
   , null /* no mapping */ --annul_freq_sldg_toxcnt_smpl, AnnualFrequencySludgeToxicantSampling
   , null /* no mapping */ --num_si_us, NumberSIUs
   , null /* no mapping */ --si_us_without_control_mech, SIUsWithoutControlMechanism
   , null /* no mapping */ --si_us_not_inspected, SIUsNotInspected
   , null /* no mapping */ --si_us_not_smpl, SIUsNotSampled
   , null /* no mapping */ --si_us_on_schd, SIUsOnSchedule
   , null /* no mapping */ --si_us_snc_with_pretr_stndr, SIUsSNCWithPretreatmentStandards
   , null /* no mapping */ --si_us_snc_with_rep_reqs, SIUsSNCWithReportingRequirements
   , null /* no mapping */ --si_us_snc_with_pretr_schd, SIUsSNCWithPretreatmentSchedule
   , null /* no mapping */ --si_us_snc_publ_newspaper, SIUsSNCPublishedNewspaper
   , null /* no mapping */ --viol_notices_issued_si_us, ViolationNoticesIssuedSIUs
   , null /* no mapping */ --admin_orders_issued_si_us, AdministrativeOrdersIssuedSIUs
   , null /* no mapping */ --civil_suts_fild_aginst_si_us, CivilSuitsFiledAgainstSIUs
   , null /* no mapping */ --criminl_suts_fild_aginst_si_us, CriminalSuitsFiledAgainstSIUs
   , null /* no mapping */ --dollar_amt_pnlty_coll_pp, DollarAmountPenaltiesCollectedPPS
   , null /* no mapping */ --i_us_whc_pnlty_hav_bee_coll_pp, IUsWhichPenaltiesHaveBeenCollectedPPS
   , null /* no mapping */ --num_ci_us, NumberCIUs
   , null /* no mapping */ --ci_us_in_snc, CIUsInSNC
   , null /* no mapping */ --pass_through_interference_ind, PassThroughInterferenceIndicator
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRETR_PERF_SUMM/ICS_LOC_LMTS
INSERT INTO ICS_FLOW_LOCAL.ics_loc_lmts (
     ics_loc_lmts_id
   , ics_pretr_insp_id
   , ics_loc_lmts_prog_rep_id
   , ics_pretr_perf_summ_id
   , mos_rc_date_tech_eval_loc_lmts
   , mos_rc_date_ad_tc_bs_loc_lmts
   , data_hash)
SELECT 
     null /* no mapping */ --ics_loc_lmts_id, 
   , null /* no mapping */ --ics_pretr_insp_id, 
   , null /* no mapping */ --ics_loc_lmts_prog_rep_id, 
   , null /* no mapping */ --ics_pretr_perf_summ_id, 
   , null /* no mapping */ --mos_rc_date_tech_eval_loc_lmts, MostRecentDateTechnicalEvaluationLocalLimits
   , null /* no mapping */ --mos_rc_date_ad_tc_bs_loc_lmts, MostRecentDateAdoptionTechnicallyBasedLocalLimits
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRETR_PERF_SUMM/ICS_LOC_LMTS/ICS_LOC_LMTS_POLUT
INSERT INTO ICS_FLOW_LOCAL.ics_loc_lmts_polut (
     ics_loc_lmts_polut_id
   , ics_loc_lmts_id
   , loc_lmts_polut_code
   , data_hash)
SELECT 
     null /* no mapping */ --ics_loc_lmts_polut_id, 
   , null /* no mapping */ --ics_loc_lmts_id, 
   , null /* no mapping */ --loc_lmts_polut_code, LocalLimitsPollutantCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRETR_PERF_SUMM/ICS_RMVL_CRDTS
INSERT INTO ICS_FLOW_LOCAL.ics_rmvl_crdts (
     ics_rmvl_crdts_id
   , ics_pretr_insp_id
   , ics_loc_lmts_prog_rep_id
   , ics_pretr_perf_summ_id
   , mos_rc_date_rmvl_crdts_aprvl
   , rmvl_crdts_appl_stat_code
   , data_hash)
SELECT 
     null /* no mapping */ --ics_rmvl_crdts_id, 
   , null /* no mapping */ --ics_pretr_insp_id, 
   , null /* no mapping */ --ics_loc_lmts_prog_rep_id, 
   , null /* no mapping */ --ics_pretr_perf_summ_id, 
   , null /* no mapping */ --mos_rc_date_rmvl_crdts_aprvl, MostRecentDateRemovalCreditsApproval
   , null /* no mapping */ --rmvl_crdts_appl_stat_code, RemovalCreditsApplicationStatusCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRETR_PERF_SUMM/ICS_RMVL_CRDTS/ICS_RMVL_CRDTS_POLUT
INSERT INTO ICS_FLOW_LOCAL.ics_rmvl_crdts_polut (
     ics_rmvl_crdts_polut_id
   , ics_rmvl_crdts_id
   , rmvl_crdts_polut_code
   , data_hash)
SELECT 
     null /* no mapping */ --ics_rmvl_crdts_polut_id, 
   , null /* no mapping */ --ics_rmvl_crdts_id, 
   , null /* no mapping */ --rmvl_crdts_polut_code, RemovalCreditsPollutantCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

END;
