﻿
/*************************************************************************************************
** ObjectName: ics_etl_csoeventreport
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the CSOEventReportSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_csoeventreport

AS

BEGIN
---------------------------- 
-- ICS_CSO_EVT_REP
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ics_cso_evt_rep;


-- /ICS_CSO_EVT_REP
INSERT INTO ICS_FLOW_LOCAL.ics_cso_evt_rep (
     ics_cso_evt_rep_id
   , ics_payload_id
   , src_systm_ident
   , transaction_type
   , transaction_timestamp
   , prmt_ident
   , cso_evt_date
   , cso_evt_id
   , dry_or_wet_weather_ind
   , prmt_featr_ident
   , lat_meas
   , long_meas
   , cso_ovrflw_loc_street
   , duration_cso_ovrflw_evt
   , dsch_vol_treated
   , dsch_vol_untreated
   , corr_actn_taken_desc_txt
   , inches_precip
   , key_hash
   , data_hash)
SELECT 
     null /* no mapping */ --ics_cso_evt_rep_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --cso_evt_date, CSOEventDate
   , null /* no mapping */ --cso_evt_id, CSOEventID
   , null /* no mapping */ --dry_or_wet_weather_ind, DryOrWetWeatherIndicator
   , null /* no mapping */ --prmt_featr_ident, PermittedFeatureIdentifier
   , null /* no mapping */ --lat_meas, LatitudeMeasure
   , null /* no mapping */ --long_meas, LongitudeMeasure
   , null /* no mapping */ --cso_ovrflw_loc_street, CSOOverflowLocationStreet
   , null /* no mapping */ --duration_cso_ovrflw_evt, DurationCSOOverflowEvent
   , null /* no mapping */ --dsch_vol_treated, DischargeVolumeTreated
   , null /* no mapping */ --dsch_vol_untreated, DischargeVolumeUntreated
   , null /* no mapping */ --corr_actn_taken_desc_txt, CorrectiveActionTakenDescriptionText
   , null /* no mapping */ --inches_precip, InchesPrecipitation
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

END;
