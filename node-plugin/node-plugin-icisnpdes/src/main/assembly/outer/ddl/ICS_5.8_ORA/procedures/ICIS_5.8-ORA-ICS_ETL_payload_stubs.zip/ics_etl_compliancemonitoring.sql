﻿
/*************************************************************************************************
** ObjectName: ics_etl_compliancemonitoring
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the ComplianceMonitoringSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_compliancemonitoring

AS

BEGIN
---------------------------- 
-- ICS_CMPL_MON
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ics_cmpl_mon;


-- /ICS_CMPL_MON
INSERT INTO ICS_FLOW_LOCAL.ics_cmpl_mon (
     ics_cmpl_mon_id
   , ics_payload_id
   , src_systm_ident
   , transaction_type
   , transaction_timestamp
   , cmpl_mon_ident
   , prmt_ident
   , cmpl_mon_acty_type_code
   , cmpl_mon_catg_code
   , cmpl_mon_date
   , cmpl_mon_start_date
   , cmpl_mon_acty_name
   , biomon_insp_method
   , cmpl_mon_agncy_code
   , st_statute_viol_name
   , epa_assist_ind
   , st_fedr_joint_ind
   , joint_insp_reason_code
   , lead_party
   , num_days_phys_cond_acty
   , num_hours_phys_cond_acty
   , cmpl_mon_actn_outcome_code
   , insp_rating_code
   , multimedia_ind
   , fedr_fac_ind
   , fedr_fac_ind_cmnt
   , insp_usr_dfnd_fld_1
   , insp_usr_dfnd_fld_2
   , insp_usr_dfnd_fld_3
   , insp_usr_dfnd_fld_4
   , insp_usr_dfnd_fld_5
   , insp_usr_dfnd_fld_6
   , insp_cmnt_txt
   , cmpl_mon_planned_start_date
   , cmpl_mon_planned_end_date
   , key_hash
   , data_hash)
SELECT 
     null /* no mapping */ --ics_cmpl_mon_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --cmpl_mon_ident, ComplianceMonitoringIdentifier
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --cmpl_mon_acty_type_code, ComplianceMonitoringActivityTypeCode
   , null /* no mapping */ --cmpl_mon_catg_code, ComplianceMonitoringCategoryCode
   , null /* no mapping */ --cmpl_mon_date, ComplianceMonitoringDate
   , null /* no mapping */ --cmpl_mon_start_date, ComplianceMonitoringStartDate
   , null /* no mapping */ --cmpl_mon_acty_name, ComplianceMonitoringActivityName
   , null /* no mapping */ --biomon_insp_method, BiomonitoringInspectionMethod
   , null /* no mapping */ --cmpl_mon_agncy_code, ComplianceMonitoringAgencyCode
   , null /* no mapping */ --st_statute_viol_name, StateStatuteViolatedName
   , null /* no mapping */ --epa_assist_ind, EPAAssistanceIndicator
   , null /* no mapping */ --st_fedr_joint_ind, StateFederalJointIndicator
   , null /* no mapping */ --joint_insp_reason_code, JointInspectionReasonCode
   , null /* no mapping */ --lead_party, LeadParty
   , null /* no mapping */ --num_days_phys_cond_acty, NumberDaysPhysicallyConductingActivity
   , null /* no mapping */ --num_hours_phys_cond_acty, NumberHoursPhysicallyConductingActivity
   , null /* no mapping */ --cmpl_mon_actn_outcome_code, ComplianceMonitoringActionOutcomeCode
   , null /* no mapping */ --insp_rating_code, InspectionRatingCode
   , null /* no mapping */ --multimedia_ind, MultimediaIndicator
   , null /* no mapping */ --fedr_fac_ind, FederalFacilityIndicator
   , null /* no mapping */ --fedr_fac_ind_cmnt, FederalFacilityIndicatorComment
   , null /* no mapping */ --insp_usr_dfnd_fld_1, InspectionUserDefinedField1
   , null /* no mapping */ --insp_usr_dfnd_fld_2, InspectionUserDefinedField2
   , null /* no mapping */ --insp_usr_dfnd_fld_3, InspectionUserDefinedField3
   , null /* no mapping */ --insp_usr_dfnd_fld_4, InspectionUserDefinedField4
   , null /* no mapping */ --insp_usr_dfnd_fld_5, InspectionUserDefinedField5
   , null /* no mapping */ --insp_usr_dfnd_fld_6, InspectionUserDefinedField6
   , null /* no mapping */ --insp_cmnt_txt, InspectionCommentText
   , null /* no mapping */ --cmpl_mon_planned_start_date, ComplianceMonitoringPlannedStartDate
   , null /* no mapping */ --cmpl_mon_planned_end_date, ComplianceMonitoringPlannedEndDate
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_CAFO_INSP
INSERT INTO ICS_FLOW_LOCAL.ics_cafo_insp (
     ics_cafo_insp_id
   , ics_cmpl_mon_id
   , cafo_class_code
   , is_anml_fac_type_cafo_ind
   , cafo_desgn_date
   , cafo_desgn_reason_txt
   , dsch_drng_year_prod_area_ind
   , num_acres_contrb_drain
   , appl_meas_avail_land_num
   , solid_mnur_lttr_gnrtd_amt
   , liquid_mnur_ww_gnrtd_amt
   , solid_mnur_lttr_trans_amt
   , liquid_mnur_ww_trans_amt
   , nmp_dvlpd_cert_plnr_aprvd_ind
   , nmp_dvlpd_date
   , nmp_last_updated_date
   , envr_mgmt_systm_ind
   , ems_dvlpd_date
   , ems_last_updated_date
   , lvstck_max_cpcty_num
   , lvstck_cpcty_dtrmn_bs_upon_num
   , auth_lvstck_cpcty_num
   , data_hash)
SELECT 
     null /* no mapping */ --ics_cafo_insp_id, 
   , null /* no mapping */ --ics_cmpl_mon_id, 
   , null /* no mapping */ --cafo_class_code, CAFOClassificationCode
   , null /* no mapping */ --is_anml_fac_type_cafo_ind, IsAnimalFacilityTypeCAFOIndicator
   , null /* no mapping */ --cafo_desgn_date, CAFODesignationDate
   , null /* no mapping */ --cafo_desgn_reason_txt, CAFODesignationReasonText
   , null /* no mapping */ --dsch_drng_year_prod_area_ind, DischargesDuringYearProductionAreaIndicator
   , null /* no mapping */ --num_acres_contrb_drain, NumberAcresContributingDrainage
   , null /* no mapping */ --appl_meas_avail_land_num, ApplicationMeasureAvailableLandNumber
   , null /* no mapping */ --solid_mnur_lttr_gnrtd_amt, SolidManureLitterGeneratedAmount
   , null /* no mapping */ --liquid_mnur_ww_gnrtd_amt, LiquidManureWastewaterGeneratedAmount
   , null /* no mapping */ --solid_mnur_lttr_trans_amt, SolidManureLitterTransferAmount
   , null /* no mapping */ --liquid_mnur_ww_trans_amt, LiquidManureWastewaterTransferAmount
   , null /* no mapping */ --nmp_dvlpd_cert_plnr_aprvd_ind, NMPDevelopedCertifiedPlannerApprovedIndicator
   , null /* no mapping */ --nmp_dvlpd_date, NMPDevelopedDate
   , null /* no mapping */ --nmp_last_updated_date, NMPLastUpdatedDate
   , null /* no mapping */ --envr_mgmt_systm_ind, EnvironmentalManagementSystemIndicator
   , null /* no mapping */ --ems_dvlpd_date, EMSDevelopedDate
   , null /* no mapping */ --ems_last_updated_date, EMSLastUpdatedDate
   , null /* no mapping */ --lvstck_max_cpcty_num, LivestockMaximumCapacityNumber
   , null /* no mapping */ --lvstck_cpcty_dtrmn_bs_upon_num, LivestockCapacityDeterminationBasedUponNumber
   , null /* no mapping */ --auth_lvstck_cpcty_num, AuthorizedLivestockCapacityNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_ANML_TYPE
INSERT INTO ICS_FLOW_LOCAL.ics_anml_type (
     ics_anml_type_id
   , ics_cafo_prmt_id
   , ics_cafo_insp_id
   , anml_type_code
   , othr_anml_type_name
   , ttl_num_each_lvstck
   , open_confinemnt_cnt
   , housd_undr_roof_confinemnt_cnt
   , data_hash)
SELECT 
     null /* no mapping */ --ics_anml_type_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_cafo_insp_id, 
   , null /* no mapping */ --anml_type_code, AnimalTypeCode
   , null /* no mapping */ --othr_anml_type_name, OtherAnimalTypeName
   , null /* no mapping */ --ttl_num_each_lvstck, TotalNumbersEachLivestock
   , null /* no mapping */ --open_confinemnt_cnt, OpenConfinementCount
   , null /* no mapping */ --housd_undr_roof_confinemnt_cnt, HousedUnderRoofConfinementCount
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_CAFO_INSP_VIOL_TYPE
INSERT INTO ICS_FLOW_LOCAL.ics_cafo_insp_viol_type (
     ics_cafo_insp_viol_type_id
   , ics_cafo_insp_id
   , cafo_insp_viol_type_code
   , data_hash)
SELECT 
     null /* no mapping */ --ics_cafo_insp_viol_type_id, 
   , null /* no mapping */ --ics_cafo_insp_id, 
   , null /* no mapping */ --cafo_insp_viol_type_code, CAFOInspectionViolationTypeCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_CONTAINMENT
INSERT INTO ICS_FLOW_LOCAL.ics_containment (
     ics_containment_id
   , ics_cafo_prmt_id
   , ics_cafo_insp_id
   , containment_type_code
   , othr_containment_type_name
   , containment_cpcty_num
   , data_hash)
SELECT 
     null /* no mapping */ --ics_containment_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_cafo_insp_id, 
   , null /* no mapping */ --containment_type_code, ContainmentTypeCode
   , null /* no mapping */ --othr_containment_type_name, OtherContainmentTypeName
   , null /* no mapping */ --containment_cpcty_num, ContainmentCapacityNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_LAND_APPL_BMP
INSERT INTO ICS_FLOW_LOCAL.ics_land_appl_bmp (
     ics_land_appl_bmp_id
   , ics_cafo_prmt_id
   , ics_cafo_insp_id
   , land_appl_bmp_type_code
   , othr_land_appl_bmp_type_name
   , data_hash)
SELECT 
     null /* no mapping */ --ics_land_appl_bmp_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_cafo_insp_id, 
   , null /* no mapping */ --land_appl_bmp_type_code, LandApplicationBMPTypeCode
   , null /* no mapping */ --othr_land_appl_bmp_type_name, OtherLandApplicationBMPTypeName
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_MNUR_LTTR_PRCSS_WW_STOR
INSERT INTO ICS_FLOW_LOCAL.ics_mnur_lttr_prcss_ww_stor (
     ics_mnur_lttr_prcss_ww_stor_id
   , ics_cafo_prmt_id
   , ics_cafo_insp_id
   , mnur_lttr_prcss_ww_stor_type
   , othr_stor_type_name
   , stor_ttl_cpcty_meas
   , days_of_stor
   , data_hash)
SELECT 
     null /* no mapping */ --ics_mnur_lttr_prcss_ww_stor_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_cafo_insp_id, 
   , null /* no mapping */ --mnur_lttr_prcss_ww_stor_type, ManureLitterProcessedWastewaterStorageType
   , null /* no mapping */ --othr_stor_type_name, OtherStorageTypeName
   , null /* no mapping */ --stor_ttl_cpcty_meas, StorageTotalCapacityMeasure
   , null /* no mapping */ --days_of_stor, DaysOfStorage
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_CMPL_INSP_TYPE
INSERT INTO ICS_FLOW_LOCAL.ics_cmpl_insp_type (
     ics_cmpl_insp_type_id
   , ics_cmpl_mon_id
   , cmpl_insp_type_code
   , data_hash)
SELECT 
     null /* no mapping */ --ics_cmpl_insp_type_id, 
   , null /* no mapping */ --ics_cmpl_mon_id, 
   , null /* no mapping */ --cmpl_insp_type_code, ComplianceInspectionTypeCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_CMPL_MON_ACTN_REASON
INSERT INTO ICS_FLOW_LOCAL.ics_cmpl_mon_actn_reason (
     ics_cmpl_mon_actn_reason_id
   , ics_cmpl_mon_id
   , cmpl_mon_actn_reason_code
   , data_hash)
SELECT 
     null /* no mapping */ --ics_cmpl_mon_actn_reason_id, 
   , null /* no mapping */ --ics_cmpl_mon_id, 
   , null /* no mapping */ --cmpl_mon_actn_reason_code, ComplianceMonitoringActionReasonCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_CMPL_MON_AGNCY_TYPE
INSERT INTO ICS_FLOW_LOCAL.ics_cmpl_mon_agncy_type (
     ics_cmpl_mon_agncy_type_id
   , ics_cmpl_mon_id
   , cmpl_mon_agncy_type_code
   , data_hash)
SELECT 
     null /* no mapping */ --ics_cmpl_mon_agncy_type_id, 
   , null /* no mapping */ --ics_cmpl_mon_id, 
   , null /* no mapping */ --cmpl_mon_agncy_type_code, ComplianceMonitoringAgencyTypeCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_CONTACT
INSERT INTO ICS_FLOW_LOCAL.ics_contact (
     ics_contact_id
   , ics_fac_id
   , ics_basic_prmt_id
   , ics_prmt_featr_id
   , ics_bs_mgmt_practices_id
   , ics_bs_annul_prog_rep_id
   , ics_bs_prmt_id
   , ics_cafo_prmt_id
   , ics_cmpl_mon_id
   , ics_gnrl_prmt_id
   , ics_master_gnrl_prmt_id
   , ics_pretr_prmt_id
   , ics_sw_cnst_prmt_id
   , ics_sw_evt_rep_id
   , ics_sw_indst_prmt_id
   , ics_swms_4_large_prmt_id
   , ics_swms_4_prog_rep_id
   , ics_swms_4_small_prmt_id
   , ics_unprmt_fac_id
   , affil_type_txt
   , first_name
   , middle_name
   , last_name
   , indvl_title_txt
   , org_frml_name
   , st_code
   , rgn_code
   , elec_addr_txt
   , start_date_of_contact_assc
   , end_date_of_contact_assc
   , data_hash)
SELECT 
     null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --ics_bs_mgmt_practices_id, 
   , null /* no mapping */ --ics_bs_annul_prog_rep_id, 
   , null /* no mapping */ --ics_bs_prmt_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_cmpl_mon_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_master_gnrl_prmt_id, 
   , null /* no mapping */ --ics_pretr_prmt_id, 
   , null /* no mapping */ --ics_sw_cnst_prmt_id, 
   , null /* no mapping */ --ics_sw_evt_rep_id, 
   , null /* no mapping */ --ics_sw_indst_prmt_id, 
   , null /* no mapping */ --ics_swms_4_large_prmt_id, 
   , null /* no mapping */ --ics_swms_4_prog_rep_id, 
   , null /* no mapping */ --ics_swms_4_small_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --affil_type_txt, AffiliationTypeText
   , null /* no mapping */ --first_name, FirstName
   , null /* no mapping */ --middle_name, MiddleName
   , null /* no mapping */ --last_name, LastName
   , null /* no mapping */ --indvl_title_txt, IndividualTitleText
   , null /* no mapping */ --org_frml_name, OrganizationFormalName
   , null /* no mapping */ --st_code, StateCode
   , null /* no mapping */ --rgn_code, RegionCode
   , null /* no mapping */ --elec_addr_txt, ElectronicAddressText
   , null /* no mapping */ --start_date_of_contact_assc, StartDateOfContactAssociation
   , null /* no mapping */ --end_date_of_contact_assc, EndDateOfContactAssociation
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_CONTACT/ICS_TELEPH
INSERT INTO ICS_FLOW_LOCAL.ics_teleph (
     ics_teleph_id
   , ics_contact_id
   , ics_addr_id
   , ics_efflu_trade_prtner_addr_id
   , teleph_num_type_code
   , teleph_num
   , teleph_ext_num
   , data_hash)
SELECT 
     null /* no mapping */ --ics_teleph_id, 
   , null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_efflu_trade_prtner_addr_id, 
   , null /* no mapping */ --teleph_num_type_code, TelephoneNumberTypeCode
   , null /* no mapping */ --teleph_num, TelephoneNumber
   , null /* no mapping */ --teleph_ext_num, TelephoneExtensionNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_CSO_INSP
INSERT INTO ICS_FLOW_LOCAL.ics_cso_insp (
     ics_cso_insp_id
   , ics_cmpl_mon_id
   , cso_evt_date
   , dry_or_wet_weather_ind
   , prmt_featr_ident
   , lat_meas
   , long_meas
   , cso_ovrflw_loc_street
   , duration_cso_ovrflw_evt
   , dsch_vol_treated
   , dsch_vol_untreated
   , corr_actn_taken_desc_txt
   , inches_precip
   , data_hash)
SELECT 
     null /* no mapping */ --ics_cso_insp_id, 
   , null /* no mapping */ --ics_cmpl_mon_id, 
   , null /* no mapping */ --cso_evt_date, CSOEventDate
   , null /* no mapping */ --dry_or_wet_weather_ind, DryOrWetWeatherIndicator
   , null /* no mapping */ --prmt_featr_ident, PermittedFeatureIdentifier
   , null /* no mapping */ --lat_meas, LatitudeMeasure
   , null /* no mapping */ --long_meas, LongitudeMeasure
   , null /* no mapping */ --cso_ovrflw_loc_street, CSOOverflowLocationStreet
   , null /* no mapping */ --duration_cso_ovrflw_evt, DurationCSOOverflowEvent
   , null /* no mapping */ --dsch_vol_treated, DischargeVolumeTreated
   , null /* no mapping */ --dsch_vol_untreated, DischargeVolumeUntreated
   , null /* no mapping */ --corr_actn_taken_desc_txt, CorrectiveActionTakenDescriptionText
   , null /* no mapping */ --inches_precip, InchesPrecipitation
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_NAT_PRIO
INSERT INTO ICS_FLOW_LOCAL.ics_nat_prio (
     ics_nat_prio_id
   , ics_cmpl_mon_id
   , nat_prio_code
   , data_hash)
SELECT 
     null /* no mapping */ --ics_nat_prio_id, 
   , null /* no mapping */ --ics_cmpl_mon_id, 
   , null /* no mapping */ --nat_prio_code, NationalPrioritiesCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_PRETR_INSP
INSERT INTO ICS_FLOW_LOCAL.ics_pretr_insp (
     ics_pretr_insp_id
   , ics_cmpl_mon_id
   , suo_ref
   , suo_date
   , acceptance_haz_waste
   , acceptance_non_haz_indst_waste
   , acceptance_huled_domstic_wstes
   , annul_pretr_budget
   , inadequacy_smpl_insp_ind
   , adequacy_pretr_resources
   , dfcnc_idntfd_drng_iu_file_rviw
   , control_mech_dfcnc
   , legal_auth_dfcnc
   , dfcnc_intrprt_appl_pretr_stndr
   , dfcnc_dat_mgmt_pblc_prticipton
   , viol_iu_schd_rmd_msr
   , frml_rspn_viol_iu_schd_rmd_msr
   , annul_freq_influnt_toxcnt_smpl
   , annul_freq_efflu_toxcnt_smpl
   , annul_freq_sldg_toxcnt_smpl
   , num_si_us
   , si_us_without_control_mech
   , si_us_not_inspected
   , si_us_not_smpl
   , si_us_on_schd
   , si_us_snc_with_pretr_stndr
   , si_us_snc_with_rep_reqs
   , si_us_snc_with_pretr_schd
   , si_us_snc_publ_newspaper
   , viol_notices_issued_si_us
   , admin_orders_issued_si_us
   , civil_suts_fild_aginst_si_us
   , criminl_suts_fild_aginst_si_us
   , dollar_amt_pnlty_coll
   , i_us_whc_pnlty_hav_bee_coll
   , num_ci_us
   , ci_us_in_snc
   , pass_through_interference_ind
   , data_hash)
SELECT 
     null /* no mapping */ --ics_pretr_insp_id, 
   , null /* no mapping */ --ics_cmpl_mon_id, 
   , null /* no mapping */ --suo_ref, SUOReference
   , null /* no mapping */ --suo_date, SUODate
   , null /* no mapping */ --acceptance_haz_waste, AcceptanceHazardousWaste
   , null /* no mapping */ --acceptance_non_haz_indst_waste, AcceptanceNonHazardousIndustrialWaste
   , null /* no mapping */ --acceptance_huled_domstic_wstes, AcceptanceHauledDomesticWastes
   , null /* no mapping */ --annul_pretr_budget, AnnualPretreatmentBudget
   , null /* no mapping */ --inadequacy_smpl_insp_ind, InadequacySamplingInspectionIndicator
   , null /* no mapping */ --adequacy_pretr_resources, AdequacyPretreatmentResources
   , null /* no mapping */ --dfcnc_idntfd_drng_iu_file_rviw, DeficienciesIdentifiedDuringIUFileReview
   , null /* no mapping */ --control_mech_dfcnc, ControlMechanismDeficiencies
   , null /* no mapping */ --legal_auth_dfcnc, LegalAuthorityDeficiencies
   , null /* no mapping */ --dfcnc_intrprt_appl_pretr_stndr, DeficienciesInterpretationApplicationPretreatmentStandards
   , null /* no mapping */ --dfcnc_dat_mgmt_pblc_prticipton, DeficienciesDataManagementPublicParticipation
   , null /* no mapping */ --viol_iu_schd_rmd_msr, ViolationIUScheduleRemedialMeasures
   , null /* no mapping */ --frml_rspn_viol_iu_schd_rmd_msr, FormalResponseViolationIUScheduleRemedialMeasures
   , null /* no mapping */ --annul_freq_influnt_toxcnt_smpl, AnnualFrequencyInfluentToxicantSampling
   , null /* no mapping */ --annul_freq_efflu_toxcnt_smpl, AnnualFrequencyEffluentToxicantSampling
   , null /* no mapping */ --annul_freq_sldg_toxcnt_smpl, AnnualFrequencySludgeToxicantSampling
   , null /* no mapping */ --num_si_us, NumberSIUs
   , null /* no mapping */ --si_us_without_control_mech, SIUsWithoutControlMechanism
   , null /* no mapping */ --si_us_not_inspected, SIUsNotInspected
   , null /* no mapping */ --si_us_not_smpl, SIUsNotSampled
   , null /* no mapping */ --si_us_on_schd, SIUsOnSchedule
   , null /* no mapping */ --si_us_snc_with_pretr_stndr, SIUsSNCWithPretreatmentStandards
   , null /* no mapping */ --si_us_snc_with_rep_reqs, SIUsSNCWithReportingRequirements
   , null /* no mapping */ --si_us_snc_with_pretr_schd, SIUsSNCWithPretreatmentSchedule
   , null /* no mapping */ --si_us_snc_publ_newspaper, SIUsSNCPublishedNewspaper
   , null /* no mapping */ --viol_notices_issued_si_us, ViolationNoticesIssuedSIUs
   , null /* no mapping */ --admin_orders_issued_si_us, AdministrativeOrdersIssuedSIUs
   , null /* no mapping */ --civil_suts_fild_aginst_si_us, CivilSuitsFiledAgainstSIUs
   , null /* no mapping */ --criminl_suts_fild_aginst_si_us, CriminalSuitsFiledAgainstSIUs
   , null /* no mapping */ --dollar_amt_pnlty_coll, DollarAmountPenaltiesCollected
   , null /* no mapping */ --i_us_whc_pnlty_hav_bee_coll, IUsWhichPenaltiesHaveBeenCollected
   , null /* no mapping */ --num_ci_us, NumberCIUs
   , null /* no mapping */ --ci_us_in_snc, CIUsInSNC
   , null /* no mapping */ --pass_through_interference_ind, PassThroughInterferenceIndicator
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_PRETR_INSP/ICS_LOC_LMTS
INSERT INTO ICS_FLOW_LOCAL.ics_loc_lmts (
     ics_loc_lmts_id
   , ics_pretr_insp_id
   , ics_loc_lmts_prog_rep_id
   , ics_pretr_perf_summ_id
   , mos_rc_date_tech_eval_loc_lmts
   , mos_rc_date_ad_tc_bs_loc_lmts
   , data_hash)
SELECT 
     null /* no mapping */ --ics_loc_lmts_id, 
   , null /* no mapping */ --ics_pretr_insp_id, 
   , null /* no mapping */ --ics_loc_lmts_prog_rep_id, 
   , null /* no mapping */ --ics_pretr_perf_summ_id, 
   , null /* no mapping */ --mos_rc_date_tech_eval_loc_lmts, MostRecentDateTechnicalEvaluationLocalLimits
   , null /* no mapping */ --mos_rc_date_ad_tc_bs_loc_lmts, MostRecentDateAdoptionTechnicallyBasedLocalLimits
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_PRETR_INSP/ICS_LOC_LMTS/ICS_LOC_LMTS_POLUT
INSERT INTO ICS_FLOW_LOCAL.ics_loc_lmts_polut (
     ics_loc_lmts_polut_id
   , ics_loc_lmts_id
   , loc_lmts_polut_code
   , data_hash)
SELECT 
     null /* no mapping */ --ics_loc_lmts_polut_id, 
   , null /* no mapping */ --ics_loc_lmts_id, 
   , null /* no mapping */ --loc_lmts_polut_code, LocalLimitsPollutantCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_PRETR_INSP/ICS_RMVL_CRDTS
INSERT INTO ICS_FLOW_LOCAL.ics_rmvl_crdts (
     ics_rmvl_crdts_id
   , ics_pretr_insp_id
   , ics_loc_lmts_prog_rep_id
   , ics_pretr_perf_summ_id
   , mos_rc_date_rmvl_crdts_aprvl
   , rmvl_crdts_appl_stat_code
   , data_hash)
SELECT 
     null /* no mapping */ --ics_rmvl_crdts_id, 
   , null /* no mapping */ --ics_pretr_insp_id, 
   , null /* no mapping */ --ics_loc_lmts_prog_rep_id, 
   , null /* no mapping */ --ics_pretr_perf_summ_id, 
   , null /* no mapping */ --mos_rc_date_rmvl_crdts_aprvl, MostRecentDateRemovalCreditsApproval
   , null /* no mapping */ --rmvl_crdts_appl_stat_code, RemovalCreditsApplicationStatusCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_PRETR_INSP/ICS_RMVL_CRDTS/ICS_RMVL_CRDTS_POLUT
INSERT INTO ICS_FLOW_LOCAL.ics_rmvl_crdts_polut (
     ics_rmvl_crdts_polut_id
   , ics_rmvl_crdts_id
   , rmvl_crdts_polut_code
   , data_hash)
SELECT 
     null /* no mapping */ --ics_rmvl_crdts_polut_id, 
   , null /* no mapping */ --ics_rmvl_crdts_id, 
   , null /* no mapping */ --rmvl_crdts_polut_code, RemovalCreditsPollutantCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_PROG
INSERT INTO ICS_FLOW_LOCAL.ics_prog (
     ics_prog_id
   , ics_cmpl_mon_id
   , prog_code
   , data_hash)
SELECT 
     null /* no mapping */ --ics_prog_id, 
   , null /* no mapping */ --ics_cmpl_mon_id, 
   , null /* no mapping */ --prog_code, ProgramCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_PROG_DEFCY_TYPE
INSERT INTO ICS_FLOW_LOCAL.ics_prog_defcy_type (
     ics_prog_defcy_type_id
   , ics_cmpl_mon_id
   , prog_defcy_type_code
   , data_hash)
SELECT 
     null /* no mapping */ --ics_prog_defcy_type_id, 
   , null /* no mapping */ --ics_cmpl_mon_id, 
   , null /* no mapping */ --prog_defcy_type_code, ProgramDeficiencyTypeCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SSO_INSP
INSERT INTO ICS_FLOW_LOCAL.ics_sso_insp (
     ics_sso_insp_id
   , ics_cmpl_mon_id
   , sso_evt_date
   , cause_sso_ovrflw_evt
   , lat_meas
   , long_meas
   , sso_ovrflw_loc_street
   , duration_sso_ovrflw_evt
   , sso_vol
   , name_rcvg_wtr
   , desc_stps_taken
   , data_hash)
SELECT 
     null /* no mapping */ --ics_sso_insp_id, 
   , null /* no mapping */ --ics_cmpl_mon_id, 
   , null /* no mapping */ --sso_evt_date, SSOEventDate
   , null /* no mapping */ --cause_sso_ovrflw_evt, CauseSSOOverflowEvent
   , null /* no mapping */ --lat_meas, LatitudeMeasure
   , null /* no mapping */ --long_meas, LongitudeMeasure
   , null /* no mapping */ --sso_ovrflw_loc_street, SSOOverflowLocationStreet
   , null /* no mapping */ --duration_sso_ovrflw_evt, DurationSSOOverflowEvent
   , null /* no mapping */ --sso_vol, SSOVolume
   , null /* no mapping */ --name_rcvg_wtr, NameReceivingWater
   , null /* no mapping */ --desc_stps_taken, DescriptionStepsTaken
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SSO_INSP/ICS_IMPACT_SSO_EVT
INSERT INTO ICS_FLOW_LOCAL.ics_impact_sso_evt (
     ics_impact_sso_evt_id
   , ics_sso_insp_id
   , ics_sso_evt_rep_id
   , impact_sso_evt
   , data_hash)
SELECT 
     null /* no mapping */ --ics_impact_sso_evt_id, 
   , null /* no mapping */ --ics_sso_insp_id, 
   , null /* no mapping */ --ics_sso_evt_rep_id, 
   , null /* no mapping */ --impact_sso_evt, ImpactSSOEvent
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SSO_INSP/ICS_SSO_STPS
INSERT INTO ICS_FLOW_LOCAL.ics_sso_stps (
     ics_sso_stps_id
   , ics_sso_insp_id
   , ics_sso_evt_rep_id
   , stps_rduce_prevnt_mitigte
   , othr_stps_rduce_prevnt_mitigte
   , data_hash)
SELECT 
     null /* no mapping */ --ics_sso_stps_id, 
   , null /* no mapping */ --ics_sso_insp_id, 
   , null /* no mapping */ --ics_sso_evt_rep_id, 
   , null /* no mapping */ --stps_rduce_prevnt_mitigte, StepsReducePreventMitigate
   , null /* no mapping */ --othr_stps_rduce_prevnt_mitigte, OtherStepsReducePreventMitigate
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SSO_INSP/ICS_SSO_SYSTM_COMP
INSERT INTO ICS_FLOW_LOCAL.ics_sso_systm_comp (
     ics_sso_systm_comp_id
   , ics_sso_insp_id
   , ics_sso_evt_rep_id
   , systm_comp
   , othr_systm_comp
   , data_hash)
SELECT 
     null /* no mapping */ --ics_sso_systm_comp_id, 
   , null /* no mapping */ --ics_sso_insp_id, 
   , null /* no mapping */ --ics_sso_evt_rep_id, 
   , null /* no mapping */ --systm_comp, SystemComponent
   , null /* no mapping */ --othr_systm_comp, OtherSystemComponent
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SW_CNST_INSP
INSERT INTO ICS_FLOW_LOCAL.ics_sw_cnst_insp (
     ics_sw_cnst_insp_id
   , ics_cmpl_mon_id
   , data_hash)
SELECT 
     null /* no mapping */ --ics_sw_cnst_insp_id, 
   , null /* no mapping */ --ics_cmpl_mon_id, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_CNST_INDST_INSP
INSERT INTO ICS_FLOW_LOCAL.ics_sw_cnst_indst_insp (
     ics_sw_cnst_indst_insp_id
   , ics_sw_cnst_insp_id
   , ics_sw_cnst_non_cnst_insp_id
   , ics_sw_non_cnst_insp_id
   , swppp_eval_basis_code
   , swppp_eval_date
   , swppp_eval_desc_txt
   , no_exposure_auth_date
   , data_hash)
SELECT 
     null /* no mapping */ --ics_sw_cnst_indst_insp_id, 
   , null /* no mapping */ --ics_sw_cnst_insp_id, 
   , null /* no mapping */ --ics_sw_cnst_non_cnst_insp_id, 
   , null /* no mapping */ --ics_sw_non_cnst_insp_id, 
   , null /* no mapping */ --swppp_eval_basis_code, SWPPPEvaluationBasisCode
   , null /* no mapping */ --swppp_eval_date, SWPPPEvaluationDate
   , null /* no mapping */ --swppp_eval_desc_txt, SWPPPEvaluationDescriptionText
   , null /* no mapping */ --no_exposure_auth_date, NoExposureAuthorizationDate
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP
INSERT INTO ICS_FLOW_LOCAL.ics_sw_unprmt_cnst_insp (
     ics_sw_unprmt_cnst_insp_id
   , ics_sw_cnst_insp_id
   , ics_sw_cnst_non_cnst_insp_id
   , ics_sw_non_cnst_insp_id
   , est_start_date
   , est_complete_date
   , est_area_disturbed_acres_num
   , proj_plan_size_code
   , data_hash)
SELECT 
     null /* no mapping */ --ics_sw_unprmt_cnst_insp_id, 
   , null /* no mapping */ --ics_sw_cnst_insp_id, 
   , null /* no mapping */ --ics_sw_cnst_non_cnst_insp_id, 
   , null /* no mapping */ --ics_sw_non_cnst_insp_id, 
   , null /* no mapping */ --est_start_date, EstimatedStartDate
   , null /* no mapping */ --est_complete_date, EstimatedCompleteDate
   , null /* no mapping */ --est_area_disturbed_acres_num, EstimatedAreaDisturbedAcresNumber
   , null /* no mapping */ --proj_plan_size_code, ProjectPlanSizeCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE
INSERT INTO ICS_FLOW_LOCAL.ics_proj_type (
     ics_proj_type_id
   , ics_sw_unprmt_cnst_insp_id
   , proj_type_code
   , proj_type_code_othr_desc
   , data_hash)
SELECT 
     null /* no mapping */ --ics_proj_type_id, 
   , null /* no mapping */ --ics_sw_unprmt_cnst_insp_id, 
   , null /* no mapping */ --proj_type_code, ProjectTypeCode
   , null /* no mapping */ --proj_type_code_othr_desc, ProjectTypeCodeOtherDescription
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP
INSERT INTO ICS_FLOW_LOCAL.ics_sw_cnst_non_cnst_insp (
     ics_sw_cnst_non_cnst_insp_id
   , ics_cmpl_mon_id
   , data_hash)
SELECT 
     null /* no mapping */ --ics_sw_cnst_non_cnst_insp_id, 
   , null /* no mapping */ --ics_cmpl_mon_id, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_CNST_INDST_INSP
INSERT INTO ICS_FLOW_LOCAL.ics_sw_cnst_indst_insp (
     ics_sw_cnst_indst_insp_id
   , ics_sw_cnst_insp_id
   , ics_sw_cnst_non_cnst_insp_id
   , ics_sw_non_cnst_insp_id
   , swppp_eval_basis_code
   , swppp_eval_date
   , swppp_eval_desc_txt
   , no_exposure_auth_date
   , data_hash)
SELECT 
     null /* no mapping */ --ics_sw_cnst_indst_insp_id, 
   , null /* no mapping */ --ics_sw_cnst_insp_id, 
   , null /* no mapping */ --ics_sw_cnst_non_cnst_insp_id, 
   , null /* no mapping */ --ics_sw_non_cnst_insp_id, 
   , null /* no mapping */ --swppp_eval_basis_code, SWPPPEvaluationBasisCode
   , null /* no mapping */ --swppp_eval_date, SWPPPEvaluationDate
   , null /* no mapping */ --swppp_eval_desc_txt, SWPPPEvaluationDescriptionText
   , null /* no mapping */ --no_exposure_auth_date, NoExposureAuthorizationDate
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP
INSERT INTO ICS_FLOW_LOCAL.ics_sw_unprmt_cnst_insp (
     ics_sw_unprmt_cnst_insp_id
   , ics_sw_cnst_insp_id
   , ics_sw_cnst_non_cnst_insp_id
   , ics_sw_non_cnst_insp_id
   , est_start_date
   , est_complete_date
   , est_area_disturbed_acres_num
   , proj_plan_size_code
   , data_hash)
SELECT 
     null /* no mapping */ --ics_sw_unprmt_cnst_insp_id, 
   , null /* no mapping */ --ics_sw_cnst_insp_id, 
   , null /* no mapping */ --ics_sw_cnst_non_cnst_insp_id, 
   , null /* no mapping */ --ics_sw_non_cnst_insp_id, 
   , null /* no mapping */ --est_start_date, EstimatedStartDate
   , null /* no mapping */ --est_complete_date, EstimatedCompleteDate
   , null /* no mapping */ --est_area_disturbed_acres_num, EstimatedAreaDisturbedAcresNumber
   , null /* no mapping */ --proj_plan_size_code, ProjectPlanSizeCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE
INSERT INTO ICS_FLOW_LOCAL.ics_proj_type (
     ics_proj_type_id
   , ics_sw_unprmt_cnst_insp_id
   , proj_type_code
   , proj_type_code_othr_desc
   , data_hash)
SELECT 
     null /* no mapping */ --ics_proj_type_id, 
   , null /* no mapping */ --ics_sw_unprmt_cnst_insp_id, 
   , null /* no mapping */ --proj_type_code, ProjectTypeCode
   , null /* no mapping */ --proj_type_code_othr_desc, ProjectTypeCodeOtherDescription
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SW_MS_4_INSP
INSERT INTO ICS_FLOW_LOCAL.ics_sw_ms_4_insp (
     ics_sw_ms_4_insp_id
   , ics_cmpl_mon_id
   , ms_4_annul_expen_dollars
   , ms_4_annul_expen_year
   , ms_4_budget_dollars
   , ms_4_budget_year
   , major_outfall_est_meas_ind
   , major_outfall_num
   , minor_outfall_est_meas_ind
   , minor_outfall_num
   , data_hash)
SELECT 
     null /* no mapping */ --ics_sw_ms_4_insp_id, 
   , null /* no mapping */ --ics_cmpl_mon_id, 
   , null /* no mapping */ --ms_4_annul_expen_dollars, MS4AnnualExpenditureDollars
   , null /* no mapping */ --ms_4_annul_expen_year, MS4AnnualExpenditureYear
   , null /* no mapping */ --ms_4_budget_dollars, MS4BudgetDollars
   , null /* no mapping */ --ms_4_budget_year, MS4BudgetYear
   , null /* no mapping */ --major_outfall_est_meas_ind, MajorOutfallEstimatedMeasureIndicator
   , null /* no mapping */ --major_outfall_num, MajorOutfallNumber
   , null /* no mapping */ --minor_outfall_est_meas_ind, MinorOutfallEstimatedMeasureIndicator
   , null /* no mapping */ --minor_outfall_num, MinorOutfallNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SW_MS_4_INSP/ICS_PROJ_SRCS_FUND
INSERT INTO ICS_FLOW_LOCAL.ics_proj_srcs_fund (
     ics_proj_srcs_fund_id
   , ics_sw_ms_4_insp_id
   , ics_swms_4_prog_rep_id
   , proj_srcs_fund_code
   , data_hash)
SELECT 
     null /* no mapping */ --ics_proj_srcs_fund_id, 
   , null /* no mapping */ --ics_sw_ms_4_insp_id, 
   , null /* no mapping */ --ics_swms_4_prog_rep_id, 
   , null /* no mapping */ --proj_srcs_fund_code, ProjectedSourcesFundingCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP
INSERT INTO ICS_FLOW_LOCAL.ics_sw_non_cnst_insp (
     ics_sw_non_cnst_insp_id
   , ics_cmpl_mon_id
   , data_hash)
SELECT 
     null /* no mapping */ --ics_sw_non_cnst_insp_id, 
   , null /* no mapping */ --ics_cmpl_mon_id, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_CNST_INDST_INSP
INSERT INTO ICS_FLOW_LOCAL.ics_sw_cnst_indst_insp (
     ics_sw_cnst_indst_insp_id
   , ics_sw_cnst_insp_id
   , ics_sw_cnst_non_cnst_insp_id
   , ics_sw_non_cnst_insp_id
   , swppp_eval_basis_code
   , swppp_eval_date
   , swppp_eval_desc_txt
   , no_exposure_auth_date
   , data_hash)
SELECT 
     null /* no mapping */ --ics_sw_cnst_indst_insp_id, 
   , null /* no mapping */ --ics_sw_cnst_insp_id, 
   , null /* no mapping */ --ics_sw_cnst_non_cnst_insp_id, 
   , null /* no mapping */ --ics_sw_non_cnst_insp_id, 
   , null /* no mapping */ --swppp_eval_basis_code, SWPPPEvaluationBasisCode
   , null /* no mapping */ --swppp_eval_date, SWPPPEvaluationDate
   , null /* no mapping */ --swppp_eval_desc_txt, SWPPPEvaluationDescriptionText
   , null /* no mapping */ --no_exposure_auth_date, NoExposureAuthorizationDate
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP
INSERT INTO ICS_FLOW_LOCAL.ics_sw_unprmt_cnst_insp (
     ics_sw_unprmt_cnst_insp_id
   , ics_sw_cnst_insp_id
   , ics_sw_cnst_non_cnst_insp_id
   , ics_sw_non_cnst_insp_id
   , est_start_date
   , est_complete_date
   , est_area_disturbed_acres_num
   , proj_plan_size_code
   , data_hash)
SELECT 
     null /* no mapping */ --ics_sw_unprmt_cnst_insp_id, 
   , null /* no mapping */ --ics_sw_cnst_insp_id, 
   , null /* no mapping */ --ics_sw_cnst_non_cnst_insp_id, 
   , null /* no mapping */ --ics_sw_non_cnst_insp_id, 
   , null /* no mapping */ --est_start_date, EstimatedStartDate
   , null /* no mapping */ --est_complete_date, EstimatedCompleteDate
   , null /* no mapping */ --est_area_disturbed_acres_num, EstimatedAreaDisturbedAcresNumber
   , null /* no mapping */ --proj_plan_size_code, ProjectPlanSizeCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE
INSERT INTO ICS_FLOW_LOCAL.ics_proj_type (
     ics_proj_type_id
   , ics_sw_unprmt_cnst_insp_id
   , proj_type_code
   , proj_type_code_othr_desc
   , data_hash)
SELECT 
     null /* no mapping */ --ics_proj_type_id, 
   , null /* no mapping */ --ics_sw_unprmt_cnst_insp_id, 
   , null /* no mapping */ --proj_type_code, ProjectTypeCode
   , null /* no mapping */ --proj_type_code_othr_desc, ProjectTypeCodeOtherDescription
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

END;
