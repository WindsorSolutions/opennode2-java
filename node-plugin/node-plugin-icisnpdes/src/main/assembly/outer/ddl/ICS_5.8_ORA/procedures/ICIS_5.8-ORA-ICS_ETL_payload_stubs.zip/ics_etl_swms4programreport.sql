﻿
/*************************************************************************************************
** ObjectName: ics_etl_swms4programreport
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the SWMS4ProgramReportSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_swms4programreport

AS

BEGIN
---------------------------- 
-- ICS_SWMS_4_PROG_REP
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ics_swms_4_prog_rep;


-- /ICS_SWMS_4_PROG_REP
INSERT INTO ICS_FLOW_LOCAL.ics_swms_4_prog_rep (
     ics_swms_4_prog_rep_id
   , ics_payload_id
   , src_systm_ident
   , transaction_type
   , transaction_timestamp
   , prmt_ident
   , sw_ms_4_rep_rcvd_date
   , ms_4_annul_expen_dollars
   , ms_4_annul_expen_year
   , ms_4_budget_dollars
   , ms_4_budget_year
   , major_outfall_est_meas_ind
   , major_outfall_num
   , minor_outfall_est_meas_ind
   , minor_outfall_num
   , key_hash
   , data_hash)
SELECT 
     null /* no mapping */ --ics_swms_4_prog_rep_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --sw_ms_4_rep_rcvd_date, StormWaterMS4ReportReceivedDate
   , null /* no mapping */ --ms_4_annul_expen_dollars, MS4AnnualExpenditureDollars
   , null /* no mapping */ --ms_4_annul_expen_year, MS4AnnualExpenditureYear
   , null /* no mapping */ --ms_4_budget_dollars, MS4BudgetDollars
   , null /* no mapping */ --ms_4_budget_year, MS4BudgetYear
   , null /* no mapping */ --major_outfall_est_meas_ind, MajorOutfallEstimatedMeasureIndicator
   , null /* no mapping */ --major_outfall_num, MajorOutfallNumber
   , null /* no mapping */ --minor_outfall_est_meas_ind, MinorOutfallEstimatedMeasureIndicator
   , null /* no mapping */ --minor_outfall_num, MinorOutfallNumber
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SWMS_4_PROG_REP/ICS_ADDR
INSERT INTO ICS_FLOW_LOCAL.ics_addr (
     ics_addr_id
   , ics_fac_id
   , ics_basic_prmt_id
   , ics_prmt_featr_id
   , ics_bs_mgmt_practices_id
   , ics_bs_prmt_id
   , ics_cafo_prmt_id
   , ics_gnrl_prmt_id
   , ics_sw_cnst_prmt_id
   , ics_sw_evt_rep_id
   , ics_sw_indst_prmt_id
   , ics_swms_4_large_prmt_id
   , ics_swms_4_prog_rep_id
   , ics_swms_4_small_prmt_id
   , ics_unprmt_fac_id
   , affil_type_txt
   , org_frml_name
   , org_duns_num
   , mailing_addr_txt
   , suppl_addr_txt
   , mailing_addr_city_name
   , mailing_addr_st_code
   , mailing_addr_zip_code
   , county_name
   , mailing_addr_country_code
   , division_name
   , loc_province
   , elec_addr_txt
   , start_date_of_addr_assc
   , end_date_of_addr_assc
   , data_hash)
SELECT 
     null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --ics_bs_mgmt_practices_id, 
   , null /* no mapping */ --ics_bs_prmt_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_sw_cnst_prmt_id, 
   , null /* no mapping */ --ics_sw_evt_rep_id, 
   , null /* no mapping */ --ics_sw_indst_prmt_id, 
   , null /* no mapping */ --ics_swms_4_large_prmt_id, 
   , null /* no mapping */ --ics_swms_4_prog_rep_id, 
   , null /* no mapping */ --ics_swms_4_small_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --affil_type_txt, AffiliationTypeText
   , null /* no mapping */ --org_frml_name, OrganizationFormalName
   , null /* no mapping */ --org_duns_num, OrganizationDUNSNumber
   , null /* no mapping */ --mailing_addr_txt, MailingAddressText
   , null /* no mapping */ --suppl_addr_txt, SupplementalAddressText
   , null /* no mapping */ --mailing_addr_city_name, MailingAddressCityName
   , null /* no mapping */ --mailing_addr_st_code, MailingAddressStateCode
   , null /* no mapping */ --mailing_addr_zip_code, MailingAddressZipCode
   , null /* no mapping */ --county_name, CountyName
   , null /* no mapping */ --mailing_addr_country_code, MailingAddressCountryCode
   , null /* no mapping */ --division_name, DivisionName
   , null /* no mapping */ --loc_province, LocationProvince
   , null /* no mapping */ --elec_addr_txt, ElectronicAddressText
   , null /* no mapping */ --start_date_of_addr_assc, StartDateOfAddressAssociation
   , null /* no mapping */ --end_date_of_addr_assc, EndDateOfAddressAssociation
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SWMS_4_PROG_REP/ICS_ADDR/ICS_TELEPH
INSERT INTO ICS_FLOW_LOCAL.ics_teleph (
     ics_teleph_id
   , ics_contact_id
   , ics_addr_id
   , ics_efflu_trade_prtner_addr_id
   , teleph_num_type_code
   , teleph_num
   , teleph_ext_num
   , data_hash)
SELECT 
     null /* no mapping */ --ics_teleph_id, 
   , null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_efflu_trade_prtner_addr_id, 
   , null /* no mapping */ --teleph_num_type_code, TelephoneNumberTypeCode
   , null /* no mapping */ --teleph_num, TelephoneNumber
   , null /* no mapping */ --teleph_ext_num, TelephoneExtensionNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SWMS_4_PROG_REP/ICS_CONTACT
INSERT INTO ICS_FLOW_LOCAL.ics_contact (
     ics_contact_id
   , ics_fac_id
   , ics_basic_prmt_id
   , ics_prmt_featr_id
   , ics_bs_mgmt_practices_id
   , ics_bs_annul_prog_rep_id
   , ics_bs_prmt_id
   , ics_cafo_prmt_id
   , ics_cmpl_mon_id
   , ics_gnrl_prmt_id
   , ics_master_gnrl_prmt_id
   , ics_pretr_prmt_id
   , ics_sw_cnst_prmt_id
   , ics_sw_evt_rep_id
   , ics_sw_indst_prmt_id
   , ics_swms_4_large_prmt_id
   , ics_swms_4_prog_rep_id
   , ics_swms_4_small_prmt_id
   , ics_unprmt_fac_id
   , affil_type_txt
   , first_name
   , middle_name
   , last_name
   , indvl_title_txt
   , org_frml_name
   , st_code
   , rgn_code
   , elec_addr_txt
   , start_date_of_contact_assc
   , end_date_of_contact_assc
   , data_hash)
SELECT 
     null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --ics_bs_mgmt_practices_id, 
   , null /* no mapping */ --ics_bs_annul_prog_rep_id, 
   , null /* no mapping */ --ics_bs_prmt_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_cmpl_mon_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_master_gnrl_prmt_id, 
   , null /* no mapping */ --ics_pretr_prmt_id, 
   , null /* no mapping */ --ics_sw_cnst_prmt_id, 
   , null /* no mapping */ --ics_sw_evt_rep_id, 
   , null /* no mapping */ --ics_sw_indst_prmt_id, 
   , null /* no mapping */ --ics_swms_4_large_prmt_id, 
   , null /* no mapping */ --ics_swms_4_prog_rep_id, 
   , null /* no mapping */ --ics_swms_4_small_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --affil_type_txt, AffiliationTypeText
   , null /* no mapping */ --first_name, FirstName
   , null /* no mapping */ --middle_name, MiddleName
   , null /* no mapping */ --last_name, LastName
   , null /* no mapping */ --indvl_title_txt, IndividualTitleText
   , null /* no mapping */ --org_frml_name, OrganizationFormalName
   , null /* no mapping */ --st_code, StateCode
   , null /* no mapping */ --rgn_code, RegionCode
   , null /* no mapping */ --elec_addr_txt, ElectronicAddressText
   , null /* no mapping */ --start_date_of_contact_assc, StartDateOfContactAssociation
   , null /* no mapping */ --end_date_of_contact_assc, EndDateOfContactAssociation
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SWMS_4_PROG_REP/ICS_CONTACT/ICS_TELEPH
INSERT INTO ICS_FLOW_LOCAL.ics_teleph (
     ics_teleph_id
   , ics_contact_id
   , ics_addr_id
   , ics_efflu_trade_prtner_addr_id
   , teleph_num_type_code
   , teleph_num
   , teleph_ext_num
   , data_hash)
SELECT 
     null /* no mapping */ --ics_teleph_id, 
   , null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_efflu_trade_prtner_addr_id, 
   , null /* no mapping */ --teleph_num_type_code, TelephoneNumberTypeCode
   , null /* no mapping */ --teleph_num, TelephoneNumber
   , null /* no mapping */ --teleph_ext_num, TelephoneExtensionNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SWMS_4_PROG_REP/ICS_PROJ_SRCS_FUND
INSERT INTO ICS_FLOW_LOCAL.ics_proj_srcs_fund (
     ics_proj_srcs_fund_id
   , ics_sw_ms_4_insp_id
   , ics_swms_4_prog_rep_id
   , proj_srcs_fund_code
   , data_hash)
SELECT 
     null /* no mapping */ --ics_proj_srcs_fund_id, 
   , null /* no mapping */ --ics_sw_ms_4_insp_id, 
   , null /* no mapping */ --ics_swms_4_prog_rep_id, 
   , null /* no mapping */ --proj_srcs_fund_code, ProjectedSourcesFundingCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

END;
