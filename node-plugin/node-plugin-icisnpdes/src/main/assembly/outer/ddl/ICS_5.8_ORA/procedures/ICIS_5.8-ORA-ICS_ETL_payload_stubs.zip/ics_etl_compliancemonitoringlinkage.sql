﻿
/*************************************************************************************************
** ObjectName: ics_etl_compliancemonitoringlinkage
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the ComplianceMonitoringLinkageSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_compliancemonitoringlinkage

AS

BEGIN
---------------------------- 
-- ICS_CMPL_MON_LNK
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ics_cmpl_mon_lnk;


-- /ICS_CMPL_MON_LNK
INSERT INTO ICS_FLOW_LOCAL.ics_cmpl_mon_lnk (
     ics_cmpl_mon_lnk_id
   , ics_payload_id
   , src_systm_ident
   , transaction_type
   , transaction_timestamp
   , cmpl_mon_ident
   , key_hash
   , data_hash)
SELECT 
     null /* no mapping */ --ics_cmpl_mon_lnk_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --cmpl_mon_ident, ComplianceMonitoringIdentifier
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON_LNK/ICS_LNK_BS_REP
INSERT INTO ICS_FLOW_LOCAL.ics_lnk_bs_rep (
     ics_lnk_bs_rep_id
   , ics_cmpl_mon_lnk_id
   , ics_dmr_prog_rep_lnk_id
   , prmt_ident
   , rep_coverage_end_date
   , data_hash)
SELECT 
     null /* no mapping */ --ics_lnk_bs_rep_id, 
   , null /* no mapping */ --ics_cmpl_mon_lnk_id, 
   , null /* no mapping */ --ics_dmr_prog_rep_lnk_id, 
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --rep_coverage_end_date, ReportCoverageEndDate
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON_LNK/ICS_LNK_CAFO_ANNUL_REP
INSERT INTO ICS_FLOW_LOCAL.ics_lnk_cafo_annul_rep (
     ics_lnk_cafo_annul_rep_id
   , ics_cmpl_mon_lnk_id
   , prmt_ident
   , prmt_auth_rep_rcvd_date
   , data_hash)
SELECT 
     null /* no mapping */ --ics_lnk_cafo_annul_rep_id, 
   , null /* no mapping */ --ics_cmpl_mon_lnk_id, 
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --prmt_auth_rep_rcvd_date, PermittingAuthorityReportReceivedDate
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON_LNK/ICS_LNK_CSO_EVT_REP
INSERT INTO ICS_FLOW_LOCAL.ics_lnk_cso_evt_rep (
     ics_lnk_cso_evt_rep_id
   , ics_cmpl_mon_lnk_id
   , prmt_ident
   , cso_evt_date
   , cso_evt_id
   , data_hash)
SELECT 
     null /* no mapping */ --ics_lnk_cso_evt_rep_id, 
   , null /* no mapping */ --ics_cmpl_mon_lnk_id, 
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --cso_evt_date, CSOEventDate
   , null /* no mapping */ --cso_evt_id, CSOEventID
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON_LNK/ICS_LNK_ENFRC_ACTN
INSERT INTO ICS_FLOW_LOCAL.ics_lnk_enfrc_actn (
     ics_lnk_enfrc_actn_id
   , ics_cmpl_mon_lnk_id
   , enfrc_actn_ident
   , data_hash)
SELECT 
     null /* no mapping */ --ics_lnk_enfrc_actn_id, 
   , null /* no mapping */ --ics_cmpl_mon_lnk_id, 
   , null /* no mapping */ --enfrc_actn_ident, EnforcementActionIdentifier
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON_LNK/ICS_LNK_FEDR_CMPL_MON
INSERT INTO ICS_FLOW_LOCAL.ics_lnk_fedr_cmpl_mon (
     ics_lnk_fedr_cmpl_mon_id
   , ics_cmpl_mon_lnk_id
   , prog_systm_acronym
   , prog_systm_ident
   , fedr_statute_code
   , cmpl_mon_acty_type_code
   , cmpl_mon_catg_code
   , cmpl_mon_date
   , data_hash)
SELECT 
     null /* no mapping */ --ics_lnk_fedr_cmpl_mon_id, 
   , null /* no mapping */ --ics_cmpl_mon_lnk_id, 
   , null /* no mapping */ --prog_systm_acronym, ProgramSystemAcronym
   , null /* no mapping */ --prog_systm_ident, ProgramSystemIdentifier
   , null /* no mapping */ --fedr_statute_code, FederalStatuteCode
   , null /* no mapping */ --cmpl_mon_acty_type_code, ComplianceMonitoringActivityTypeCode
   , null /* no mapping */ --cmpl_mon_catg_code, ComplianceMonitoringCategoryCode
   , null /* no mapping */ --cmpl_mon_date, ComplianceMonitoringDate
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON_LNK/ICS_LNK_LOC_LMTS_REP
INSERT INTO ICS_FLOW_LOCAL.ics_lnk_loc_lmts_rep (
     ics_lnk_loc_lmts_rep_id
   , ics_cmpl_mon_lnk_id
   , prmt_ident
   , prmt_auth_rep_rcvd_date
   , data_hash)
SELECT 
     null /* no mapping */ --ics_lnk_loc_lmts_rep_id, 
   , null /* no mapping */ --ics_cmpl_mon_lnk_id, 
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --prmt_auth_rep_rcvd_date, PermittingAuthorityReportReceivedDate
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON_LNK/ICS_LNK_PRETR_PERF_REP
INSERT INTO ICS_FLOW_LOCAL.ics_lnk_pretr_perf_rep (
     ics_lnk_pretr_perf_rep_id
   , ics_cmpl_mon_lnk_id
   , prmt_ident
   , pretr_perf_summ_end_date
   , data_hash)
SELECT 
     null /* no mapping */ --ics_lnk_pretr_perf_rep_id, 
   , null /* no mapping */ --ics_cmpl_mon_lnk_id, 
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --pretr_perf_summ_end_date, PretreatmentPerformanceSummaryEndDate
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON_LNK/ICS_LNK_SNGL_EVT
INSERT INTO ICS_FLOW_LOCAL.ics_lnk_sngl_evt (
     ics_lnk_sngl_evt_id
   , ics_cmpl_mon_lnk_id
   , prmt_ident
   , sngl_evt_viol_code
   , sngl_evt_viol_date
   , data_hash)
SELECT 
     null /* no mapping */ --ics_lnk_sngl_evt_id, 
   , null /* no mapping */ --ics_cmpl_mon_lnk_id, 
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --sngl_evt_viol_code, SingleEventViolationCode
   , null /* no mapping */ --sngl_evt_viol_date, SingleEventViolationDate
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON_LNK/ICS_LNK_SSO_ANNUL_REP
INSERT INTO ICS_FLOW_LOCAL.ics_lnk_sso_annul_rep (
     ics_lnk_sso_annul_rep_id
   , ics_cmpl_mon_lnk_id
   , prmt_ident
   , sso_annul_rep_rcvd_date
   , data_hash)
SELECT 
     null /* no mapping */ --ics_lnk_sso_annul_rep_id, 
   , null /* no mapping */ --ics_cmpl_mon_lnk_id, 
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --sso_annul_rep_rcvd_date, SSOAnnualReportReceivedDate
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON_LNK/ICS_LNK_SSO_EVT_REP
INSERT INTO ICS_FLOW_LOCAL.ics_lnk_sso_evt_rep (
     ics_lnk_sso_evt_rep_id
   , ics_cmpl_mon_lnk_id
   , prmt_ident
   , sso_evt_date
   , sso_evt_id
   , data_hash)
SELECT 
     null /* no mapping */ --ics_lnk_sso_evt_rep_id, 
   , null /* no mapping */ --ics_cmpl_mon_lnk_id, 
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --sso_evt_date, SSOEventDate
   , null /* no mapping */ --sso_evt_id, SSOEventID
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON_LNK/ICS_LNK_SSO_MONTHLY_EVT_REP
INSERT INTO ICS_FLOW_LOCAL.ics_lnk_sso_monthly_evt_rep (
     ics_lnk_sso_monthly_evt_rep_id
   , ics_cmpl_mon_lnk_id
   , prmt_ident
   , sso_monthly_rep_rcvd_date
   , data_hash)
SELECT 
     null /* no mapping */ --ics_lnk_sso_monthly_evt_rep_id, 
   , null /* no mapping */ --ics_cmpl_mon_lnk_id, 
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --sso_monthly_rep_rcvd_date, SSOMonthlyReportReceivedDate
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON_LNK/ICS_LNK_ST_CMPL_MON
INSERT INTO ICS_FLOW_LOCAL.ics_lnk_st_cmpl_mon (
     ics_lnk_st_cmpl_mon_id
   , ics_cmpl_mon_lnk_id
   , cmpl_mon_ident
   , data_hash)
SELECT 
     null /* no mapping */ --ics_lnk_st_cmpl_mon_id, 
   , null /* no mapping */ --ics_cmpl_mon_lnk_id, 
   , null /* no mapping */ --cmpl_mon_ident, ComplianceMonitoringIdentifier
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON_LNK/ICS_LNK_SW_EVT_REP
INSERT INTO ICS_FLOW_LOCAL.ics_lnk_sw_evt_rep (
     ics_lnk_sw_evt_rep_id
   , ics_cmpl_mon_lnk_id
   , ics_dmr_prog_rep_lnk_id
   , prmt_ident
   , date_strm_evt_smpl
   , sw_evt_id
   , data_hash)
SELECT 
     null /* no mapping */ --ics_lnk_sw_evt_rep_id, 
   , null /* no mapping */ --ics_cmpl_mon_lnk_id, 
   , null /* no mapping */ --ics_dmr_prog_rep_lnk_id, 
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --date_strm_evt_smpl, DateStormEventSampled
   , null /* no mapping */ --sw_evt_id, SWEventID
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON_LNK/ICS_LNK_SWMS_4_REP
INSERT INTO ICS_FLOW_LOCAL.ics_lnk_swms_4_rep (
     ics_lnk_swms_4_rep_id
   , ics_cmpl_mon_lnk_id
   , prmt_ident
   , sw_ms_4_rep_rcvd_date
   , data_hash)
SELECT 
     null /* no mapping */ --ics_lnk_swms_4_rep_id, 
   , null /* no mapping */ --ics_cmpl_mon_lnk_id, 
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --sw_ms_4_rep_rcvd_date, StormWaterMS4ReportReceivedDate
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

END;
