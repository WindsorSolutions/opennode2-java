﻿
/*************************************************************************************************
** ObjectName: ics_etl_informalenforcementaction
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the InformalEnforcementActionSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_informalenforcementaction

AS

BEGIN
---------------------------- 
-- ICS_INFRML_ENFRC_ACTN
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ics_infrml_enfrc_actn;


-- /ICS_INFRML_ENFRC_ACTN
INSERT INTO ICS_FLOW_LOCAL.ics_infrml_enfrc_actn (
     ics_infrml_enfrc_actn_id
   , ics_payload_id
   , src_systm_ident
   , transaction_type
   , transaction_timestamp
   , enfrc_actn_ident
   , enfrc_actn_type_code
   , enfrc_actn_name
   , achieved_date
   , file_num
   , reason_deleting_record
   , infrml_ea_cmnt_txt
   , infrml_ea_usr_dfnd_fld_1
   , infrml_ea_usr_dfnd_fld_2
   , infrml_ea_usr_dfnd_fld_3
   , infrml_ea_usr_dfnd_fld_4
   , infrml_ea_usr_dfnd_fld_5
   , infrml_ea_usr_dfnd_fld_6
   , enfrc_agncy_name
   , key_hash
   , data_hash)
SELECT 
     null /* no mapping */ --ics_infrml_enfrc_actn_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --enfrc_actn_ident, EnforcementActionIdentifier
   , null /* no mapping */ --enfrc_actn_type_code, EnforcementActionTypeCode
   , null /* no mapping */ --enfrc_actn_name, EnforcementActionName
   , null /* no mapping */ --achieved_date, AchievedDate
   , null /* no mapping */ --file_num, FileNumber
   , null /* no mapping */ --reason_deleting_record, ReasonDeletingRecord
   , null /* no mapping */ --infrml_ea_cmnt_txt, InformalEACommentText
   , null /* no mapping */ --infrml_ea_usr_dfnd_fld_1, InformalEAUserDefinedField1
   , null /* no mapping */ --infrml_ea_usr_dfnd_fld_2, InformalEAUserDefinedField2
   , null /* no mapping */ --infrml_ea_usr_dfnd_fld_3, InformalEAUserDefinedField3
   , null /* no mapping */ --infrml_ea_usr_dfnd_fld_4, InformalEAUserDefinedField4
   , null /* no mapping */ --infrml_ea_usr_dfnd_fld_5, InformalEAUserDefinedField5
   , null /* no mapping */ --infrml_ea_usr_dfnd_fld_6, InformalEAUserDefinedField6
   , null /* no mapping */ --enfrc_agncy_name, EnforcementAgencyName
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_INFRML_ENFRC_ACTN/ICS_ENFRC_ACTN_GOV_CONTACT
INSERT INTO ICS_FLOW_LOCAL.ics_enfrc_actn_gov_contact (
     ics_enfrc_actn_gov_contact_id
   , ics_frml_enfrc_actn_id
   , ics_infrml_enfrc_actn_id
   , affil_type_txt
   , elec_addr_txt
   , start_date_of_contact_assc
   , end_date_of_contact_assc
   , data_hash)
SELECT 
     null /* no mapping */ --ics_enfrc_actn_gov_contact_id, 
   , null /* no mapping */ --ics_frml_enfrc_actn_id, 
   , null /* no mapping */ --ics_infrml_enfrc_actn_id, 
   , null /* no mapping */ --affil_type_txt, AffiliationTypeText
   , null /* no mapping */ --elec_addr_txt, ElectronicAddressText
   , null /* no mapping */ --start_date_of_contact_assc, StartDateOfContactAssociation
   , null /* no mapping */ --end_date_of_contact_assc, EndDateOfContactAssociation
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_INFRML_ENFRC_ACTN/ICS_ENFRC_AGNCY
INSERT INTO ICS_FLOW_LOCAL.ics_enfrc_agncy (
     ics_enfrc_agncy_id
   , ics_frml_enfrc_actn_id
   , ics_infrml_enfrc_actn_id
   , enfrc_agncy_type_code
   , agncy_lead_ind
   , data_hash)
SELECT 
     null /* no mapping */ --ics_enfrc_agncy_id, 
   , null /* no mapping */ --ics_frml_enfrc_actn_id, 
   , null /* no mapping */ --ics_infrml_enfrc_actn_id, 
   , null /* no mapping */ --enfrc_agncy_type_code, EnforcementAgencyTypeCode
   , null /* no mapping */ --agncy_lead_ind, AgencyLeadIndicator
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_INFRML_ENFRC_ACTN/ICS_PRMT_IDENT
INSERT INTO ICS_FLOW_LOCAL.ics_prmt_ident (
     ics_prmt_ident_id
   , ics_frml_enfrc_actn_id
   , ics_infrml_enfrc_actn_id
   , prmt_ident
   , data_hash)
SELECT 
     null /* no mapping */ --ics_prmt_ident_id, 
   , null /* no mapping */ --ics_frml_enfrc_actn_id, 
   , null /* no mapping */ --ics_infrml_enfrc_actn_id, 
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_INFRML_ENFRC_ACTN/ICS_PROGS_VIOL
INSERT INTO ICS_FLOW_LOCAL.ics_progs_viol (
     ics_progs_viol_id
   , ics_frml_enfrc_actn_id
   , ics_infrml_enfrc_actn_id
   , progs_viol_code
   , data_hash)
SELECT 
     null /* no mapping */ --ics_progs_viol_id, 
   , null /* no mapping */ --ics_frml_enfrc_actn_id, 
   , null /* no mapping */ --ics_infrml_enfrc_actn_id, 
   , null /* no mapping */ --progs_viol_code, ProgramsViolatedCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

END;
