﻿
/*************************************************************************************************
** ObjectName: ics_etl_swconstructionpermit
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the SWConstructionPermitSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_swconstructionpermit

AS

BEGIN
---------------------------- 
-- ICS_SW_CNST_PRMT
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ics_sw_cnst_prmt;


-- /ICS_SW_CNST_PRMT
INSERT INTO ICS_FLOW_LOCAL.ics_sw_cnst_prmt (
     ics_sw_cnst_prmt_id
   , ics_payload_id
   , src_systm_ident
   , transaction_type
   , transaction_timestamp
   , prmt_ident
   , st_wtr_body_name
   , rcvg_ms_4_name
   , impaired_wtr_ind
   , hist_prop_ind
   , hist_prop_crit_met_code
   , species_crit_habitat_ind
   , species_crit_met_code
   , indst_acty_size
   , cnst_site_othr_txt
   , proj_type_code
   , est_start_date
   , est_complete_date
   , est_area_disturbed_acres_num
   , proj_plan_size_code
   , strct_demoed_ind
   , strct_demoed_floor_space_ind
   , predev_land_use_ind
   , erth_distrb_activities_ind
   , erth_distrb_emrgcy_ind
   , previous_sw_dsch_ind
   , othr_prmt_ident
   , cgp_ind
   , ms_4_dsch_ind
   , wtr_prox_ind
   , antideg_ind
   , trtmnt_chems_ind
   , cationic_chems_ind
   , cationic_chems_auth_ind
   , swppp_prep_ind
   , sbsrfc_erth_dstrbn_ind
   , prior_surveys_evals_ind
   , sbsrfc_erth_dstrbn_control_ind
   , key_hash
   , data_hash)
SELECT 
     null /* no mapping */ --ics_sw_cnst_prmt_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --st_wtr_body_name, StateWaterBodyName
   , null /* no mapping */ --rcvg_ms_4_name, ReceivingMS4Name
   , null /* no mapping */ --impaired_wtr_ind, ImpairedWaterIndicator
   , null /* no mapping */ --hist_prop_ind, HistoricPropertyIndicator
   , null /* no mapping */ --hist_prop_crit_met_code, HistoricPropertyCriterionMetCode
   , null /* no mapping */ --species_crit_habitat_ind, SpeciesCriticalHabitatIndicator
   , null /* no mapping */ --species_crit_met_code, SpeciesCriterionMetCode
   , null /* no mapping */ --indst_acty_size, IndustrialActivitySize
   , null /* no mapping */ --cnst_site_othr_txt, ConstructionSiteOtherText
   , null /* no mapping */ --proj_type_code, ProjectTypeCode
   , null /* no mapping */ --est_start_date, EstimatedStartDate
   , null /* no mapping */ --est_complete_date, EstimatedCompleteDate
   , null /* no mapping */ --est_area_disturbed_acres_num, EstimatedAreaDisturbedAcresNumber
   , null /* no mapping */ --proj_plan_size_code, ProjectPlanSizeCode
   , null /* no mapping */ --strct_demoed_ind, StructureDemolishedIndicator
   , null /* no mapping */ --strct_demoed_floor_space_ind, StructureDemolishedFloorSpaceIndicator
   , null /* no mapping */ --predev_land_use_ind, PredevelopmentLandUseIndicator
   , null /* no mapping */ --erth_distrb_activities_ind, EarthDisturbingActivitiesIndicator
   , null /* no mapping */ --erth_distrb_emrgcy_ind, EarthDisturbingEmergencyIndicator
   , null /* no mapping */ --previous_sw_dsch_ind, PreviousStormwaterDischargesIndicator
   , null /* no mapping */ --othr_prmt_ident, OtherPermitIdentifier
   , null /* no mapping */ --cgp_ind, CGPIndicator
   , null /* no mapping */ --ms_4_dsch_ind, MS4DischargeIndicator
   , null /* no mapping */ --wtr_prox_ind, WaterProximityIndicator
   , null /* no mapping */ --antideg_ind, AntidegradationIndicator
   , null /* no mapping */ --trtmnt_chems_ind, TreatmentChemicalsIndicator
   , null /* no mapping */ --cationic_chems_ind, CationicChemicalsIndicator
   , null /* no mapping */ --cationic_chems_auth_ind, CationicChemicalsAuthorizationIndicator
   , null /* no mapping */ --swppp_prep_ind, SWPPPPreparedIndicator
   , null /* no mapping */ --sbsrfc_erth_dstrbn_ind, SubsurfaceEarthDisturbanceIndicator
   , null /* no mapping */ --prior_surveys_evals_ind, PriorSurveysEvaluationsIndicator
   , null /* no mapping */ --sbsrfc_erth_dstrbn_control_ind, SubsurfaceEarthDisturbanceControlIndicator
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SW_CNST_PRMT/ICS_ADDR
INSERT INTO ICS_FLOW_LOCAL.ics_addr (
     ics_addr_id
   , ics_fac_id
   , ics_basic_prmt_id
   , ics_prmt_featr_id
   , ics_bs_mgmt_practices_id
   , ics_bs_prmt_id
   , ics_cafo_prmt_id
   , ics_gnrl_prmt_id
   , ics_sw_cnst_prmt_id
   , ics_sw_evt_rep_id
   , ics_sw_indst_prmt_id
   , ics_swms_4_large_prmt_id
   , ics_swms_4_prog_rep_id
   , ics_swms_4_small_prmt_id
   , ics_unprmt_fac_id
   , affil_type_txt
   , org_frml_name
   , org_duns_num
   , mailing_addr_txt
   , suppl_addr_txt
   , mailing_addr_city_name
   , mailing_addr_st_code
   , mailing_addr_zip_code
   , county_name
   , mailing_addr_country_code
   , division_name
   , loc_province
   , elec_addr_txt
   , start_date_of_addr_assc
   , end_date_of_addr_assc
   , data_hash)
SELECT 
     null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --ics_bs_mgmt_practices_id, 
   , null /* no mapping */ --ics_bs_prmt_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_sw_cnst_prmt_id, 
   , null /* no mapping */ --ics_sw_evt_rep_id, 
   , null /* no mapping */ --ics_sw_indst_prmt_id, 
   , null /* no mapping */ --ics_swms_4_large_prmt_id, 
   , null /* no mapping */ --ics_swms_4_prog_rep_id, 
   , null /* no mapping */ --ics_swms_4_small_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --affil_type_txt, AffiliationTypeText
   , null /* no mapping */ --org_frml_name, OrganizationFormalName
   , null /* no mapping */ --org_duns_num, OrganizationDUNSNumber
   , null /* no mapping */ --mailing_addr_txt, MailingAddressText
   , null /* no mapping */ --suppl_addr_txt, SupplementalAddressText
   , null /* no mapping */ --mailing_addr_city_name, MailingAddressCityName
   , null /* no mapping */ --mailing_addr_st_code, MailingAddressStateCode
   , null /* no mapping */ --mailing_addr_zip_code, MailingAddressZipCode
   , null /* no mapping */ --county_name, CountyName
   , null /* no mapping */ --mailing_addr_country_code, MailingAddressCountryCode
   , null /* no mapping */ --division_name, DivisionName
   , null /* no mapping */ --loc_province, LocationProvince
   , null /* no mapping */ --elec_addr_txt, ElectronicAddressText
   , null /* no mapping */ --start_date_of_addr_assc, StartDateOfAddressAssociation
   , null /* no mapping */ --end_date_of_addr_assc, EndDateOfAddressAssociation
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SW_CNST_PRMT/ICS_ADDR/ICS_TELEPH
INSERT INTO ICS_FLOW_LOCAL.ics_teleph (
     ics_teleph_id
   , ics_contact_id
   , ics_addr_id
   , ics_efflu_trade_prtner_addr_id
   , teleph_num_type_code
   , teleph_num
   , teleph_ext_num
   , data_hash)
SELECT 
     null /* no mapping */ --ics_teleph_id, 
   , null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_efflu_trade_prtner_addr_id, 
   , null /* no mapping */ --teleph_num_type_code, TelephoneNumberTypeCode
   , null /* no mapping */ --teleph_num, TelephoneNumber
   , null /* no mapping */ --teleph_ext_num, TelephoneExtensionNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SW_CNST_PRMT/ICS_CNST_SITE
INSERT INTO ICS_FLOW_LOCAL.ics_cnst_site (
     ics_cnst_site_id
   , ics_sw_cnst_prmt_id
   , cnst_site_code
   , data_hash)
SELECT 
     null /* no mapping */ --ics_cnst_site_id, 
   , null /* no mapping */ --ics_sw_cnst_prmt_id, 
   , null /* no mapping */ --cnst_site_code, ConstructionSiteCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SW_CNST_PRMT/ICS_CONTACT
INSERT INTO ICS_FLOW_LOCAL.ics_contact (
     ics_contact_id
   , ics_fac_id
   , ics_basic_prmt_id
   , ics_prmt_featr_id
   , ics_bs_mgmt_practices_id
   , ics_bs_annul_prog_rep_id
   , ics_bs_prmt_id
   , ics_cafo_prmt_id
   , ics_cmpl_mon_id
   , ics_gnrl_prmt_id
   , ics_master_gnrl_prmt_id
   , ics_pretr_prmt_id
   , ics_sw_cnst_prmt_id
   , ics_sw_evt_rep_id
   , ics_sw_indst_prmt_id
   , ics_swms_4_large_prmt_id
   , ics_swms_4_prog_rep_id
   , ics_swms_4_small_prmt_id
   , ics_unprmt_fac_id
   , affil_type_txt
   , first_name
   , middle_name
   , last_name
   , indvl_title_txt
   , org_frml_name
   , st_code
   , rgn_code
   , elec_addr_txt
   , start_date_of_contact_assc
   , end_date_of_contact_assc
   , data_hash)
SELECT 
     null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --ics_bs_mgmt_practices_id, 
   , null /* no mapping */ --ics_bs_annul_prog_rep_id, 
   , null /* no mapping */ --ics_bs_prmt_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_cmpl_mon_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_master_gnrl_prmt_id, 
   , null /* no mapping */ --ics_pretr_prmt_id, 
   , null /* no mapping */ --ics_sw_cnst_prmt_id, 
   , null /* no mapping */ --ics_sw_evt_rep_id, 
   , null /* no mapping */ --ics_sw_indst_prmt_id, 
   , null /* no mapping */ --ics_swms_4_large_prmt_id, 
   , null /* no mapping */ --ics_swms_4_prog_rep_id, 
   , null /* no mapping */ --ics_swms_4_small_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --affil_type_txt, AffiliationTypeText
   , null /* no mapping */ --first_name, FirstName
   , null /* no mapping */ --middle_name, MiddleName
   , null /* no mapping */ --last_name, LastName
   , null /* no mapping */ --indvl_title_txt, IndividualTitleText
   , null /* no mapping */ --org_frml_name, OrganizationFormalName
   , null /* no mapping */ --st_code, StateCode
   , null /* no mapping */ --rgn_code, RegionCode
   , null /* no mapping */ --elec_addr_txt, ElectronicAddressText
   , null /* no mapping */ --start_date_of_contact_assc, StartDateOfContactAssociation
   , null /* no mapping */ --end_date_of_contact_assc, EndDateOfContactAssociation
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SW_CNST_PRMT/ICS_CONTACT/ICS_TELEPH
INSERT INTO ICS_FLOW_LOCAL.ics_teleph (
     ics_teleph_id
   , ics_contact_id
   , ics_addr_id
   , ics_efflu_trade_prtner_addr_id
   , teleph_num_type_code
   , teleph_num
   , teleph_ext_num
   , data_hash)
SELECT 
     null /* no mapping */ --ics_teleph_id, 
   , null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_efflu_trade_prtner_addr_id, 
   , null /* no mapping */ --teleph_num_type_code, TelephoneNumberTypeCode
   , null /* no mapping */ --teleph_num, TelephoneNumber
   , null /* no mapping */ --teleph_ext_num, TelephoneExtensionNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SW_CNST_PRMT/ICS_GPCF_NOTICE_OF_INTENT
INSERT INTO ICS_FLOW_LOCAL.ics_gpcf_notice_of_intent (
     ics_gpcf_notice_of_intent_id
   , ics_sw_cnst_prmt_id
   , ics_sw_indst_prmt_id
   , noi_sign_date
   , noi_postmark_date
   , noi_rcvd_date
   , complete_noi_rcvd_date
   , fedr_cercla_dsch_ind
   , data_hash)
SELECT 
     null /* no mapping */ --ics_gpcf_notice_of_intent_id, 
   , null /* no mapping */ --ics_sw_cnst_prmt_id, 
   , null /* no mapping */ --ics_sw_indst_prmt_id, 
   , null /* no mapping */ --noi_sign_date, NOISignatureDate
   , null /* no mapping */ --noi_postmark_date, NOIPostmarkDate
   , null /* no mapping */ --noi_rcvd_date, NOIReceivedDate
   , null /* no mapping */ --complete_noi_rcvd_date, CompleteNOIReceivedDate
   , null /* no mapping */ --fedr_cercla_dsch_ind, FederalCERCLADischargeIndicator
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SW_CNST_PRMT/ICS_GPCF_NOTICE_OF_INTENT/ICS_SUBSCTOR_CODE_PLUS_DESC
INSERT INTO ICS_FLOW_LOCAL.ics_subsctor_code_plus_desc (
     ics_subsctor_code_plus_desc_id
   , ics_gpcf_notice_of_intent_id
   , subsctor_code_plus_desc
   , data_hash)
SELECT 
     null /* no mapping */ --ics_subsctor_code_plus_desc_id, 
   , null /* no mapping */ --ics_gpcf_notice_of_intent_id, 
   , null /* no mapping */ --subsctor_code_plus_desc, SubsectorCodePlusDescription
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SW_CNST_PRMT/ICS_GPCF_NOTICE_OF_TERM
INSERT INTO ICS_FLOW_LOCAL.ics_gpcf_notice_of_term (
     ics_gpcf_notice_of_term_id
   , ics_sw_cnst_prmt_id
   , ics_sw_indst_prmt_id
   , not_term_date
   , not_sign_date
   , not_postmark_date
   , not_rcvd_date
   , data_hash)
SELECT 
     null /* no mapping */ --ics_gpcf_notice_of_term_id, 
   , null /* no mapping */ --ics_sw_cnst_prmt_id, 
   , null /* no mapping */ --ics_sw_indst_prmt_id, 
   , null /* no mapping */ --not_term_date, NOTTerminationDate
   , null /* no mapping */ --not_sign_date, NOTSignatureDate
   , null /* no mapping */ --not_postmark_date, NOTPostmarkDate
   , null /* no mapping */ --not_rcvd_date, NOTReceivedDate
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SW_CNST_PRMT/ICS_TRTMNT_CHEMS_LIST
INSERT INTO ICS_FLOW_LOCAL.ics_trtmnt_chems_list (
     ics_trtmnt_chems_list_id
   , ics_sw_cnst_prmt_id
   , trtmnt_chems_list
   , data_hash)
SELECT 
     null /* no mapping */ --ics_trtmnt_chems_list_id, 
   , null /* no mapping */ --ics_sw_cnst_prmt_id, 
   , null /* no mapping */ --trtmnt_chems_list, TreatmentChemicalsList
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

END;
