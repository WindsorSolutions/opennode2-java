﻿
/*************************************************************************************************
** ObjectName: ics_etl_enforcementactionviolationlinkage
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the EnforcementActionViolationLinkageSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_enforcementactionviolationlinkage

AS

BEGIN
---------------------------- 
-- ICS_ENFRC_ACTN_VIOL_LNK
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ics_enfrc_actn_viol_lnk;


-- /ICS_ENFRC_ACTN_VIOL_LNK
INSERT INTO ICS_FLOW_LOCAL.ics_enfrc_actn_viol_lnk (
     ics_enfrc_actn_viol_lnk_id
   , ics_payload_id
   , src_systm_ident
   , transaction_type
   , transaction_timestamp
   , enfrc_actn_ident
   , key_hash
   , data_hash)
SELECT 
     null /* no mapping */ --ics_enfrc_actn_viol_lnk_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --enfrc_actn_ident, EnforcementActionIdentifier
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_CMPL_SCHD_VIOL
INSERT INTO ICS_FLOW_LOCAL.ics_cmpl_schd_viol (
     ics_cmpl_schd_viol_id
   , ics_enfrc_actn_viol_lnk_id
   , ics_final_order_viol_lnk_id
   , enfrc_actn_ident
   , final_order_ident
   , prmt_ident
   , cmpl_schd_num
   , schd_evt_code
   , schd_date
   , data_hash)
SELECT 
     null /* no mapping */ --ics_cmpl_schd_viol_id, 
   , null /* no mapping */ --ics_enfrc_actn_viol_lnk_id, 
   , null /* no mapping */ --ics_final_order_viol_lnk_id, 
   , null /* no mapping */ --enfrc_actn_ident, EnforcementActionIdentifier
   , null /* no mapping */ --final_order_ident, FinalOrderIdentifier
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --cmpl_schd_num, ComplianceScheduleNumber
   , null /* no mapping */ --schd_evt_code, ScheduleEventCode
   , null /* no mapping */ --schd_date, ScheduleDate
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_DSCH_MON_REP_PARAM_VIOL
INSERT INTO ICS_FLOW_LOCAL.ics_dsch_mon_rep_param_viol (
     ics_dsch_mon_rep_param_viol_id
   , ics_enfrc_actn_viol_lnk_id
   , ics_final_order_viol_lnk_id
   , prmt_ident
   , prmt_featr_ident
   , lmt_set_designator
   , mon_period_end_date
   , param_code
   , mon_site_desc_code
   , lmt_season_num
   , data_hash)
SELECT 
     null /* no mapping */ --ics_dsch_mon_rep_param_viol_id, 
   , null /* no mapping */ --ics_enfrc_actn_viol_lnk_id, 
   , null /* no mapping */ --ics_final_order_viol_lnk_id, 
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --prmt_featr_ident, PermittedFeatureIdentifier
   , null /* no mapping */ --lmt_set_designator, LimitSetDesignator
   , null /* no mapping */ --mon_period_end_date, MonitoringPeriodEndDate
   , null /* no mapping */ --param_code, ParameterCode
   , null /* no mapping */ --mon_site_desc_code, MonitoringSiteDescriptionCode
   , null /* no mapping */ --lmt_season_num, LimitSeasonNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_DSCH_MON_REP_VIOL
INSERT INTO ICS_FLOW_LOCAL.ics_dsch_mon_rep_viol (
     ics_dsch_mon_rep_viol_id
   , ics_enfrc_actn_viol_lnk_id
   , ics_final_order_viol_lnk_id
   , prmt_ident
   , prmt_featr_ident
   , lmt_set_designator
   , mon_period_end_date
   , data_hash)
SELECT 
     null /* no mapping */ --ics_dsch_mon_rep_viol_id, 
   , null /* no mapping */ --ics_enfrc_actn_viol_lnk_id, 
   , null /* no mapping */ --ics_final_order_viol_lnk_id, 
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --prmt_featr_ident, PermittedFeatureIdentifier
   , null /* no mapping */ --lmt_set_designator, LimitSetDesignator
   , null /* no mapping */ --mon_period_end_date, MonitoringPeriodEndDate
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_PRMT_SCHD_VIOL
INSERT INTO ICS_FLOW_LOCAL.ics_prmt_schd_viol (
     ics_prmt_schd_viol_id
   , ics_enfrc_actn_viol_lnk_id
   , ics_final_order_viol_lnk_id
   , prmt_ident
   , narr_cond_num
   , schd_evt_code
   , schd_date
   , data_hash)
SELECT 
     null /* no mapping */ --ics_prmt_schd_viol_id, 
   , null /* no mapping */ --ics_enfrc_actn_viol_lnk_id, 
   , null /* no mapping */ --ics_final_order_viol_lnk_id, 
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --narr_cond_num, NarrativeConditionNumber
   , null /* no mapping */ --schd_evt_code, ScheduleEventCode
   , null /* no mapping */ --schd_date, ScheduleDate
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_SNGL_EVTS_VIOL
INSERT INTO ICS_FLOW_LOCAL.ics_sngl_evts_viol (
     ics_sngl_evts_viol_id
   , ics_enfrc_actn_viol_lnk_id
   , ics_final_order_viol_lnk_id
   , prmt_ident
   , sngl_evt_viol_code
   , sngl_evt_viol_date
   , data_hash)
SELECT 
     null /* no mapping */ --ics_sngl_evts_viol_id, 
   , null /* no mapping */ --ics_enfrc_actn_viol_lnk_id, 
   , null /* no mapping */ --ics_final_order_viol_lnk_id, 
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --sngl_evt_viol_code, SingleEventViolationCode
   , null /* no mapping */ --sngl_evt_viol_date, SingleEventViolationDate
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

END;
