﻿
/*************************************************************************************************
** ObjectName: ics_etl_parameterlimits
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the ParameterLimitsSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_parameterlimits

AS

BEGIN
---------------------------- 
-- ICS_PARAM_LMTS
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ics_param_lmts;


-- /ICS_PARAM_LMTS
INSERT INTO ICS_FLOW_LOCAL.ics_param_lmts (
     ics_param_lmts_id
   , ics_payload_id
   , src_systm_ident
   , transaction_type
   , transaction_timestamp
   , prmt_ident
   , prmt_featr_ident
   , lmt_set_designator
   , param_code
   , mon_site_desc_code
   , lmt_season_num
   , key_hash
   , data_hash)
SELECT 
     null /* no mapping */ --ics_param_lmts_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --prmt_featr_ident, PermittedFeatureIdentifier
   , null /* no mapping */ --lmt_set_designator, LimitSetDesignator
   , null /* no mapping */ --param_code, ParameterCode
   , null /* no mapping */ --mon_site_desc_code, MonitoringSiteDescriptionCode
   , null /* no mapping */ --lmt_season_num, LimitSeasonNumber
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PARAM_LMTS/ICS_LMT
INSERT INTO ICS_FLOW_LOCAL.ics_lmt (
     ics_lmt_id
   , ics_param_lmts_id
   , lmt_start_date
   , lmt_end_date
   , lmt_type_code
   , smpl_type_txt
   , freq_of_analysis_code
   , eligible_for_burden_reduction
   , lmt_stay_type_code
   , stay_start_date
   , stay_end_date
   , stay_reason_txt
   , calculate_viol_ind
   , enfrc_actn_ident
   , final_order_ident
   , basis_of_lmt
   , lmt_mod_type_code
   , lmt_mod_effective_date
   , lmt_mod_type_stay_reason_txt
   , lmts_usr_dfnd_fld_1
   , lmts_usr_dfnd_fld_2
   , lmts_usr_dfnd_fld_3
   , concen_num_cond_unit_meas_code
   , qty_num_cond_unit_meas_code
   , data_hash)
SELECT 
     null /* no mapping */ --ics_lmt_id, 
   , null /* no mapping */ --ics_param_lmts_id, 
   , null /* no mapping */ --lmt_start_date, LimitStartDate
   , null /* no mapping */ --lmt_end_date, LimitEndDate
   , null /* no mapping */ --lmt_type_code, LimitTypeCode
   , null /* no mapping */ --smpl_type_txt, SampleTypeText
   , null /* no mapping */ --freq_of_analysis_code, FrequencyOfAnalysisCode
   , null /* no mapping */ --eligible_for_burden_reduction, EligibleForBurdenReduction
   , null /* no mapping */ --lmt_stay_type_code, LimitStayTypeCode
   , null /* no mapping */ --stay_start_date, StayStartDate
   , null /* no mapping */ --stay_end_date, StayEndDate
   , null /* no mapping */ --stay_reason_txt, StayReasonText
   , null /* no mapping */ --calculate_viol_ind, CalculateViolationsIndicator
   , null /* no mapping */ --enfrc_actn_ident, EnforcementActionIdentifier
   , null /* no mapping */ --final_order_ident, FinalOrderIdentifier
   , null /* no mapping */ --basis_of_lmt, BasisOfLimit
   , null /* no mapping */ --lmt_mod_type_code, LimitModificationTypeCode
   , null /* no mapping */ --lmt_mod_effective_date, LimitModificationEffectiveDate
   , null /* no mapping */ --lmt_mod_type_stay_reason_txt, LimitModificationTypeStayReasonText
   , null /* no mapping */ --lmts_usr_dfnd_fld_1, LimitsUserDefinedField1
   , null /* no mapping */ --lmts_usr_dfnd_fld_2, LimitsUserDefinedField2
   , null /* no mapping */ --lmts_usr_dfnd_fld_3, LimitsUserDefinedField3
   , null /* no mapping */ --concen_num_cond_unit_meas_code, ConcentrationNumericConditionUnitMeasureCode
   , null /* no mapping */ --qty_num_cond_unit_meas_code, QuantityNumericConditionUnitMeasureCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PARAM_LMTS/ICS_LMT/ICS_MN_LMT_APPLIES
INSERT INTO ICS_FLOW_LOCAL.ics_mn_lmt_applies (
     ics_mn_lmt_applies_id
   , ics_lmts_id
   , ics_lmt_id
   , mn_lmt_applies
   , data_hash)
SELECT 
     null /* no mapping */ --ics_mn_lmt_applies_id, 
   , null /* no mapping */ --ics_lmts_id, 
   , null /* no mapping */ --ics_lmt_id, 
   , null /* no mapping */ --mn_lmt_applies, MonthLimitApplies
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PARAM_LMTS/ICS_LMT/ICS_NUM_COND
INSERT INTO ICS_FLOW_LOCAL.ics_num_cond (
     ics_num_cond_id
   , ics_lmts_id
   , ics_lmt_id
   , num_cond_txt
   , num_cond_qty
   , num_cond_stat_base_code
   , num_cond_qualifier
   , num_cond_opt_mon_ind
   , num_cond_stay_value
   , data_hash)
SELECT 
     null /* no mapping */ --ics_num_cond_id, 
   , null /* no mapping */ --ics_lmts_id, 
   , null /* no mapping */ --ics_lmt_id, 
   , null /* no mapping */ --num_cond_txt, NumericConditionText
   , null /* no mapping */ --num_cond_qty, NumericConditionQuantity
   , null /* no mapping */ --num_cond_stat_base_code, NumericConditionStatisticalBaseCode
   , null /* no mapping */ --num_cond_qualifier, NumericConditionQualifier
   , null /* no mapping */ --num_cond_opt_mon_ind, NumericConditionOptionalMonitoringIndicator
   , null /* no mapping */ --num_cond_stay_value, NumericConditionStayValue
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

END;
