﻿
/*************************************************************************************************
** ObjectName: ics_etl_ssomonthlyeventreport
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the SSOMonthlyEventReportSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_ssomonthlyeventreport

AS

BEGIN
---------------------------- 
-- ICS_SSO_MONTHLY_EVT_REP
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ics_sso_monthly_evt_rep;


-- /ICS_SSO_MONTHLY_EVT_REP
INSERT INTO ICS_FLOW_LOCAL.ics_sso_monthly_evt_rep (
     ics_sso_monthly_evt_rep_id
   , ics_payload_id
   , src_systm_ident
   , transaction_type
   , transaction_timestamp
   , prmt_ident
   , sso_monthly_rep_rcvd_date
   , sso_monthly_evt_mn
   , sso_monthly_evt_year
   , num_sso_evts_rec_us_wtr_per_mn
   , vol_sso_evts_rec_us_wtr_per_mn
   , key_hash
   , data_hash)
SELECT 
     null /* no mapping */ --ics_sso_monthly_evt_rep_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --sso_monthly_rep_rcvd_date, SSOMonthlyReportReceivedDate
   , null /* no mapping */ --sso_monthly_evt_mn, SSOMonthlyEventMonth
   , null /* no mapping */ --sso_monthly_evt_year, SSOMonthlyEventYear
   , null /* no mapping */ --num_sso_evts_rec_us_wtr_per_mn, NumberSSOEventsReachUSWatersPerMonth
   , null /* no mapping */ --vol_sso_evts_rec_us_wtr_per_mn, VolumeSSOEventsReachUSWatersPerMonth
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

END;
