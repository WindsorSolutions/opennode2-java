﻿
/*************************************************************************************************
** ObjectName: ics_etl_historicalpermitscheduleevents
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the HistoricalPermitScheduleEventsSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_historicalpermitscheduleevents

AS

BEGIN
---------------------------- 
-- ICS_HIST_PRMT_SCHD_EVTS
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ics_hist_prmt_schd_evts;


-- /ICS_HIST_PRMT_SCHD_EVTS
INSERT INTO ICS_FLOW_LOCAL.ics_hist_prmt_schd_evts (
     ics_hist_prmt_schd_evts_id
   , ics_payload_id
   , src_systm_ident
   , transaction_type
   , transaction_timestamp
   , prmt_ident
   , prmt_effective_date
   , narr_cond_num
   , schd_evt_code
   , schd_date
   , schd_rep_rcvd_date
   , schd_actul_date
   , schd_proj_date
   , schd_usr_dfnd_dat_elm_1
   , schd_usr_dfnd_dat_elm_2
   , schd_evt_cmnts
   , key_hash
   , data_hash)
SELECT 
     null /* no mapping */ --ics_hist_prmt_schd_evts_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --prmt_effective_date, PermitEffectiveDate
   , null /* no mapping */ --narr_cond_num, NarrativeConditionNumber
   , null /* no mapping */ --schd_evt_code, ScheduleEventCode
   , null /* no mapping */ --schd_date, ScheduleDate
   , null /* no mapping */ --schd_rep_rcvd_date, ScheduleReportReceivedDate
   , null /* no mapping */ --schd_actul_date, ScheduleActualDate
   , null /* no mapping */ --schd_proj_date, ScheduleProjectedDate
   , null /* no mapping */ --schd_usr_dfnd_dat_elm_1, ScheduleUserDefinedDataElement1
   , null /* no mapping */ --schd_usr_dfnd_dat_elm_2, ScheduleUserDefinedDataElement2
   , null /* no mapping */ --schd_evt_cmnts, ScheduleEventComments
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

END;
