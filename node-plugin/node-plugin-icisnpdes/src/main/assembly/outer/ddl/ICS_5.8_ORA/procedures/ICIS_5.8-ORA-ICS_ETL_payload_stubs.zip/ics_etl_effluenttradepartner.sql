﻿
/*************************************************************************************************
** ObjectName: ics_etl_effluenttradepartner
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the EffluentTradePartnerSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_effluenttradepartner

AS

BEGIN
---------------------------- 
-- ICS_EFFLU_TRADE_PRTNER
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ics_efflu_trade_prtner;


-- /ICS_EFFLU_TRADE_PRTNER
INSERT INTO ICS_FLOW_LOCAL.ics_efflu_trade_prtner (
     ics_efflu_trade_prtner_id
   , ics_payload_id
   , src_systm_ident
   , transaction_type
   , transaction_timestamp
   , prmt_ident
   , prmt_featr_ident
   , lmt_set_designator
   , param_code
   , mon_site_desc_code
   , lmt_season_num
   , lmt_start_date
   , lmt_end_date
   , lmt_mod_effective_date
   , trade_id
   , trade_prtner_npdesid
   , trade_prtner_othr_id
   , trade_prtner_type
   , trade_prtner_start_date
   , trade_prtner_end_date
   , key_hash
   , data_hash)
SELECT 
     null /* no mapping */ --ics_efflu_trade_prtner_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --prmt_featr_ident, PermittedFeatureIdentifier
   , null /* no mapping */ --lmt_set_designator, LimitSetDesignator
   , null /* no mapping */ --param_code, ParameterCode
   , null /* no mapping */ --mon_site_desc_code, MonitoringSiteDescriptionCode
   , null /* no mapping */ --lmt_season_num, LimitSeasonNumber
   , null /* no mapping */ --lmt_start_date, LimitStartDate
   , null /* no mapping */ --lmt_end_date, LimitEndDate
   , null /* no mapping */ --lmt_mod_effective_date, LimitModificationEffectiveDate
   , null /* no mapping */ --trade_id, TradeID
   , null /* no mapping */ --trade_prtner_npdesid, TradePartnerNPDESID
   , null /* no mapping */ --trade_prtner_othr_id, TradePartnerOtherID
   , null /* no mapping */ --trade_prtner_type, TradePartnerType
   , null /* no mapping */ --trade_prtner_start_date, TradePartnerStartDate
   , null /* no mapping */ --trade_prtner_end_date, TradePartnerEndDate
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_EFFLU_TRADE_PRTNER/ICS_EFFLU_TRADE_PRTNER_ADDR
INSERT INTO ICS_FLOW_LOCAL.ics_efflu_trade_prtner_addr (
     ics_efflu_trade_prtner_addr_id
   , ics_efflu_trade_prtner_id
   , org_frml_name
   , org_duns_num
   , loc_name
   , mailing_addr_txt
   , suppl_addr_txt
   , mailing_addr_city_name
   , mailing_addr_country_code
   , loc_province
   , mailing_addr_st_code
   , mailing_addr_zip_code
   , county_name
   , division_name
   , elec_addr_txt
   , data_hash)
SELECT 
     null /* no mapping */ --ics_efflu_trade_prtner_addr_id, 
   , null /* no mapping */ --ics_efflu_trade_prtner_id, 
   , null /* no mapping */ --org_frml_name, OrganizationFormalName
   , null /* no mapping */ --org_duns_num, OrganizationDUNSNumber
   , null /* no mapping */ --loc_name, LocationName
   , null /* no mapping */ --mailing_addr_txt, MailingAddressText
   , null /* no mapping */ --suppl_addr_txt, SupplementalAddressText
   , null /* no mapping */ --mailing_addr_city_name, MailingAddressCityName
   , null /* no mapping */ --mailing_addr_country_code, MailingAddressCountryCode
   , null /* no mapping */ --loc_province, LocationProvince
   , null /* no mapping */ --mailing_addr_st_code, MailingAddressStateCode
   , null /* no mapping */ --mailing_addr_zip_code, MailingAddressZipCode
   , null /* no mapping */ --county_name, CountyName
   , null /* no mapping */ --division_name, DivisionName
   , null /* no mapping */ --elec_addr_txt, ElectronicAddressText
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_EFFLU_TRADE_PRTNER/ICS_EFFLU_TRADE_PRTNER_ADDR/ICS_TELEPH
INSERT INTO ICS_FLOW_LOCAL.ics_teleph (
     ics_teleph_id
   , ics_contact_id
   , ics_addr_id
   , ics_efflu_trade_prtner_addr_id
   , teleph_num_type_code
   , teleph_num
   , teleph_ext_num
   , data_hash)
SELECT 
     null /* no mapping */ --ics_teleph_id, 
   , null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_efflu_trade_prtner_addr_id, 
   , null /* no mapping */ --teleph_num_type_code, TelephoneNumberTypeCode
   , null /* no mapping */ --teleph_num, TelephoneNumber
   , null /* no mapping */ --teleph_ext_num, TelephoneExtensionNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

END;
