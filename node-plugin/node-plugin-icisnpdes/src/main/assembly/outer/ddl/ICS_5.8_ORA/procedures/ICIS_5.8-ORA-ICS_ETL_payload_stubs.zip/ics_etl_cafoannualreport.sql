﻿
/*************************************************************************************************
** ObjectName: ics_etl_cafoannualreport
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the CAFOAnnualReportSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_cafoannualreport

AS

BEGIN
---------------------------- 
-- ICS_CAFO_ANNUL_REP
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ics_cafo_annul_rep;


-- /ICS_CAFO_ANNUL_REP
INSERT INTO ICS_FLOW_LOCAL.ics_cafo_annul_rep (
     ics_cafo_annul_rep_id
   , ics_payload_id
   , src_systm_ident
   , transaction_type
   , transaction_timestamp
   , prmt_ident
   , prmt_auth_rep_rcvd_date
   , dsch_drng_year_prod_area_ind
   , solid_mnur_lttr_gnrtd_amt
   , liquid_mnur_ww_gnrtd_amt
   , solid_mnur_lttr_trans_amt
   , liquid_mnur_ww_trans_amt
   , nmp_dvlpd_cert_plnr_aprvd_ind
   , ttl_num_acres_nmp_idntfd
   , ttl_num_acres_used_land_appl
   , key_hash
   , data_hash)
SELECT 
     null /* no mapping */ --ics_cafo_annul_rep_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --prmt_auth_rep_rcvd_date, PermittingAuthorityReportReceivedDate
   , null /* no mapping */ --dsch_drng_year_prod_area_ind, DischargesDuringYearProductionAreaIndicator
   , null /* no mapping */ --solid_mnur_lttr_gnrtd_amt, SolidManureLitterGeneratedAmount
   , null /* no mapping */ --liquid_mnur_ww_gnrtd_amt, LiquidManureWastewaterGeneratedAmount
   , null /* no mapping */ --solid_mnur_lttr_trans_amt, SolidManureLitterTransferAmount
   , null /* no mapping */ --liquid_mnur_ww_trans_amt, LiquidManureWastewaterTransferAmount
   , null /* no mapping */ --nmp_dvlpd_cert_plnr_aprvd_ind, NMPDevelopedCertifiedPlannerApprovedIndicator
   , null /* no mapping */ --ttl_num_acres_nmp_idntfd, TotalNumberAcresNMPIdentified
   , null /* no mapping */ --ttl_num_acres_used_land_appl, TotalNumberAcresUsedLandApplication
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CAFO_ANNUL_REP/ICS_REP_ANML_TYPE
INSERT INTO ICS_FLOW_LOCAL.ics_rep_anml_type (
     ics_rep_anml_type_id
   , ics_cafo_annul_rep_id
   , anml_type_code
   , othr_anml_type_name
   , ttl_num_each_lvstck
   , data_hash)
SELECT 
     null /* no mapping */ --ics_rep_anml_type_id, 
   , null /* no mapping */ --ics_cafo_annul_rep_id, 
   , null /* no mapping */ --anml_type_code, AnimalTypeCode
   , null /* no mapping */ --othr_anml_type_name, OtherAnimalTypeName
   , null /* no mapping */ --ttl_num_each_lvstck, TotalNumbersEachLivestock
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

END;
