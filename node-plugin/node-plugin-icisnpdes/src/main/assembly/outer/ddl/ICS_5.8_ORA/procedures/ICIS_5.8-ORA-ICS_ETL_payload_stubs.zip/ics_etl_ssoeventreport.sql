﻿
/*************************************************************************************************
** ObjectName: ics_etl_ssoeventreport
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the SSOEventReportSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_ssoeventreport

AS

BEGIN
---------------------------- 
-- ICS_SSO_EVT_REP
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ics_sso_evt_rep;


-- /ICS_SSO_EVT_REP
INSERT INTO ICS_FLOW_LOCAL.ics_sso_evt_rep (
     ics_sso_evt_rep_id
   , ics_payload_id
   , src_systm_ident
   , transaction_type
   , transaction_timestamp
   , prmt_ident
   , sso_evt_date
   , sso_evt_id
   , cause_sso_ovrflw_evt
   , lat_meas
   , long_meas
   , sso_ovrflw_loc_street
   , duration_sso_ovrflw_evt
   , sso_vol
   , name_rcvg_wtr
   , desc_stps_taken
   , key_hash
   , data_hash)
SELECT 
     null /* no mapping */ --ics_sso_evt_rep_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --sso_evt_date, SSOEventDate
   , null /* no mapping */ --sso_evt_id, SSOEventID
   , null /* no mapping */ --cause_sso_ovrflw_evt, CauseSSOOverflowEvent
   , null /* no mapping */ --lat_meas, LatitudeMeasure
   , null /* no mapping */ --long_meas, LongitudeMeasure
   , null /* no mapping */ --sso_ovrflw_loc_street, SSOOverflowLocationStreet
   , null /* no mapping */ --duration_sso_ovrflw_evt, DurationSSOOverflowEvent
   , null /* no mapping */ --sso_vol, SSOVolume
   , null /* no mapping */ --name_rcvg_wtr, NameReceivingWater
   , null /* no mapping */ --desc_stps_taken, DescriptionStepsTaken
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SSO_EVT_REP/ICS_IMPACT_SSO_EVT
INSERT INTO ICS_FLOW_LOCAL.ics_impact_sso_evt (
     ics_impact_sso_evt_id
   , ics_sso_insp_id
   , ics_sso_evt_rep_id
   , impact_sso_evt
   , data_hash)
SELECT 
     null /* no mapping */ --ics_impact_sso_evt_id, 
   , null /* no mapping */ --ics_sso_insp_id, 
   , null /* no mapping */ --ics_sso_evt_rep_id, 
   , null /* no mapping */ --impact_sso_evt, ImpactSSOEvent
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SSO_EVT_REP/ICS_SSO_STPS
INSERT INTO ICS_FLOW_LOCAL.ics_sso_stps (
     ics_sso_stps_id
   , ics_sso_insp_id
   , ics_sso_evt_rep_id
   , stps_rduce_prevnt_mitigte
   , othr_stps_rduce_prevnt_mitigte
   , data_hash)
SELECT 
     null /* no mapping */ --ics_sso_stps_id, 
   , null /* no mapping */ --ics_sso_insp_id, 
   , null /* no mapping */ --ics_sso_evt_rep_id, 
   , null /* no mapping */ --stps_rduce_prevnt_mitigte, StepsReducePreventMitigate
   , null /* no mapping */ --othr_stps_rduce_prevnt_mitigte, OtherStepsReducePreventMitigate
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SSO_EVT_REP/ICS_SSO_SYSTM_COMP
INSERT INTO ICS_FLOW_LOCAL.ics_sso_systm_comp (
     ics_sso_systm_comp_id
   , ics_sso_insp_id
   , ics_sso_evt_rep_id
   , systm_comp
   , othr_systm_comp
   , data_hash)
SELECT 
     null /* no mapping */ --ics_sso_systm_comp_id, 
   , null /* no mapping */ --ics_sso_insp_id, 
   , null /* no mapping */ --ics_sso_evt_rep_id, 
   , null /* no mapping */ --systm_comp, SystemComponent
   , null /* no mapping */ --othr_systm_comp, OtherSystemComponent
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

END;
