﻿
/*************************************************************************************************
** ObjectName: ics_etl_locallimitsprogramreport
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the LocalLimitsProgramReportSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_locallimitsprogramreport

AS

BEGIN
---------------------------- 
-- ICS_LOC_LMTS_PROG_REP
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ics_loc_lmts_prog_rep;


-- /ICS_LOC_LMTS_PROG_REP
INSERT INTO ICS_FLOW_LOCAL.ics_loc_lmts_prog_rep (
     ics_loc_lmts_prog_rep_id
   , ics_payload_id
   , src_systm_ident
   , transaction_type
   , transaction_timestamp
   , prmt_ident
   , prmt_auth_rep_rcvd_date
   , key_hash
   , data_hash)
SELECT 
     null /* no mapping */ --ics_loc_lmts_prog_rep_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --prmt_auth_rep_rcvd_date, PermittingAuthorityReportReceivedDate
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_LOC_LMTS_PROG_REP/ICS_LOC_LMTS
INSERT INTO ICS_FLOW_LOCAL.ics_loc_lmts (
     ics_loc_lmts_id
   , ics_pretr_insp_id
   , ics_loc_lmts_prog_rep_id
   , ics_pretr_perf_summ_id
   , mos_rc_date_tech_eval_loc_lmts
   , mos_rc_date_ad_tc_bs_loc_lmts
   , data_hash)
SELECT 
     null /* no mapping */ --ics_loc_lmts_id, 
   , null /* no mapping */ --ics_pretr_insp_id, 
   , null /* no mapping */ --ics_loc_lmts_prog_rep_id, 
   , null /* no mapping */ --ics_pretr_perf_summ_id, 
   , null /* no mapping */ --mos_rc_date_tech_eval_loc_lmts, MostRecentDateTechnicalEvaluationLocalLimits
   , null /* no mapping */ --mos_rc_date_ad_tc_bs_loc_lmts, MostRecentDateAdoptionTechnicallyBasedLocalLimits
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_LOC_LMTS_PROG_REP/ICS_LOC_LMTS/ICS_LOC_LMTS_POLUT
INSERT INTO ICS_FLOW_LOCAL.ics_loc_lmts_polut (
     ics_loc_lmts_polut_id
   , ics_loc_lmts_id
   , loc_lmts_polut_code
   , data_hash)
SELECT 
     null /* no mapping */ --ics_loc_lmts_polut_id, 
   , null /* no mapping */ --ics_loc_lmts_id, 
   , null /* no mapping */ --loc_lmts_polut_code, LocalLimitsPollutantCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_LOC_LMTS_PROG_REP/ICS_RMVL_CRDTS
INSERT INTO ICS_FLOW_LOCAL.ics_rmvl_crdts (
     ics_rmvl_crdts_id
   , ics_pretr_insp_id
   , ics_loc_lmts_prog_rep_id
   , ics_pretr_perf_summ_id
   , mos_rc_date_rmvl_crdts_aprvl
   , rmvl_crdts_appl_stat_code
   , data_hash)
SELECT 
     null /* no mapping */ --ics_rmvl_crdts_id, 
   , null /* no mapping */ --ics_pretr_insp_id, 
   , null /* no mapping */ --ics_loc_lmts_prog_rep_id, 
   , null /* no mapping */ --ics_pretr_perf_summ_id, 
   , null /* no mapping */ --mos_rc_date_rmvl_crdts_aprvl, MostRecentDateRemovalCreditsApproval
   , null /* no mapping */ --rmvl_crdts_appl_stat_code, RemovalCreditsApplicationStatusCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_LOC_LMTS_PROG_REP/ICS_RMVL_CRDTS/ICS_RMVL_CRDTS_POLUT
INSERT INTO ICS_FLOW_LOCAL.ics_rmvl_crdts_polut (
     ics_rmvl_crdts_polut_id
   , ics_rmvl_crdts_id
   , rmvl_crdts_polut_code
   , data_hash)
SELECT 
     null /* no mapping */ --ics_rmvl_crdts_polut_id, 
   , null /* no mapping */ --ics_rmvl_crdts_id, 
   , null /* no mapping */ --rmvl_crdts_polut_code, RemovalCreditsPollutantCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

END;
