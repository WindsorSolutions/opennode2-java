﻿IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'ICS_FLOW_LOCAL.ics_etl_mastergeneralpermit') AND type in (N'P', N'PC'))
DROP PROCEDURE ICS_FLOW_LOCAL.ics_etl_mastergeneralpermit
GO


/*************************************************************************************************
** ObjectName: ics_etl_mastergeneralpermit
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the MasterGeneralPermitSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE PROCEDURE ICS_FLOW_LOCAL.ics_etl_mastergeneralpermit

AS

---------------------------- 
-- ICS_MASTER_GNRL_PRMT
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_MASTER_GNRL_PRMT/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM ICS_FLOW_LOCAL.ics_teleph
 WHERE ics_contact_id IN
          (SELECT ics_contact.ics_contact_id
             FROM ICS_FLOW_LOCAL.ics_master_gnrl_prmt
                  JOIN ICS_FLOW_LOCAL.ics_contact ON ics_contact.ics_master_gnrl_prmt_id = ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
          );

-- /ICS_MASTER_GNRL_PRMT/ICS_ASSC_PRMT
DELETE
  FROM ICS_FLOW_LOCAL.ics_assc_prmt
 WHERE ics_master_gnrl_prmt_id IN
          (SELECT ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
             FROM ICS_FLOW_LOCAL.ics_master_gnrl_prmt
          );

-- /ICS_MASTER_GNRL_PRMT/ICS_CONTACT
DELETE
  FROM ICS_FLOW_LOCAL.ics_contact
 WHERE ics_master_gnrl_prmt_id IN
          (SELECT ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
             FROM ICS_FLOW_LOCAL.ics_master_gnrl_prmt
          );

-- /ICS_MASTER_GNRL_PRMT/ICS_NAICS_CODE
DELETE
  FROM ICS_FLOW_LOCAL.ics_naics_code
 WHERE ics_master_gnrl_prmt_id IN
          (SELECT ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
             FROM ICS_FLOW_LOCAL.ics_master_gnrl_prmt
          );

-- /ICS_MASTER_GNRL_PRMT/ICS_OTHR_PRMTS
DELETE
  FROM ICS_FLOW_LOCAL.ics_othr_prmts
 WHERE ics_master_gnrl_prmt_id IN
          (SELECT ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
             FROM ICS_FLOW_LOCAL.ics_master_gnrl_prmt
          );

-- /ICS_MASTER_GNRL_PRMT/ICS_PRMT_COMP_TYPE
DELETE
  FROM ICS_FLOW_LOCAL.ics_prmt_comp_type
 WHERE ics_master_gnrl_prmt_id IN
          (SELECT ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
             FROM ICS_FLOW_LOCAL.ics_master_gnrl_prmt
          );

-- /ICS_MASTER_GNRL_PRMT/ICS_SIC_CODE
DELETE
  FROM ICS_FLOW_LOCAL.ics_sic_code
 WHERE ics_master_gnrl_prmt_id IN
          (SELECT ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
             FROM ICS_FLOW_LOCAL.ics_master_gnrl_prmt
          );

-- /ICS_MASTER_GNRL_PRMT
DELETE
  FROM ICS_FLOW_LOCAL.ics_master_gnrl_prmt;


-- /ICS_MASTER_GNRL_PRMT
INSERT INTO ICS_FLOW_LOCAL.ics_master_gnrl_prmt (
     [ics_master_gnrl_prmt_id]
   , [ics_payload_id]
   , [src_systm_ident]
   , [transaction_type]
   , [transaction_timestamp]
   , [prmt_ident]
   , [prmt_type_code]
   , [agncy_type_code]
   , [prmt_issue_date]
   , [prmt_effective_date]
   , [prmt_expr_date]
   , [reissu_prio_prmt_ind]
   , [backlog_reason_txt]
   , [prmt_issuing_org_type_name]
   , [prmt_appealed_ind]
   , [prmt_usr_dfnd_dat_elm_1_txt]
   , [prmt_usr_dfnd_dat_elm_2_txt]
   , [prmt_usr_dfnd_dat_elm_3_txt]
   , [prmt_usr_dfnd_dat_elm_4_txt]
   , [prmt_usr_dfnd_dat_elm_5_txt]
   , [prmt_cmnts_txt]
   , [gnrl_prmt_indst_catg]
   , [prmt_name]
   , [key_hash]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_master_gnrl_prmt_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --prmt_type_code, PermitTypeCode
   , null /* no mapping */ --agncy_type_code, AgencyTypeCode
   , null /* no mapping */ --prmt_issue_date, PermitIssueDate
   , null /* no mapping */ --prmt_effective_date, PermitEffectiveDate
   , null /* no mapping */ --prmt_expr_date, PermitExpirationDate
   , null /* no mapping */ --reissu_prio_prmt_ind, ReissuancePriorityPermitIndicator
   , null /* no mapping */ --backlog_reason_txt, BacklogReasonText
   , null /* no mapping */ --prmt_issuing_org_type_name, PermitIssuingOrganizationTypeName
   , null /* no mapping */ --prmt_appealed_ind, PermitAppealedIndicator
   , null /* no mapping */ --prmt_usr_dfnd_dat_elm_1_txt, PermitUserDefinedDataElement1Text
   , null /* no mapping */ --prmt_usr_dfnd_dat_elm_2_txt, PermitUserDefinedDataElement2Text
   , null /* no mapping */ --prmt_usr_dfnd_dat_elm_3_txt, PermitUserDefinedDataElement3Text
   , null /* no mapping */ --prmt_usr_dfnd_dat_elm_4_txt, PermitUserDefinedDataElement4Text
   , null /* no mapping */ --prmt_usr_dfnd_dat_elm_5_txt, PermitUserDefinedDataElement5Text
   , null /* no mapping */ --prmt_cmnts_txt, PermitCommentsText
   , null /* no mapping */ --gnrl_prmt_indst_catg, GeneralPermitIndustrialCategory
   , null /* no mapping */ --prmt_name, PermitName
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_MASTER_GNRL_PRMT/ICS_ASSC_PRMT
INSERT INTO ICS_FLOW_LOCAL.ics_assc_prmt (
     [ics_assc_prmt_id]
   , [ics_basic_prmt_id]
   , [ics_gnrl_prmt_id]
   , [ics_master_gnrl_prmt_id]
   , [assc_prmt_ident]
   , [assc_prmt_reason_code]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_assc_prmt_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_master_gnrl_prmt_id, 
   , null /* no mapping */ --assc_prmt_ident, AssociatedPermitIdentifier
   , null /* no mapping */ --assc_prmt_reason_code, AssociatedPermitReasonCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_MASTER_GNRL_PRMT/ICS_CONTACT
INSERT INTO ICS_FLOW_LOCAL.ics_contact (
     [ics_contact_id]
   , [ics_fac_id]
   , [ics_basic_prmt_id]
   , [ics_prmt_featr_id]
   , [ics_bs_mgmt_practices_id]
   , [ics_bs_annul_prog_rep_id]
   , [ics_bs_prmt_id]
   , [ics_cafo_prmt_id]
   , [ics_cmpl_mon_id]
   , [ics_gnrl_prmt_id]
   , [ics_master_gnrl_prmt_id]
   , [ics_pretr_prmt_id]
   , [ics_sw_cnst_prmt_id]
   , [ics_sw_evt_rep_id]
   , [ics_sw_indst_prmt_id]
   , [ics_swms_4_large_prmt_id]
   , [ics_swms_4_prog_rep_id]
   , [ics_swms_4_small_prmt_id]
   , [ics_unprmt_fac_id]
   , [affil_type_txt]
   , [first_name]
   , [middle_name]
   , [last_name]
   , [indvl_title_txt]
   , [org_frml_name]
   , [st_code]
   , [rgn_code]
   , [elec_addr_txt]
   , [start_date_of_contact_assc]
   , [end_date_of_contact_assc]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --ics_bs_mgmt_practices_id, 
   , null /* no mapping */ --ics_bs_annul_prog_rep_id, 
   , null /* no mapping */ --ics_bs_prmt_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_cmpl_mon_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_master_gnrl_prmt_id, 
   , null /* no mapping */ --ics_pretr_prmt_id, 
   , null /* no mapping */ --ics_sw_cnst_prmt_id, 
   , null /* no mapping */ --ics_sw_evt_rep_id, 
   , null /* no mapping */ --ics_sw_indst_prmt_id, 
   , null /* no mapping */ --ics_swms_4_large_prmt_id, 
   , null /* no mapping */ --ics_swms_4_prog_rep_id, 
   , null /* no mapping */ --ics_swms_4_small_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --affil_type_txt, AffiliationTypeText
   , null /* no mapping */ --first_name, FirstName
   , null /* no mapping */ --middle_name, MiddleName
   , null /* no mapping */ --last_name, LastName
   , null /* no mapping */ --indvl_title_txt, IndividualTitleText
   , null /* no mapping */ --org_frml_name, OrganizationFormalName
   , null /* no mapping */ --st_code, StateCode
   , null /* no mapping */ --rgn_code, RegionCode
   , null /* no mapping */ --elec_addr_txt, ElectronicAddressText
   , null /* no mapping */ --start_date_of_contact_assc, StartDateOfContactAssociation
   , null /* no mapping */ --end_date_of_contact_assc, EndDateOfContactAssociation
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_MASTER_GNRL_PRMT/ICS_CONTACT/ICS_TELEPH
INSERT INTO ICS_FLOW_LOCAL.ics_teleph (
     [ics_teleph_id]
   , [ics_contact_id]
   , [ics_addr_id]
   , [ics_efflu_trade_prtner_addr_id]
   , [teleph_num_type_code]
   , [teleph_num]
   , [teleph_ext_num]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_teleph_id, 
   , null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_efflu_trade_prtner_addr_id, 
   , null /* no mapping */ --teleph_num_type_code, TelephoneNumberTypeCode
   , null /* no mapping */ --teleph_num, TelephoneNumber
   , null /* no mapping */ --teleph_ext_num, TelephoneExtensionNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_MASTER_GNRL_PRMT/ICS_NAICS_CODE
INSERT INTO ICS_FLOW_LOCAL.ics_naics_code (
     [ics_naics_code_id]
   , [ics_basic_prmt_id]
   , [ics_fac_id]
   , [ics_gnrl_prmt_id]
   , [ics_master_gnrl_prmt_id]
   , [ics_unprmt_fac_id]
   , [naics_code]
   , [naics_primary_ind_code]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_naics_code_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_master_gnrl_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --naics_code, NAICSCode
   , null /* no mapping */ --naics_primary_ind_code, NAICSPrimaryIndicatorCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_MASTER_GNRL_PRMT/ICS_OTHR_PRMTS
INSERT INTO ICS_FLOW_LOCAL.ics_othr_prmts (
     [ics_othr_prmts_id]
   , [ics_basic_prmt_id]
   , [ics_gnrl_prmt_id]
   , [ics_master_gnrl_prmt_id]
   , [othr_prmt_ident]
   , [othr_org_name]
   , [othr_prmt_ident_cntxt_name]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_othr_prmts_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_master_gnrl_prmt_id, 
   , null /* no mapping */ --othr_prmt_ident, OtherPermitIdentifier
   , null /* no mapping */ --othr_org_name, OtherOrganizationName
   , null /* no mapping */ --othr_prmt_ident_cntxt_name, OtherPermitIdentifierContextName
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_MASTER_GNRL_PRMT/ICS_PRMT_COMP_TYPE
INSERT INTO ICS_FLOW_LOCAL.ics_prmt_comp_type (
     [ics_prmt_comp_type_id]
   , [ics_master_gnrl_prmt_id]
   , [ics_unprmt_fac_id]
   , [prmt_comp_type_code]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_prmt_comp_type_id, 
   , null /* no mapping */ --ics_master_gnrl_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --prmt_comp_type_code, PermitComponentTypeCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_MASTER_GNRL_PRMT/ICS_SIC_CODE
INSERT INTO ICS_FLOW_LOCAL.ics_sic_code (
     [ics_sic_code_id]
   , [ics_basic_prmt_id]
   , [ics_fac_id]
   , [ics_gnrl_prmt_id]
   , [ics_master_gnrl_prmt_id]
   , [ics_unprmt_fac_id]
   , [sic_code]
   , [sic_primary_ind_code]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_sic_code_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_master_gnrl_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --sic_code, SICCode
   , null /* no mapping */ --sic_primary_ind_code, SICPrimaryIndicatorCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

