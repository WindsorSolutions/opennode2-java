﻿IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'ICS_FLOW_LOCAL.ics_etl_permittedfeature') AND type in (N'P', N'PC'))
DROP PROCEDURE ICS_FLOW_LOCAL.ics_etl_permittedfeature
GO


/*************************************************************************************************
** ObjectName: ics_etl_permittedfeature
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the PermittedFeatureSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE PROCEDURE ICS_FLOW_LOCAL.ics_etl_permittedfeature

AS

---------------------------- 
-- ICS_PRMT_FEATR
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_PRMT_FEATR/ICS_ADDR/ICS_TELEPH
DELETE
  FROM ICS_FLOW_LOCAL.ics_teleph
 WHERE ics_addr_id IN
          (SELECT ics_addr.ics_addr_id
             FROM ICS_FLOW_LOCAL.ics_prmt_featr
                  JOIN ICS_FLOW_LOCAL.ics_addr ON ics_addr.ics_prmt_featr_id = ics_prmt_featr.ics_prmt_featr_id
          );

-- /ICS_PRMT_FEATR/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM ICS_FLOW_LOCAL.ics_teleph
 WHERE ics_contact_id IN
          (SELECT ics_contact.ics_contact_id
             FROM ICS_FLOW_LOCAL.ics_prmt_featr
                  JOIN ICS_FLOW_LOCAL.ics_contact ON ics_contact.ics_prmt_featr_id = ics_prmt_featr.ics_prmt_featr_id
          );

-- /ICS_PRMT_FEATR/ICS_TMDL_POLLUTANTS/ICS_TMDL_POLUT
DELETE
  FROM ICS_FLOW_LOCAL.ics_tmdl_polut
 WHERE ics_tmdl_pollutants_id IN
          (SELECT ics_tmdl_pollutants.ics_tmdl_pollutants_id
             FROM ICS_FLOW_LOCAL.ics_prmt_featr
                  JOIN ICS_FLOW_LOCAL.ics_tmdl_pollutants ON ics_tmdl_pollutants.ics_prmt_featr_id = ics_prmt_featr.ics_prmt_featr_id
          );

-- /ICS_PRMT_FEATR/ICS_ADDR
DELETE
  FROM ICS_FLOW_LOCAL.ics_addr
 WHERE ics_prmt_featr_id IN
          (SELECT ics_prmt_featr.ics_prmt_featr_id
             FROM ICS_FLOW_LOCAL.ics_prmt_featr
          );

-- /ICS_PRMT_FEATR/ICS_CONTACT
DELETE
  FROM ICS_FLOW_LOCAL.ics_contact
 WHERE ics_prmt_featr_id IN
          (SELECT ics_prmt_featr.ics_prmt_featr_id
             FROM ICS_FLOW_LOCAL.ics_prmt_featr
          );

-- /ICS_PRMT_FEATR/ICS_GEO_COORD
DELETE
  FROM ICS_FLOW_LOCAL.ics_geo_coord
 WHERE ics_prmt_featr_id IN
          (SELECT ics_prmt_featr.ics_prmt_featr_id
             FROM ICS_FLOW_LOCAL.ics_prmt_featr
          );

-- /ICS_PRMT_FEATR/ICS_IMPAIRED_WTR_POLLUTANTS
DELETE
  FROM ICS_FLOW_LOCAL.ics_impaired_wtr_pollutants
 WHERE ics_prmt_featr_id IN
          (SELECT ics_prmt_featr.ics_prmt_featr_id
             FROM ICS_FLOW_LOCAL.ics_prmt_featr
          );

-- /ICS_PRMT_FEATR/ICS_PRMT_FEATR_CHAR
DELETE
  FROM ICS_FLOW_LOCAL.ics_prmt_featr_char
 WHERE ics_prmt_featr_id IN
          (SELECT ics_prmt_featr.ics_prmt_featr_id
             FROM ICS_FLOW_LOCAL.ics_prmt_featr
          );

-- /ICS_PRMT_FEATR/ICS_PRMT_FEATR_TRTMNT_TYPE
DELETE
  FROM ICS_FLOW_LOCAL.ics_prmt_featr_trtmnt_type
 WHERE ics_prmt_featr_id IN
          (SELECT ics_prmt_featr.ics_prmt_featr_id
             FROM ICS_FLOW_LOCAL.ics_prmt_featr
          );

-- /ICS_PRMT_FEATR/ICS_TMDL_POLLUTANTS
DELETE
  FROM ICS_FLOW_LOCAL.ics_tmdl_pollutants
 WHERE ics_prmt_featr_id IN
          (SELECT ics_prmt_featr.ics_prmt_featr_id
             FROM ICS_FLOW_LOCAL.ics_prmt_featr
          );

-- /ICS_PRMT_FEATR
DELETE
  FROM ICS_FLOW_LOCAL.ics_prmt_featr;


-- /ICS_PRMT_FEATR
INSERT INTO ICS_FLOW_LOCAL.ics_prmt_featr (
     [ics_prmt_featr_id]
   , [ics_payload_id]
   , [src_systm_ident]
   , [transaction_type]
   , [transaction_timestamp]
   , [prmt_ident]
   , [prmt_featr_ident]
   , [prmt_featr_type_code]
   , [prmt_featr_desc]
   , [prmt_featr_dsgn_flow_num]
   , [prmt_featr_actul_aver_flow_num]
   , [prmt_featr_st_wtr_body_code]
   , [prmt_featr_st_wtr_body_name]
   , [tier_level_name]
   , [impaired_wtr_ind]
   , [tmdl_completed_ind]
   , [prmt_featr_usr_dfnd_dat_elm_1]
   , [prmt_featr_usr_dfnd_dat_elm_2]
   , [fld_size]
   , [is_site_own_by_fac]
   , [is_systm_lined_with_leachate]
   , [does_unit_hav_daily_cover]
   , [prop_boundary_distance]
   , [is_reqd_nitrate_ground_wtr]
   , [well_num]
   , [src_prmt_featr_detail_txt]
   , [key_hash]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --prmt_featr_ident, PermittedFeatureIdentifier
   , null /* no mapping */ --prmt_featr_type_code, PermittedFeatureTypeCode
   , null /* no mapping */ --prmt_featr_desc, PermittedFeatureDescription
   , null /* no mapping */ --prmt_featr_dsgn_flow_num, PermittedFeatureDesignFlowNumber
   , null /* no mapping */ --prmt_featr_actul_aver_flow_num, PermittedFeatureActualAverageFlowNumber
   , null /* no mapping */ --prmt_featr_st_wtr_body_code, PermittedFeatureStateWaterBodyCode
   , null /* no mapping */ --prmt_featr_st_wtr_body_name, PermittedFeatureStateWaterBodyName
   , null /* no mapping */ --tier_level_name, TierLevelName
   , null /* no mapping */ --impaired_wtr_ind, ImpairedWaterIndicator
   , null /* no mapping */ --tmdl_completed_ind, TMDLCompletedIndicator
   , null /* no mapping */ --prmt_featr_usr_dfnd_dat_elm_1, PermittedFeatureUserDefinedDataElement1
   , null /* no mapping */ --prmt_featr_usr_dfnd_dat_elm_2, PermittedFeatureUserDefinedDataElement2
   , null /* no mapping */ --fld_size, FieldSize
   , null /* no mapping */ --is_site_own_by_fac, IsSiteOwnByFacility
   , null /* no mapping */ --is_systm_lined_with_leachate, IsSystemLinedWithLeachate
   , null /* no mapping */ --does_unit_hav_daily_cover, DoesUnitHaveDailyCover
   , null /* no mapping */ --prop_boundary_distance, PropertyBoundaryDistance
   , null /* no mapping */ --is_reqd_nitrate_ground_wtr, IsRequiredNitrateGroundWater
   , null /* no mapping */ --well_num, WellNumber
   , null /* no mapping */ --src_prmt_featr_detail_txt, SourcePermittedFeatureDetailText
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRMT_FEATR/ICS_ADDR
INSERT INTO ICS_FLOW_LOCAL.ics_addr (
     [ics_addr_id]
   , [ics_fac_id]
   , [ics_basic_prmt_id]
   , [ics_prmt_featr_id]
   , [ics_bs_mgmt_practices_id]
   , [ics_bs_prmt_id]
   , [ics_cafo_prmt_id]
   , [ics_gnrl_prmt_id]
   , [ics_sw_cnst_prmt_id]
   , [ics_sw_evt_rep_id]
   , [ics_sw_indst_prmt_id]
   , [ics_swms_4_large_prmt_id]
   , [ics_swms_4_prog_rep_id]
   , [ics_swms_4_small_prmt_id]
   , [ics_unprmt_fac_id]
   , [affil_type_txt]
   , [org_frml_name]
   , [org_duns_num]
   , [mailing_addr_txt]
   , [suppl_addr_txt]
   , [mailing_addr_city_name]
   , [mailing_addr_st_code]
   , [mailing_addr_zip_code]
   , [county_name]
   , [mailing_addr_country_code]
   , [division_name]
   , [loc_province]
   , [elec_addr_txt]
   , [start_date_of_addr_assc]
   , [end_date_of_addr_assc]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --ics_bs_mgmt_practices_id, 
   , null /* no mapping */ --ics_bs_prmt_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_sw_cnst_prmt_id, 
   , null /* no mapping */ --ics_sw_evt_rep_id, 
   , null /* no mapping */ --ics_sw_indst_prmt_id, 
   , null /* no mapping */ --ics_swms_4_large_prmt_id, 
   , null /* no mapping */ --ics_swms_4_prog_rep_id, 
   , null /* no mapping */ --ics_swms_4_small_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --affil_type_txt, AffiliationTypeText
   , null /* no mapping */ --org_frml_name, OrganizationFormalName
   , null /* no mapping */ --org_duns_num, OrganizationDUNSNumber
   , null /* no mapping */ --mailing_addr_txt, MailingAddressText
   , null /* no mapping */ --suppl_addr_txt, SupplementalAddressText
   , null /* no mapping */ --mailing_addr_city_name, MailingAddressCityName
   , null /* no mapping */ --mailing_addr_st_code, MailingAddressStateCode
   , null /* no mapping */ --mailing_addr_zip_code, MailingAddressZipCode
   , null /* no mapping */ --county_name, CountyName
   , null /* no mapping */ --mailing_addr_country_code, MailingAddressCountryCode
   , null /* no mapping */ --division_name, DivisionName
   , null /* no mapping */ --loc_province, LocationProvince
   , null /* no mapping */ --elec_addr_txt, ElectronicAddressText
   , null /* no mapping */ --start_date_of_addr_assc, StartDateOfAddressAssociation
   , null /* no mapping */ --end_date_of_addr_assc, EndDateOfAddressAssociation
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRMT_FEATR/ICS_ADDR/ICS_TELEPH
INSERT INTO ICS_FLOW_LOCAL.ics_teleph (
     [ics_teleph_id]
   , [ics_contact_id]
   , [ics_addr_id]
   , [ics_efflu_trade_prtner_addr_id]
   , [teleph_num_type_code]
   , [teleph_num]
   , [teleph_ext_num]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_teleph_id, 
   , null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_efflu_trade_prtner_addr_id, 
   , null /* no mapping */ --teleph_num_type_code, TelephoneNumberTypeCode
   , null /* no mapping */ --teleph_num, TelephoneNumber
   , null /* no mapping */ --teleph_ext_num, TelephoneExtensionNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRMT_FEATR/ICS_CONTACT
INSERT INTO ICS_FLOW_LOCAL.ics_contact (
     [ics_contact_id]
   , [ics_fac_id]
   , [ics_basic_prmt_id]
   , [ics_prmt_featr_id]
   , [ics_bs_mgmt_practices_id]
   , [ics_bs_annul_prog_rep_id]
   , [ics_bs_prmt_id]
   , [ics_cafo_prmt_id]
   , [ics_cmpl_mon_id]
   , [ics_gnrl_prmt_id]
   , [ics_master_gnrl_prmt_id]
   , [ics_pretr_prmt_id]
   , [ics_sw_cnst_prmt_id]
   , [ics_sw_evt_rep_id]
   , [ics_sw_indst_prmt_id]
   , [ics_swms_4_large_prmt_id]
   , [ics_swms_4_prog_rep_id]
   , [ics_swms_4_small_prmt_id]
   , [ics_unprmt_fac_id]
   , [affil_type_txt]
   , [first_name]
   , [middle_name]
   , [last_name]
   , [indvl_title_txt]
   , [org_frml_name]
   , [st_code]
   , [rgn_code]
   , [elec_addr_txt]
   , [start_date_of_contact_assc]
   , [end_date_of_contact_assc]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --ics_bs_mgmt_practices_id, 
   , null /* no mapping */ --ics_bs_annul_prog_rep_id, 
   , null /* no mapping */ --ics_bs_prmt_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_cmpl_mon_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_master_gnrl_prmt_id, 
   , null /* no mapping */ --ics_pretr_prmt_id, 
   , null /* no mapping */ --ics_sw_cnst_prmt_id, 
   , null /* no mapping */ --ics_sw_evt_rep_id, 
   , null /* no mapping */ --ics_sw_indst_prmt_id, 
   , null /* no mapping */ --ics_swms_4_large_prmt_id, 
   , null /* no mapping */ --ics_swms_4_prog_rep_id, 
   , null /* no mapping */ --ics_swms_4_small_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --affil_type_txt, AffiliationTypeText
   , null /* no mapping */ --first_name, FirstName
   , null /* no mapping */ --middle_name, MiddleName
   , null /* no mapping */ --last_name, LastName
   , null /* no mapping */ --indvl_title_txt, IndividualTitleText
   , null /* no mapping */ --org_frml_name, OrganizationFormalName
   , null /* no mapping */ --st_code, StateCode
   , null /* no mapping */ --rgn_code, RegionCode
   , null /* no mapping */ --elec_addr_txt, ElectronicAddressText
   , null /* no mapping */ --start_date_of_contact_assc, StartDateOfContactAssociation
   , null /* no mapping */ --end_date_of_contact_assc, EndDateOfContactAssociation
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRMT_FEATR/ICS_CONTACT/ICS_TELEPH
INSERT INTO ICS_FLOW_LOCAL.ics_teleph (
     [ics_teleph_id]
   , [ics_contact_id]
   , [ics_addr_id]
   , [ics_efflu_trade_prtner_addr_id]
   , [teleph_num_type_code]
   , [teleph_num]
   , [teleph_ext_num]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_teleph_id, 
   , null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_efflu_trade_prtner_addr_id, 
   , null /* no mapping */ --teleph_num_type_code, TelephoneNumberTypeCode
   , null /* no mapping */ --teleph_num, TelephoneNumber
   , null /* no mapping */ --teleph_ext_num, TelephoneExtensionNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRMT_FEATR/ICS_GEO_COORD
INSERT INTO ICS_FLOW_LOCAL.ics_geo_coord (
     [ics_geo_coord_id]
   , [ics_fac_id]
   , [ics_prmt_featr_id]
   , [ics_unprmt_fac_id]
   , [lat_meas]
   , [long_meas]
   , [horz_accuracy_meas]
   , [geometric_type_code]
   , [horz_coll_method_code]
   , [horz_ref_datum_code]
   , [ref_point_code]
   , [src_map_scale_num]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_geo_coord_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --lat_meas, LatitudeMeasure
   , null /* no mapping */ --long_meas, LongitudeMeasure
   , null /* no mapping */ --horz_accuracy_meas, HorizontalAccuracyMeasure
   , null /* no mapping */ --geometric_type_code, GeometricTypeCode
   , null /* no mapping */ --horz_coll_method_code, HorizontalCollectionMethodCode
   , null /* no mapping */ --horz_ref_datum_code, HorizontalReferenceDatumCode
   , null /* no mapping */ --ref_point_code, ReferencePointCode
   , null /* no mapping */ --src_map_scale_num, SourceMapScaleNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRMT_FEATR/ICS_IMPAIRED_WTR_POLLUTANTS
INSERT INTO ICS_FLOW_LOCAL.ics_impaired_wtr_pollutants (
     [ics_impaired_wtr_pollutants_id]
   , [ics_prmt_featr_id]
   , [impaired_wtr_pollutants]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_impaired_wtr_pollutants_id, 
   , null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --impaired_wtr_pollutants, ImpairedWaterPollutants
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRMT_FEATR/ICS_PRMT_FEATR_CHAR
INSERT INTO ICS_FLOW_LOCAL.ics_prmt_featr_char (
     [ics_prmt_featr_char_id]
   , [ics_prmt_featr_id]
   , [prmt_featr_char]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_prmt_featr_char_id, 
   , null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --prmt_featr_char, PermittedFeatureCharacteristics
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRMT_FEATR/ICS_PRMT_FEATR_TRTMNT_TYPE
INSERT INTO ICS_FLOW_LOCAL.ics_prmt_featr_trtmnt_type (
     [ics_prmt_featr_trtmnt_type_id]
   , [ics_prmt_featr_id]
   , [prmt_featr_trtmnt_type_code]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_prmt_featr_trtmnt_type_id, 
   , null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --prmt_featr_trtmnt_type_code, PermittedFeatureTreatmentTypeCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRMT_FEATR/ICS_TMDL_POLLUTANTS
INSERT INTO ICS_FLOW_LOCAL.ics_tmdl_pollutants (
     [ics_tmdl_pollutants_id]
   , [ics_prmt_featr_id]
   , [tmdl_ident]
   , [tmdl_name]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_tmdl_pollutants_id, 
   , null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --tmdl_ident, TMDLIdentifier
   , null /* no mapping */ --tmdl_name, TMDLName
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRMT_FEATR/ICS_TMDL_POLLUTANTS/ICS_TMDL_POLUT
INSERT INTO ICS_FLOW_LOCAL.ics_tmdl_polut (
     [ics_tmdl_polut_id]
   , [ics_tmdl_pollutants_id]
   , [tmdl_polut_code]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_tmdl_polut_id, 
   , null /* no mapping */ --ics_tmdl_pollutants_id, 
   , null /* no mapping */ --tmdl_polut_code, TMDLPollutantCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

