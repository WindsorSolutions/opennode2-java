﻿IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'ICS_FLOW_LOCAL.ics_etl_basicpermit') AND type in (N'P', N'PC'))
DROP PROCEDURE ICS_FLOW_LOCAL.ics_etl_basicpermit
GO


/*************************************************************************************************
** ObjectName: ics_etl_basicpermit
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the BasicPermitSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE PROCEDURE ICS_FLOW_LOCAL.ics_etl_basicpermit

AS

---------------------------- 
-- ICS_BASIC_PRMT
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_ADDR/ICS_TELEPH
DELETE
  FROM ICS_FLOW_LOCAL.ics_teleph
 WHERE ics_addr_id IN
          (SELECT ics_addr.ics_addr_id
             FROM ICS_FLOW_LOCAL.ics_basic_prmt
                  JOIN ICS_FLOW_LOCAL.ics_fac ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
                  JOIN ICS_FLOW_LOCAL.ics_addr ON ics_addr.ics_fac_id = ics_fac.ics_fac_id
          );

-- /ICS_BASIC_PRMT/ICS_FAC/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM ICS_FLOW_LOCAL.ics_teleph
 WHERE ics_contact_id IN
          (SELECT ics_contact.ics_contact_id
             FROM ICS_FLOW_LOCAL.ics_basic_prmt
                  JOIN ICS_FLOW_LOCAL.ics_fac ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
                  JOIN ICS_FLOW_LOCAL.ics_contact ON ics_contact.ics_fac_id = ics_fac.ics_fac_id
          );

-- /ICS_BASIC_PRMT/ICS_ADDR/ICS_TELEPH
DELETE
  FROM ICS_FLOW_LOCAL.ics_teleph
 WHERE ics_addr_id IN
          (SELECT ics_addr.ics_addr_id
             FROM ICS_FLOW_LOCAL.ics_basic_prmt
                  JOIN ICS_FLOW_LOCAL.ics_addr ON ics_addr.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
          );

-- /ICS_BASIC_PRMT/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM ICS_FLOW_LOCAL.ics_teleph
 WHERE ics_contact_id IN
          (SELECT ics_contact.ics_contact_id
             FROM ICS_FLOW_LOCAL.ics_basic_prmt
                  JOIN ICS_FLOW_LOCAL.ics_contact ON ics_contact.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
          );

-- /ICS_BASIC_PRMT/ICS_FAC/ICS_ADDR
DELETE
  FROM ICS_FLOW_LOCAL.ics_addr
 WHERE ics_fac_id IN
          (SELECT ics_fac.ics_fac_id
             FROM ICS_FLOW_LOCAL.ics_basic_prmt
                  JOIN ICS_FLOW_LOCAL.ics_fac ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
          );

-- /ICS_BASIC_PRMT/ICS_FAC/ICS_CONTACT
DELETE
  FROM ICS_FLOW_LOCAL.ics_contact
 WHERE ics_fac_id IN
          (SELECT ics_fac.ics_fac_id
             FROM ICS_FLOW_LOCAL.ics_basic_prmt
                  JOIN ICS_FLOW_LOCAL.ics_fac ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
          );

-- /ICS_BASIC_PRMT/ICS_FAC/ICS_FAC_CLASS
DELETE
  FROM ICS_FLOW_LOCAL.ics_fac_class
 WHERE ics_fac_id IN
          (SELECT ics_fac.ics_fac_id
             FROM ICS_FLOW_LOCAL.ics_basic_prmt
                  JOIN ICS_FLOW_LOCAL.ics_fac ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
          );

-- /ICS_BASIC_PRMT/ICS_FAC/ICS_GEO_COORD
DELETE
  FROM ICS_FLOW_LOCAL.ics_geo_coord
 WHERE ics_fac_id IN
          (SELECT ics_fac.ics_fac_id
             FROM ICS_FLOW_LOCAL.ics_basic_prmt
                  JOIN ICS_FLOW_LOCAL.ics_fac ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
          );

-- /ICS_BASIC_PRMT/ICS_FAC/ICS_NAICS_CODE
DELETE
  FROM ICS_FLOW_LOCAL.ics_naics_code
 WHERE ics_fac_id IN
          (SELECT ics_fac.ics_fac_id
             FROM ICS_FLOW_LOCAL.ics_basic_prmt
                  JOIN ICS_FLOW_LOCAL.ics_fac ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
          );

-- /ICS_BASIC_PRMT/ICS_FAC/ICS_ORIG_PROGS
DELETE
  FROM ICS_FLOW_LOCAL.ics_orig_progs
 WHERE ics_fac_id IN
          (SELECT ics_fac.ics_fac_id
             FROM ICS_FLOW_LOCAL.ics_basic_prmt
                  JOIN ICS_FLOW_LOCAL.ics_fac ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
          );

-- /ICS_BASIC_PRMT/ICS_FAC/ICS_PLCY
DELETE
  FROM ICS_FLOW_LOCAL.ics_plcy
 WHERE ics_fac_id IN
          (SELECT ics_fac.ics_fac_id
             FROM ICS_FLOW_LOCAL.ics_basic_prmt
                  JOIN ICS_FLOW_LOCAL.ics_fac ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
          );

-- /ICS_BASIC_PRMT/ICS_FAC/ICS_SIC_CODE
DELETE
  FROM ICS_FLOW_LOCAL.ics_sic_code
 WHERE ics_fac_id IN
          (SELECT ics_fac.ics_fac_id
             FROM ICS_FLOW_LOCAL.ics_basic_prmt
                  JOIN ICS_FLOW_LOCAL.ics_fac ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
          );

-- /ICS_BASIC_PRMT/ICS_ADDR
DELETE
  FROM ICS_FLOW_LOCAL.ics_addr
 WHERE ics_basic_prmt_id IN
          (SELECT ics_basic_prmt.ics_basic_prmt_id
             FROM ICS_FLOW_LOCAL.ics_basic_prmt
          );

-- /ICS_BASIC_PRMT/ICS_ASSC_PRMT
DELETE
  FROM ICS_FLOW_LOCAL.ics_assc_prmt
 WHERE ics_basic_prmt_id IN
          (SELECT ics_basic_prmt.ics_basic_prmt_id
             FROM ICS_FLOW_LOCAL.ics_basic_prmt
          );

-- /ICS_BASIC_PRMT/ICS_CMPL_TRACK_STAT
DELETE
  FROM ICS_FLOW_LOCAL.ics_cmpl_track_stat
 WHERE ics_basic_prmt_id IN
          (SELECT ics_basic_prmt.ics_basic_prmt_id
             FROM ICS_FLOW_LOCAL.ics_basic_prmt
          );

-- /ICS_BASIC_PRMT/ICS_CONTACT
DELETE
  FROM ICS_FLOW_LOCAL.ics_contact
 WHERE ics_basic_prmt_id IN
          (SELECT ics_basic_prmt.ics_basic_prmt_id
             FROM ICS_FLOW_LOCAL.ics_basic_prmt
          );

-- /ICS_BASIC_PRMT/ICS_EFFLU_GUIDE
DELETE
  FROM ICS_FLOW_LOCAL.ics_efflu_guide
 WHERE ics_basic_prmt_id IN
          (SELECT ics_basic_prmt.ics_basic_prmt_id
             FROM ICS_FLOW_LOCAL.ics_basic_prmt
          );

-- /ICS_BASIC_PRMT/ICS_FAC
DELETE
  FROM ICS_FLOW_LOCAL.ics_fac
 WHERE ics_basic_prmt_id IN
          (SELECT ics_basic_prmt.ics_basic_prmt_id
             FROM ICS_FLOW_LOCAL.ics_basic_prmt
          );

-- /ICS_BASIC_PRMT/ICS_NAICS_CODE
DELETE
  FROM ICS_FLOW_LOCAL.ics_naics_code
 WHERE ics_basic_prmt_id IN
          (SELECT ics_basic_prmt.ics_basic_prmt_id
             FROM ICS_FLOW_LOCAL.ics_basic_prmt
          );

-- /ICS_BASIC_PRMT/ICS_NPDES_DAT_GRP_NUM
DELETE
  FROM ICS_FLOW_LOCAL.ics_npdes_dat_grp_num
 WHERE ics_basic_prmt_id IN
          (SELECT ics_basic_prmt.ics_basic_prmt_id
             FROM ICS_FLOW_LOCAL.ics_basic_prmt
          );

-- /ICS_BASIC_PRMT/ICS_OTHR_PRMTS
DELETE
  FROM ICS_FLOW_LOCAL.ics_othr_prmts
 WHERE ics_basic_prmt_id IN
          (SELECT ics_basic_prmt.ics_basic_prmt_id
             FROM ICS_FLOW_LOCAL.ics_basic_prmt
          );

-- /ICS_BASIC_PRMT/ICS_REP_NON_CMPL_STAT
DELETE
  FROM ICS_FLOW_LOCAL.ics_rep_non_cmpl_stat
 WHERE ics_basic_prmt_id IN
          (SELECT ics_basic_prmt.ics_basic_prmt_id
             FROM ICS_FLOW_LOCAL.ics_basic_prmt
          );

-- /ICS_BASIC_PRMT/ICS_SIC_CODE
DELETE
  FROM ICS_FLOW_LOCAL.ics_sic_code
 WHERE ics_basic_prmt_id IN
          (SELECT ics_basic_prmt.ics_basic_prmt_id
             FROM ICS_FLOW_LOCAL.ics_basic_prmt
          );

-- /ICS_BASIC_PRMT
DELETE
  FROM ICS_FLOW_LOCAL.ics_basic_prmt;


-- /ICS_BASIC_PRMT
INSERT INTO ICS_FLOW_LOCAL.ics_basic_prmt (
     [ics_basic_prmt_id]
   , [ics_payload_id]
   , [src_systm_ident]
   , [transaction_type]
   , [transaction_timestamp]
   , [prmt_ident]
   , [prmt_type_code]
   , [agncy_type_code]
   , [prmt_stat_code]
   , [prmt_issue_date]
   , [prmt_effective_date]
   , [prmt_expr_date]
   , [reissu_prio_prmt_ind]
   , [backlog_reason_txt]
   , [prmt_issuing_org_type_name]
   , [prmt_appealed_ind]
   , [prmt_usr_dfnd_dat_elm_1_txt]
   , [prmt_usr_dfnd_dat_elm_2_txt]
   , [prmt_usr_dfnd_dat_elm_3_txt]
   , [prmt_usr_dfnd_dat_elm_4_txt]
   , [prmt_usr_dfnd_dat_elm_5_txt]
   , [prmt_cmnts_txt]
   , [major_minor_rating_code]
   , [major_minor_stat_ind]
   , [major_minor_stat_start_date]
   , [ttl_appl_dsgn_flow_num]
   , [ttl_appl_aver_flow_num]
   , [appl_rcvd_date]
   , [prmt_appl_cmpl_date]
   , [new_src_ind]
   , [dmr_non_rcpt_stat_ind]
   , [dmr_non_rcpt_stat_start_date]
   , [prmt_st_wtr_body_code]
   , [prmt_st_wtr_body_name]
   , [fedr_grant_ind]
   , [dmr_cognznt_ofcl]
   , [dmr_cognznt_ofcl_teleph_num]
   , [sig_iu_ind]
   , [rcvg_prmt_ident]
   , [elec_rep_waiver_type_code]
   , [elec_rep_waiver_effective_date]
   , [elec_rep_waiver_expr_date]
   , [key_hash]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --prmt_type_code, PermitTypeCode
   , null /* no mapping */ --agncy_type_code, AgencyTypeCode
   , null /* no mapping */ --prmt_stat_code, PermitStatusCode
   , null /* no mapping */ --prmt_issue_date, PermitIssueDate
   , null /* no mapping */ --prmt_effective_date, PermitEffectiveDate
   , null /* no mapping */ --prmt_expr_date, PermitExpirationDate
   , null /* no mapping */ --reissu_prio_prmt_ind, ReissuancePriorityPermitIndicator
   , null /* no mapping */ --backlog_reason_txt, BacklogReasonText
   , null /* no mapping */ --prmt_issuing_org_type_name, PermitIssuingOrganizationTypeName
   , null /* no mapping */ --prmt_appealed_ind, PermitAppealedIndicator
   , null /* no mapping */ --prmt_usr_dfnd_dat_elm_1_txt, PermitUserDefinedDataElement1Text
   , null /* no mapping */ --prmt_usr_dfnd_dat_elm_2_txt, PermitUserDefinedDataElement2Text
   , null /* no mapping */ --prmt_usr_dfnd_dat_elm_3_txt, PermitUserDefinedDataElement3Text
   , null /* no mapping */ --prmt_usr_dfnd_dat_elm_4_txt, PermitUserDefinedDataElement4Text
   , null /* no mapping */ --prmt_usr_dfnd_dat_elm_5_txt, PermitUserDefinedDataElement5Text
   , null /* no mapping */ --prmt_cmnts_txt, PermitCommentsText
   , null /* no mapping */ --major_minor_rating_code, MajorMinorRatingCode
   , null /* no mapping */ --major_minor_stat_ind, MajorMinorStatusIndicator
   , null /* no mapping */ --major_minor_stat_start_date, MajorMinorStatusStartDate
   , null /* no mapping */ --ttl_appl_dsgn_flow_num, TotalApplicationDesignFlowNumber
   , null /* no mapping */ --ttl_appl_aver_flow_num, TotalApplicationAverageFlowNumber
   , null /* no mapping */ --appl_rcvd_date, ApplicationReceivedDate
   , null /* no mapping */ --prmt_appl_cmpl_date, PermitApplicationCompletionDate
   , null /* no mapping */ --new_src_ind, NewSourceIndicator
   , null /* no mapping */ --dmr_non_rcpt_stat_ind, DMRNonReceiptStatusIndicator
   , null /* no mapping */ --dmr_non_rcpt_stat_start_date, DMRNonReceiptStatusStartDate
   , null /* no mapping */ --prmt_st_wtr_body_code, PermitStateWaterBodyCode
   , null /* no mapping */ --prmt_st_wtr_body_name, PermitStateWaterBodyName
   , null /* no mapping */ --fedr_grant_ind, FederalGrantIndicator
   , null /* no mapping */ --dmr_cognznt_ofcl, DMRCognizantOfficial
   , null /* no mapping */ --dmr_cognznt_ofcl_teleph_num, DMRCognizantOfficialTelephoneNumber
   , null /* no mapping */ --sig_iu_ind, SignificantIUIndicator
   , null /* no mapping */ --rcvg_prmt_ident, ReceivingPermitIdentifier
   , null /* no mapping */ --elec_rep_waiver_type_code, ElectronicReportingWaiverTypeCode
   , null /* no mapping */ --elec_rep_waiver_effective_date, ElectronicReportingWaiverEffectiveDate
   , null /* no mapping */ --elec_rep_waiver_expr_date, ElectronicReportingWaiverExpirationDate
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BASIC_PRMT/ICS_ADDR
INSERT INTO ICS_FLOW_LOCAL.ics_addr (
     [ics_addr_id]
   , [ics_fac_id]
   , [ics_basic_prmt_id]
   , [ics_prmt_featr_id]
   , [ics_bs_mgmt_practices_id]
   , [ics_bs_prmt_id]
   , [ics_cafo_prmt_id]
   , [ics_gnrl_prmt_id]
   , [ics_sw_cnst_prmt_id]
   , [ics_sw_evt_rep_id]
   , [ics_sw_indst_prmt_id]
   , [ics_swms_4_large_prmt_id]
   , [ics_swms_4_prog_rep_id]
   , [ics_swms_4_small_prmt_id]
   , [ics_unprmt_fac_id]
   , [affil_type_txt]
   , [org_frml_name]
   , [org_duns_num]
   , [mailing_addr_txt]
   , [suppl_addr_txt]
   , [mailing_addr_city_name]
   , [mailing_addr_st_code]
   , [mailing_addr_zip_code]
   , [county_name]
   , [mailing_addr_country_code]
   , [division_name]
   , [loc_province]
   , [elec_addr_txt]
   , [start_date_of_addr_assc]
   , [end_date_of_addr_assc]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --ics_bs_mgmt_practices_id, 
   , null /* no mapping */ --ics_bs_prmt_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_sw_cnst_prmt_id, 
   , null /* no mapping */ --ics_sw_evt_rep_id, 
   , null /* no mapping */ --ics_sw_indst_prmt_id, 
   , null /* no mapping */ --ics_swms_4_large_prmt_id, 
   , null /* no mapping */ --ics_swms_4_prog_rep_id, 
   , null /* no mapping */ --ics_swms_4_small_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --affil_type_txt, AffiliationTypeText
   , null /* no mapping */ --org_frml_name, OrganizationFormalName
   , null /* no mapping */ --org_duns_num, OrganizationDUNSNumber
   , null /* no mapping */ --mailing_addr_txt, MailingAddressText
   , null /* no mapping */ --suppl_addr_txt, SupplementalAddressText
   , null /* no mapping */ --mailing_addr_city_name, MailingAddressCityName
   , null /* no mapping */ --mailing_addr_st_code, MailingAddressStateCode
   , null /* no mapping */ --mailing_addr_zip_code, MailingAddressZipCode
   , null /* no mapping */ --county_name, CountyName
   , null /* no mapping */ --mailing_addr_country_code, MailingAddressCountryCode
   , null /* no mapping */ --division_name, DivisionName
   , null /* no mapping */ --loc_province, LocationProvince
   , null /* no mapping */ --elec_addr_txt, ElectronicAddressText
   , null /* no mapping */ --start_date_of_addr_assc, StartDateOfAddressAssociation
   , null /* no mapping */ --end_date_of_addr_assc, EndDateOfAddressAssociation
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BASIC_PRMT/ICS_ADDR/ICS_TELEPH
INSERT INTO ICS_FLOW_LOCAL.ics_teleph (
     [ics_teleph_id]
   , [ics_contact_id]
   , [ics_addr_id]
   , [ics_efflu_trade_prtner_addr_id]
   , [teleph_num_type_code]
   , [teleph_num]
   , [teleph_ext_num]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_teleph_id, 
   , null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_efflu_trade_prtner_addr_id, 
   , null /* no mapping */ --teleph_num_type_code, TelephoneNumberTypeCode
   , null /* no mapping */ --teleph_num, TelephoneNumber
   , null /* no mapping */ --teleph_ext_num, TelephoneExtensionNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BASIC_PRMT/ICS_ASSC_PRMT
INSERT INTO ICS_FLOW_LOCAL.ics_assc_prmt (
     [ics_assc_prmt_id]
   , [ics_basic_prmt_id]
   , [ics_gnrl_prmt_id]
   , [ics_master_gnrl_prmt_id]
   , [assc_prmt_ident]
   , [assc_prmt_reason_code]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_assc_prmt_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_master_gnrl_prmt_id, 
   , null /* no mapping */ --assc_prmt_ident, AssociatedPermitIdentifier
   , null /* no mapping */ --assc_prmt_reason_code, AssociatedPermitReasonCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BASIC_PRMT/ICS_CMPL_TRACK_STAT
INSERT INTO ICS_FLOW_LOCAL.ics_cmpl_track_stat (
     [ics_cmpl_track_stat_id]
   , [ics_basic_prmt_id]
   , [ics_gnrl_prmt_id]
   , [stat_code]
   , [stat_start_date]
   , [stat_reason]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_cmpl_track_stat_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --stat_code, StatusCode
   , null /* no mapping */ --stat_start_date, StatusStartDate
   , null /* no mapping */ --stat_reason, StatusReason
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BASIC_PRMT/ICS_CONTACT
INSERT INTO ICS_FLOW_LOCAL.ics_contact (
     [ics_contact_id]
   , [ics_fac_id]
   , [ics_basic_prmt_id]
   , [ics_prmt_featr_id]
   , [ics_bs_mgmt_practices_id]
   , [ics_bs_annul_prog_rep_id]
   , [ics_bs_prmt_id]
   , [ics_cafo_prmt_id]
   , [ics_cmpl_mon_id]
   , [ics_gnrl_prmt_id]
   , [ics_master_gnrl_prmt_id]
   , [ics_pretr_prmt_id]
   , [ics_sw_cnst_prmt_id]
   , [ics_sw_evt_rep_id]
   , [ics_sw_indst_prmt_id]
   , [ics_swms_4_large_prmt_id]
   , [ics_swms_4_prog_rep_id]
   , [ics_swms_4_small_prmt_id]
   , [ics_unprmt_fac_id]
   , [affil_type_txt]
   , [first_name]
   , [middle_name]
   , [last_name]
   , [indvl_title_txt]
   , [org_frml_name]
   , [st_code]
   , [rgn_code]
   , [elec_addr_txt]
   , [start_date_of_contact_assc]
   , [end_date_of_contact_assc]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --ics_bs_mgmt_practices_id, 
   , null /* no mapping */ --ics_bs_annul_prog_rep_id, 
   , null /* no mapping */ --ics_bs_prmt_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_cmpl_mon_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_master_gnrl_prmt_id, 
   , null /* no mapping */ --ics_pretr_prmt_id, 
   , null /* no mapping */ --ics_sw_cnst_prmt_id, 
   , null /* no mapping */ --ics_sw_evt_rep_id, 
   , null /* no mapping */ --ics_sw_indst_prmt_id, 
   , null /* no mapping */ --ics_swms_4_large_prmt_id, 
   , null /* no mapping */ --ics_swms_4_prog_rep_id, 
   , null /* no mapping */ --ics_swms_4_small_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --affil_type_txt, AffiliationTypeText
   , null /* no mapping */ --first_name, FirstName
   , null /* no mapping */ --middle_name, MiddleName
   , null /* no mapping */ --last_name, LastName
   , null /* no mapping */ --indvl_title_txt, IndividualTitleText
   , null /* no mapping */ --org_frml_name, OrganizationFormalName
   , null /* no mapping */ --st_code, StateCode
   , null /* no mapping */ --rgn_code, RegionCode
   , null /* no mapping */ --elec_addr_txt, ElectronicAddressText
   , null /* no mapping */ --start_date_of_contact_assc, StartDateOfContactAssociation
   , null /* no mapping */ --end_date_of_contact_assc, EndDateOfContactAssociation
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BASIC_PRMT/ICS_CONTACT/ICS_TELEPH
INSERT INTO ICS_FLOW_LOCAL.ics_teleph (
     [ics_teleph_id]
   , [ics_contact_id]
   , [ics_addr_id]
   , [ics_efflu_trade_prtner_addr_id]
   , [teleph_num_type_code]
   , [teleph_num]
   , [teleph_ext_num]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_teleph_id, 
   , null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_efflu_trade_prtner_addr_id, 
   , null /* no mapping */ --teleph_num_type_code, TelephoneNumberTypeCode
   , null /* no mapping */ --teleph_num, TelephoneNumber
   , null /* no mapping */ --teleph_ext_num, TelephoneExtensionNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BASIC_PRMT/ICS_EFFLU_GUIDE
INSERT INTO ICS_FLOW_LOCAL.ics_efflu_guide (
     [ics_efflu_guide_id]
   , [ics_basic_prmt_id]
   , [ics_gnrl_prmt_id]
   , [efflu_guide_code]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_efflu_guide_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --efflu_guide_code, EffluentGuidelineCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BASIC_PRMT/ICS_FAC
INSERT INTO ICS_FLOW_LOCAL.ics_fac (
     [ics_fac_id]
   , [ics_basic_prmt_id]
   , [ics_gnrl_prmt_id]
   , [fac_site_name]
   , [loc_addr_txt]
   , [suppl_loc_txt]
   , [locality_name]
   , [loc_addr_county_code]
   , [loc_addr_city_code]
   , [loc_st_code]
   , [loc_zip_code]
   , [loc_country_code]
   , [org_duns_num]
   , [st_fac_ident]
   , [st_rgn_code]
   , [fac_congr_district_num]
   , [fac_type_of_ownership_code]
   , [fedr_fac_ident_num]
   , [fedr_agncy_code]
   , [tribal_land_code]
   , [cnst_proj_name]
   , [cnst_proj_lat_meas]
   , [cnst_proj_long_meas]
   , [section_township_rng]
   , [fac_cmnts]
   , [fac_usr_dfnd_fld_1]
   , [fac_usr_dfnd_fld_2]
   , [fac_usr_dfnd_fld_3]
   , [fac_usr_dfnd_fld_4]
   , [fac_usr_dfnd_fld_5]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --fac_site_name, FacilitySiteName
   , null /* no mapping */ --loc_addr_txt, LocationAddressText
   , null /* no mapping */ --suppl_loc_txt, SupplementalLocationText
   , null /* no mapping */ --locality_name, LocalityName
   , null /* no mapping */ --loc_addr_county_code, LocationAddressCountyCode
   , null /* no mapping */ --loc_addr_city_code, LocationAddressCityCode
   , null /* no mapping */ --loc_st_code, LocationStateCode
   , null /* no mapping */ --loc_zip_code, LocationZipCode
   , null /* no mapping */ --loc_country_code, LocationCountryCode
   , null /* no mapping */ --org_duns_num, OrganizationDUNSNumber
   , null /* no mapping */ --st_fac_ident, StateFacilityIdentifier
   , null /* no mapping */ --st_rgn_code, StateRegionCode
   , null /* no mapping */ --fac_congr_district_num, FacilityCongressionalDistrictNumber
   , null /* no mapping */ --fac_type_of_ownership_code, FacilityTypeOfOwnershipCode
   , null /* no mapping */ --fedr_fac_ident_num, FederalFacilityIdentificationNumber
   , null /* no mapping */ --fedr_agncy_code, FederalAgencyCode
   , null /* no mapping */ --tribal_land_code, TribalLandCode
   , null /* no mapping */ --cnst_proj_name, ConstructionProjectName
   , null /* no mapping */ --cnst_proj_lat_meas, ConstructionProjectLatitudeMeasure
   , null /* no mapping */ --cnst_proj_long_meas, ConstructionProjectLongitudeMeasure
   , null /* no mapping */ --section_township_rng, SectionTownshipRange
   , null /* no mapping */ --fac_cmnts, FacilityComments
   , null /* no mapping */ --fac_usr_dfnd_fld_1, FacilityUserDefinedField1
   , null /* no mapping */ --fac_usr_dfnd_fld_2, FacilityUserDefinedField2
   , null /* no mapping */ --fac_usr_dfnd_fld_3, FacilityUserDefinedField3
   , null /* no mapping */ --fac_usr_dfnd_fld_4, FacilityUserDefinedField4
   , null /* no mapping */ --fac_usr_dfnd_fld_5, FacilityUserDefinedField5
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BASIC_PRMT/ICS_FAC/ICS_ADDR
INSERT INTO ICS_FLOW_LOCAL.ics_addr (
     [ics_addr_id]
   , [ics_fac_id]
   , [ics_basic_prmt_id]
   , [ics_prmt_featr_id]
   , [ics_bs_mgmt_practices_id]
   , [ics_bs_prmt_id]
   , [ics_cafo_prmt_id]
   , [ics_gnrl_prmt_id]
   , [ics_sw_cnst_prmt_id]
   , [ics_sw_evt_rep_id]
   , [ics_sw_indst_prmt_id]
   , [ics_swms_4_large_prmt_id]
   , [ics_swms_4_prog_rep_id]
   , [ics_swms_4_small_prmt_id]
   , [ics_unprmt_fac_id]
   , [affil_type_txt]
   , [org_frml_name]
   , [org_duns_num]
   , [mailing_addr_txt]
   , [suppl_addr_txt]
   , [mailing_addr_city_name]
   , [mailing_addr_st_code]
   , [mailing_addr_zip_code]
   , [county_name]
   , [mailing_addr_country_code]
   , [division_name]
   , [loc_province]
   , [elec_addr_txt]
   , [start_date_of_addr_assc]
   , [end_date_of_addr_assc]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --ics_bs_mgmt_practices_id, 
   , null /* no mapping */ --ics_bs_prmt_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_sw_cnst_prmt_id, 
   , null /* no mapping */ --ics_sw_evt_rep_id, 
   , null /* no mapping */ --ics_sw_indst_prmt_id, 
   , null /* no mapping */ --ics_swms_4_large_prmt_id, 
   , null /* no mapping */ --ics_swms_4_prog_rep_id, 
   , null /* no mapping */ --ics_swms_4_small_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --affil_type_txt, AffiliationTypeText
   , null /* no mapping */ --org_frml_name, OrganizationFormalName
   , null /* no mapping */ --org_duns_num, OrganizationDUNSNumber
   , null /* no mapping */ --mailing_addr_txt, MailingAddressText
   , null /* no mapping */ --suppl_addr_txt, SupplementalAddressText
   , null /* no mapping */ --mailing_addr_city_name, MailingAddressCityName
   , null /* no mapping */ --mailing_addr_st_code, MailingAddressStateCode
   , null /* no mapping */ --mailing_addr_zip_code, MailingAddressZipCode
   , null /* no mapping */ --county_name, CountyName
   , null /* no mapping */ --mailing_addr_country_code, MailingAddressCountryCode
   , null /* no mapping */ --division_name, DivisionName
   , null /* no mapping */ --loc_province, LocationProvince
   , null /* no mapping */ --elec_addr_txt, ElectronicAddressText
   , null /* no mapping */ --start_date_of_addr_assc, StartDateOfAddressAssociation
   , null /* no mapping */ --end_date_of_addr_assc, EndDateOfAddressAssociation
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BASIC_PRMT/ICS_FAC/ICS_ADDR/ICS_TELEPH
INSERT INTO ICS_FLOW_LOCAL.ics_teleph (
     [ics_teleph_id]
   , [ics_contact_id]
   , [ics_addr_id]
   , [ics_efflu_trade_prtner_addr_id]
   , [teleph_num_type_code]
   , [teleph_num]
   , [teleph_ext_num]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_teleph_id, 
   , null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_efflu_trade_prtner_addr_id, 
   , null /* no mapping */ --teleph_num_type_code, TelephoneNumberTypeCode
   , null /* no mapping */ --teleph_num, TelephoneNumber
   , null /* no mapping */ --teleph_ext_num, TelephoneExtensionNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BASIC_PRMT/ICS_FAC/ICS_CONTACT
INSERT INTO ICS_FLOW_LOCAL.ics_contact (
     [ics_contact_id]
   , [ics_fac_id]
   , [ics_basic_prmt_id]
   , [ics_prmt_featr_id]
   , [ics_bs_mgmt_practices_id]
   , [ics_bs_annul_prog_rep_id]
   , [ics_bs_prmt_id]
   , [ics_cafo_prmt_id]
   , [ics_cmpl_mon_id]
   , [ics_gnrl_prmt_id]
   , [ics_master_gnrl_prmt_id]
   , [ics_pretr_prmt_id]
   , [ics_sw_cnst_prmt_id]
   , [ics_sw_evt_rep_id]
   , [ics_sw_indst_prmt_id]
   , [ics_swms_4_large_prmt_id]
   , [ics_swms_4_prog_rep_id]
   , [ics_swms_4_small_prmt_id]
   , [ics_unprmt_fac_id]
   , [affil_type_txt]
   , [first_name]
   , [middle_name]
   , [last_name]
   , [indvl_title_txt]
   , [org_frml_name]
   , [st_code]
   , [rgn_code]
   , [elec_addr_txt]
   , [start_date_of_contact_assc]
   , [end_date_of_contact_assc]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --ics_bs_mgmt_practices_id, 
   , null /* no mapping */ --ics_bs_annul_prog_rep_id, 
   , null /* no mapping */ --ics_bs_prmt_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_cmpl_mon_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_master_gnrl_prmt_id, 
   , null /* no mapping */ --ics_pretr_prmt_id, 
   , null /* no mapping */ --ics_sw_cnst_prmt_id, 
   , null /* no mapping */ --ics_sw_evt_rep_id, 
   , null /* no mapping */ --ics_sw_indst_prmt_id, 
   , null /* no mapping */ --ics_swms_4_large_prmt_id, 
   , null /* no mapping */ --ics_swms_4_prog_rep_id, 
   , null /* no mapping */ --ics_swms_4_small_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --affil_type_txt, AffiliationTypeText
   , null /* no mapping */ --first_name, FirstName
   , null /* no mapping */ --middle_name, MiddleName
   , null /* no mapping */ --last_name, LastName
   , null /* no mapping */ --indvl_title_txt, IndividualTitleText
   , null /* no mapping */ --org_frml_name, OrganizationFormalName
   , null /* no mapping */ --st_code, StateCode
   , null /* no mapping */ --rgn_code, RegionCode
   , null /* no mapping */ --elec_addr_txt, ElectronicAddressText
   , null /* no mapping */ --start_date_of_contact_assc, StartDateOfContactAssociation
   , null /* no mapping */ --end_date_of_contact_assc, EndDateOfContactAssociation
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BASIC_PRMT/ICS_FAC/ICS_CONTACT/ICS_TELEPH
INSERT INTO ICS_FLOW_LOCAL.ics_teleph (
     [ics_teleph_id]
   , [ics_contact_id]
   , [ics_addr_id]
   , [ics_efflu_trade_prtner_addr_id]
   , [teleph_num_type_code]
   , [teleph_num]
   , [teleph_ext_num]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_teleph_id, 
   , null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_efflu_trade_prtner_addr_id, 
   , null /* no mapping */ --teleph_num_type_code, TelephoneNumberTypeCode
   , null /* no mapping */ --teleph_num, TelephoneNumber
   , null /* no mapping */ --teleph_ext_num, TelephoneExtensionNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BASIC_PRMT/ICS_FAC/ICS_FAC_CLASS
INSERT INTO ICS_FLOW_LOCAL.ics_fac_class (
     [ics_fac_class_id]
   , [ics_fac_id]
   , [ics_unprmt_fac_id]
   , [fac_class]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_fac_class_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --fac_class, FacilityClassification
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BASIC_PRMT/ICS_FAC/ICS_GEO_COORD
INSERT INTO ICS_FLOW_LOCAL.ics_geo_coord (
     [ics_geo_coord_id]
   , [ics_fac_id]
   , [ics_prmt_featr_id]
   , [ics_unprmt_fac_id]
   , [lat_meas]
   , [long_meas]
   , [horz_accuracy_meas]
   , [geometric_type_code]
   , [horz_coll_method_code]
   , [horz_ref_datum_code]
   , [ref_point_code]
   , [src_map_scale_num]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_geo_coord_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --lat_meas, LatitudeMeasure
   , null /* no mapping */ --long_meas, LongitudeMeasure
   , null /* no mapping */ --horz_accuracy_meas, HorizontalAccuracyMeasure
   , null /* no mapping */ --geometric_type_code, GeometricTypeCode
   , null /* no mapping */ --horz_coll_method_code, HorizontalCollectionMethodCode
   , null /* no mapping */ --horz_ref_datum_code, HorizontalReferenceDatumCode
   , null /* no mapping */ --ref_point_code, ReferencePointCode
   , null /* no mapping */ --src_map_scale_num, SourceMapScaleNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BASIC_PRMT/ICS_FAC/ICS_NAICS_CODE
INSERT INTO ICS_FLOW_LOCAL.ics_naics_code (
     [ics_naics_code_id]
   , [ics_basic_prmt_id]
   , [ics_fac_id]
   , [ics_gnrl_prmt_id]
   , [ics_master_gnrl_prmt_id]
   , [ics_unprmt_fac_id]
   , [naics_code]
   , [naics_primary_ind_code]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_naics_code_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_master_gnrl_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --naics_code, NAICSCode
   , null /* no mapping */ --naics_primary_ind_code, NAICSPrimaryIndicatorCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BASIC_PRMT/ICS_FAC/ICS_ORIG_PROGS
INSERT INTO ICS_FLOW_LOCAL.ics_orig_progs (
     [ics_orig_progs_id]
   , [ics_fac_id]
   , [ics_unprmt_fac_id]
   , [orig_progs_code]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_orig_progs_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --orig_progs_code, OriginatingProgramsCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BASIC_PRMT/ICS_FAC/ICS_PLCY
INSERT INTO ICS_FLOW_LOCAL.ics_plcy (
     [ics_plcy_id]
   , [ics_fac_id]
   , [ics_unprmt_fac_id]
   , [plcy_code]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_plcy_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --plcy_code, PolicyCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BASIC_PRMT/ICS_FAC/ICS_SIC_CODE
INSERT INTO ICS_FLOW_LOCAL.ics_sic_code (
     [ics_sic_code_id]
   , [ics_basic_prmt_id]
   , [ics_fac_id]
   , [ics_gnrl_prmt_id]
   , [ics_master_gnrl_prmt_id]
   , [ics_unprmt_fac_id]
   , [sic_code]
   , [sic_primary_ind_code]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_sic_code_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_master_gnrl_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --sic_code, SICCode
   , null /* no mapping */ --sic_primary_ind_code, SICPrimaryIndicatorCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BASIC_PRMT/ICS_NAICS_CODE
INSERT INTO ICS_FLOW_LOCAL.ics_naics_code (
     [ics_naics_code_id]
   , [ics_basic_prmt_id]
   , [ics_fac_id]
   , [ics_gnrl_prmt_id]
   , [ics_master_gnrl_prmt_id]
   , [ics_unprmt_fac_id]
   , [naics_code]
   , [naics_primary_ind_code]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_naics_code_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_master_gnrl_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --naics_code, NAICSCode
   , null /* no mapping */ --naics_primary_ind_code, NAICSPrimaryIndicatorCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BASIC_PRMT/ICS_NPDES_DAT_GRP_NUM
INSERT INTO ICS_FLOW_LOCAL.ics_npdes_dat_grp_num (
     [ics_npdes_dat_grp_num_id]
   , [ics_basic_prmt_id]
   , [ics_gnrl_prmt_id]
   , [npdes_dat_grp_num_code]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_npdes_dat_grp_num_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --npdes_dat_grp_num_code, NPDESDataGroupNumberCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BASIC_PRMT/ICS_OTHR_PRMTS
INSERT INTO ICS_FLOW_LOCAL.ics_othr_prmts (
     [ics_othr_prmts_id]
   , [ics_basic_prmt_id]
   , [ics_gnrl_prmt_id]
   , [ics_master_gnrl_prmt_id]
   , [othr_prmt_ident]
   , [othr_org_name]
   , [othr_prmt_ident_cntxt_name]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_othr_prmts_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_master_gnrl_prmt_id, 
   , null /* no mapping */ --othr_prmt_ident, OtherPermitIdentifier
   , null /* no mapping */ --othr_org_name, OtherOrganizationName
   , null /* no mapping */ --othr_prmt_ident_cntxt_name, OtherPermitIdentifierContextName
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BASIC_PRMT/ICS_REP_NON_CMPL_STAT
INSERT INTO ICS_FLOW_LOCAL.ics_rep_non_cmpl_stat (
     [ics_rep_non_cmpl_stat_id]
   , [ics_basic_prmt_id]
   , [ics_gnrl_prmt_id]
   , [rep_non_cmpl_stat_code_year]
   , [rep_non_cmpl_stat_code_quarter]
   , [rep_non_cmpl_manual_stat_code]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_rep_non_cmpl_stat_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --rep_non_cmpl_stat_code_year, ReportableNonComplianceStatusCodeYear
   , null /* no mapping */ --rep_non_cmpl_stat_code_quarter, ReportableNonComplianceStatusCodeQuarter
   , null /* no mapping */ --rep_non_cmpl_manual_stat_code, ReportableNonComplianceManualStatusCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BASIC_PRMT/ICS_SIC_CODE
INSERT INTO ICS_FLOW_LOCAL.ics_sic_code (
     [ics_sic_code_id]
   , [ics_basic_prmt_id]
   , [ics_fac_id]
   , [ics_gnrl_prmt_id]
   , [ics_master_gnrl_prmt_id]
   , [ics_unprmt_fac_id]
   , [sic_code]
   , [sic_primary_ind_code]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_sic_code_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_master_gnrl_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --sic_code, SICCode
   , null /* no mapping */ --sic_primary_ind_code, SICPrimaryIndicatorCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

