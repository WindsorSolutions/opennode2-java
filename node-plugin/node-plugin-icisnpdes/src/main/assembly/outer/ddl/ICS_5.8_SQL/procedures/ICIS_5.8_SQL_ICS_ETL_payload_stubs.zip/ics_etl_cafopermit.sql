﻿IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'ICS_FLOW_LOCAL.ics_etl_cafopermit') AND type in (N'P', N'PC'))
DROP PROCEDURE ICS_FLOW_LOCAL.ics_etl_cafopermit
GO


/*************************************************************************************************
** ObjectName: ics_etl_cafopermit
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the CAFOPermitSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE PROCEDURE ICS_FLOW_LOCAL.ics_etl_cafopermit

AS

---------------------------- 
-- ICS_CAFO_PRMT
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_CAFO_PRMT/ICS_ADDR/ICS_TELEPH
DELETE
  FROM ICS_FLOW_LOCAL.ics_teleph
 WHERE ics_addr_id IN
          (SELECT ics_addr.ics_addr_id
             FROM ICS_FLOW_LOCAL.ics_cafo_prmt
                  JOIN ICS_FLOW_LOCAL.ics_addr ON ics_addr.ics_cafo_prmt_id = ics_cafo_prmt.ics_cafo_prmt_id
          );

-- /ICS_CAFO_PRMT/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM ICS_FLOW_LOCAL.ics_teleph
 WHERE ics_contact_id IN
          (SELECT ics_contact.ics_contact_id
             FROM ICS_FLOW_LOCAL.ics_cafo_prmt
                  JOIN ICS_FLOW_LOCAL.ics_contact ON ics_contact.ics_cafo_prmt_id = ics_cafo_prmt.ics_cafo_prmt_id
          );

-- /ICS_CAFO_PRMT/ICS_ADDR
DELETE
  FROM ICS_FLOW_LOCAL.ics_addr
 WHERE ics_cafo_prmt_id IN
          (SELECT ics_cafo_prmt.ics_cafo_prmt_id
             FROM ICS_FLOW_LOCAL.ics_cafo_prmt
          );

-- /ICS_CAFO_PRMT/ICS_ANML_TYPE
DELETE
  FROM ICS_FLOW_LOCAL.ics_anml_type
 WHERE ics_cafo_prmt_id IN
          (SELECT ics_cafo_prmt.ics_cafo_prmt_id
             FROM ICS_FLOW_LOCAL.ics_cafo_prmt
          );

-- /ICS_CAFO_PRMT/ICS_CONTACT
DELETE
  FROM ICS_FLOW_LOCAL.ics_contact
 WHERE ics_cafo_prmt_id IN
          (SELECT ics_cafo_prmt.ics_cafo_prmt_id
             FROM ICS_FLOW_LOCAL.ics_cafo_prmt
          );

-- /ICS_CAFO_PRMT/ICS_CONTAINMENT
DELETE
  FROM ICS_FLOW_LOCAL.ics_containment
 WHERE ics_cafo_prmt_id IN
          (SELECT ics_cafo_prmt.ics_cafo_prmt_id
             FROM ICS_FLOW_LOCAL.ics_cafo_prmt
          );

-- /ICS_CAFO_PRMT/ICS_LAND_APPL_BMP
DELETE
  FROM ICS_FLOW_LOCAL.ics_land_appl_bmp
 WHERE ics_cafo_prmt_id IN
          (SELECT ics_cafo_prmt.ics_cafo_prmt_id
             FROM ICS_FLOW_LOCAL.ics_cafo_prmt
          );

-- /ICS_CAFO_PRMT/ICS_MNUR_LTTR_PRCSS_WW_STOR
DELETE
  FROM ICS_FLOW_LOCAL.ics_mnur_lttr_prcss_ww_stor
 WHERE ics_cafo_prmt_id IN
          (SELECT ics_cafo_prmt.ics_cafo_prmt_id
             FROM ICS_FLOW_LOCAL.ics_cafo_prmt
          );

-- /ICS_CAFO_PRMT
DELETE
  FROM ICS_FLOW_LOCAL.ics_cafo_prmt;


-- /ICS_CAFO_PRMT
INSERT INTO ICS_FLOW_LOCAL.ics_cafo_prmt (
     [ics_cafo_prmt_id]
   , [ics_payload_id]
   , [src_systm_ident]
   , [transaction_type]
   , [transaction_timestamp]
   , [prmt_ident]
   , [cafo_class_code]
   , [is_anml_fac_type_cafo_ind]
   , [cafo_desgn_date]
   , [cafo_desgn_reason_txt]
   , [num_acres_contrb_drain]
   , [appl_meas_avail_land_num]
   , [solid_mnur_lttr_gnrtd_amt]
   , [liquid_mnur_ww_gnrtd_amt]
   , [solid_mnur_lttr_trans_amt]
   , [liquid_mnur_ww_trans_amt]
   , [nmp_dvlpd_cert_plnr_aprvd_ind]
   , [nmp_dvlpd_date]
   , [nmp_last_updated_date]
   , [envr_mgmt_systm_ind]
   , [ems_dvlpd_date]
   , [ems_last_updated_date]
   , [lvstck_max_cpcty_num]
   , [lvstck_cpcty_dtrmn_bs_upon_num]
   , [auth_lvstck_cpcty_num]
   , [legal_desc_txt]
   , [key_hash]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --cafo_class_code, CAFOClassificationCode
   , null /* no mapping */ --is_anml_fac_type_cafo_ind, IsAnimalFacilityTypeCAFOIndicator
   , null /* no mapping */ --cafo_desgn_date, CAFODesignationDate
   , null /* no mapping */ --cafo_desgn_reason_txt, CAFODesignationReasonText
   , null /* no mapping */ --num_acres_contrb_drain, NumberAcresContributingDrainage
   , null /* no mapping */ --appl_meas_avail_land_num, ApplicationMeasureAvailableLandNumber
   , null /* no mapping */ --solid_mnur_lttr_gnrtd_amt, SolidManureLitterGeneratedAmount
   , null /* no mapping */ --liquid_mnur_ww_gnrtd_amt, LiquidManureWastewaterGeneratedAmount
   , null /* no mapping */ --solid_mnur_lttr_trans_amt, SolidManureLitterTransferAmount
   , null /* no mapping */ --liquid_mnur_ww_trans_amt, LiquidManureWastewaterTransferAmount
   , null /* no mapping */ --nmp_dvlpd_cert_plnr_aprvd_ind, NMPDevelopedCertifiedPlannerApprovedIndicator
   , null /* no mapping */ --nmp_dvlpd_date, NMPDevelopedDate
   , null /* no mapping */ --nmp_last_updated_date, NMPLastUpdatedDate
   , null /* no mapping */ --envr_mgmt_systm_ind, EnvironmentalManagementSystemIndicator
   , null /* no mapping */ --ems_dvlpd_date, EMSDevelopedDate
   , null /* no mapping */ --ems_last_updated_date, EMSLastUpdatedDate
   , null /* no mapping */ --lvstck_max_cpcty_num, LivestockMaximumCapacityNumber
   , null /* no mapping */ --lvstck_cpcty_dtrmn_bs_upon_num, LivestockCapacityDeterminationBasedUponNumber
   , null /* no mapping */ --auth_lvstck_cpcty_num, AuthorizedLivestockCapacityNumber
   , null /* no mapping */ --legal_desc_txt, LegalDescriptionText
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CAFO_PRMT/ICS_ADDR
INSERT INTO ICS_FLOW_LOCAL.ics_addr (
     [ics_addr_id]
   , [ics_fac_id]
   , [ics_basic_prmt_id]
   , [ics_prmt_featr_id]
   , [ics_bs_mgmt_practices_id]
   , [ics_bs_prmt_id]
   , [ics_cafo_prmt_id]
   , [ics_gnrl_prmt_id]
   , [ics_sw_cnst_prmt_id]
   , [ics_sw_evt_rep_id]
   , [ics_sw_indst_prmt_id]
   , [ics_swms_4_large_prmt_id]
   , [ics_swms_4_prog_rep_id]
   , [ics_swms_4_small_prmt_id]
   , [ics_unprmt_fac_id]
   , [affil_type_txt]
   , [org_frml_name]
   , [org_duns_num]
   , [mailing_addr_txt]
   , [suppl_addr_txt]
   , [mailing_addr_city_name]
   , [mailing_addr_st_code]
   , [mailing_addr_zip_code]
   , [county_name]
   , [mailing_addr_country_code]
   , [division_name]
   , [loc_province]
   , [elec_addr_txt]
   , [start_date_of_addr_assc]
   , [end_date_of_addr_assc]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --ics_bs_mgmt_practices_id, 
   , null /* no mapping */ --ics_bs_prmt_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_sw_cnst_prmt_id, 
   , null /* no mapping */ --ics_sw_evt_rep_id, 
   , null /* no mapping */ --ics_sw_indst_prmt_id, 
   , null /* no mapping */ --ics_swms_4_large_prmt_id, 
   , null /* no mapping */ --ics_swms_4_prog_rep_id, 
   , null /* no mapping */ --ics_swms_4_small_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --affil_type_txt, AffiliationTypeText
   , null /* no mapping */ --org_frml_name, OrganizationFormalName
   , null /* no mapping */ --org_duns_num, OrganizationDUNSNumber
   , null /* no mapping */ --mailing_addr_txt, MailingAddressText
   , null /* no mapping */ --suppl_addr_txt, SupplementalAddressText
   , null /* no mapping */ --mailing_addr_city_name, MailingAddressCityName
   , null /* no mapping */ --mailing_addr_st_code, MailingAddressStateCode
   , null /* no mapping */ --mailing_addr_zip_code, MailingAddressZipCode
   , null /* no mapping */ --county_name, CountyName
   , null /* no mapping */ --mailing_addr_country_code, MailingAddressCountryCode
   , null /* no mapping */ --division_name, DivisionName
   , null /* no mapping */ --loc_province, LocationProvince
   , null /* no mapping */ --elec_addr_txt, ElectronicAddressText
   , null /* no mapping */ --start_date_of_addr_assc, StartDateOfAddressAssociation
   , null /* no mapping */ --end_date_of_addr_assc, EndDateOfAddressAssociation
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CAFO_PRMT/ICS_ADDR/ICS_TELEPH
INSERT INTO ICS_FLOW_LOCAL.ics_teleph (
     [ics_teleph_id]
   , [ics_contact_id]
   , [ics_addr_id]
   , [ics_efflu_trade_prtner_addr_id]
   , [teleph_num_type_code]
   , [teleph_num]
   , [teleph_ext_num]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_teleph_id, 
   , null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_efflu_trade_prtner_addr_id, 
   , null /* no mapping */ --teleph_num_type_code, TelephoneNumberTypeCode
   , null /* no mapping */ --teleph_num, TelephoneNumber
   , null /* no mapping */ --teleph_ext_num, TelephoneExtensionNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CAFO_PRMT/ICS_ANML_TYPE
INSERT INTO ICS_FLOW_LOCAL.ics_anml_type (
     [ics_anml_type_id]
   , [ics_cafo_prmt_id]
   , [ics_cafo_insp_id]
   , [anml_type_code]
   , [othr_anml_type_name]
   , [ttl_num_each_lvstck]
   , [open_confinemnt_cnt]
   , [housd_undr_roof_confinemnt_cnt]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_anml_type_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_cafo_insp_id, 
   , null /* no mapping */ --anml_type_code, AnimalTypeCode
   , null /* no mapping */ --othr_anml_type_name, OtherAnimalTypeName
   , null /* no mapping */ --ttl_num_each_lvstck, TotalNumbersEachLivestock
   , null /* no mapping */ --open_confinemnt_cnt, OpenConfinementCount
   , null /* no mapping */ --housd_undr_roof_confinemnt_cnt, HousedUnderRoofConfinementCount
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CAFO_PRMT/ICS_CONTACT
INSERT INTO ICS_FLOW_LOCAL.ics_contact (
     [ics_contact_id]
   , [ics_fac_id]
   , [ics_basic_prmt_id]
   , [ics_prmt_featr_id]
   , [ics_bs_mgmt_practices_id]
   , [ics_bs_annul_prog_rep_id]
   , [ics_bs_prmt_id]
   , [ics_cafo_prmt_id]
   , [ics_cmpl_mon_id]
   , [ics_gnrl_prmt_id]
   , [ics_master_gnrl_prmt_id]
   , [ics_pretr_prmt_id]
   , [ics_sw_cnst_prmt_id]
   , [ics_sw_evt_rep_id]
   , [ics_sw_indst_prmt_id]
   , [ics_swms_4_large_prmt_id]
   , [ics_swms_4_prog_rep_id]
   , [ics_swms_4_small_prmt_id]
   , [ics_unprmt_fac_id]
   , [affil_type_txt]
   , [first_name]
   , [middle_name]
   , [last_name]
   , [indvl_title_txt]
   , [org_frml_name]
   , [st_code]
   , [rgn_code]
   , [elec_addr_txt]
   , [start_date_of_contact_assc]
   , [end_date_of_contact_assc]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --ics_bs_mgmt_practices_id, 
   , null /* no mapping */ --ics_bs_annul_prog_rep_id, 
   , null /* no mapping */ --ics_bs_prmt_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_cmpl_mon_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_master_gnrl_prmt_id, 
   , null /* no mapping */ --ics_pretr_prmt_id, 
   , null /* no mapping */ --ics_sw_cnst_prmt_id, 
   , null /* no mapping */ --ics_sw_evt_rep_id, 
   , null /* no mapping */ --ics_sw_indst_prmt_id, 
   , null /* no mapping */ --ics_swms_4_large_prmt_id, 
   , null /* no mapping */ --ics_swms_4_prog_rep_id, 
   , null /* no mapping */ --ics_swms_4_small_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --affil_type_txt, AffiliationTypeText
   , null /* no mapping */ --first_name, FirstName
   , null /* no mapping */ --middle_name, MiddleName
   , null /* no mapping */ --last_name, LastName
   , null /* no mapping */ --indvl_title_txt, IndividualTitleText
   , null /* no mapping */ --org_frml_name, OrganizationFormalName
   , null /* no mapping */ --st_code, StateCode
   , null /* no mapping */ --rgn_code, RegionCode
   , null /* no mapping */ --elec_addr_txt, ElectronicAddressText
   , null /* no mapping */ --start_date_of_contact_assc, StartDateOfContactAssociation
   , null /* no mapping */ --end_date_of_contact_assc, EndDateOfContactAssociation
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CAFO_PRMT/ICS_CONTACT/ICS_TELEPH
INSERT INTO ICS_FLOW_LOCAL.ics_teleph (
     [ics_teleph_id]
   , [ics_contact_id]
   , [ics_addr_id]
   , [ics_efflu_trade_prtner_addr_id]
   , [teleph_num_type_code]
   , [teleph_num]
   , [teleph_ext_num]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_teleph_id, 
   , null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_efflu_trade_prtner_addr_id, 
   , null /* no mapping */ --teleph_num_type_code, TelephoneNumberTypeCode
   , null /* no mapping */ --teleph_num, TelephoneNumber
   , null /* no mapping */ --teleph_ext_num, TelephoneExtensionNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CAFO_PRMT/ICS_CONTAINMENT
INSERT INTO ICS_FLOW_LOCAL.ics_containment (
     [ics_containment_id]
   , [ics_cafo_prmt_id]
   , [ics_cafo_insp_id]
   , [containment_type_code]
   , [othr_containment_type_name]
   , [containment_cpcty_num]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_containment_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_cafo_insp_id, 
   , null /* no mapping */ --containment_type_code, ContainmentTypeCode
   , null /* no mapping */ --othr_containment_type_name, OtherContainmentTypeName
   , null /* no mapping */ --containment_cpcty_num, ContainmentCapacityNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CAFO_PRMT/ICS_LAND_APPL_BMP
INSERT INTO ICS_FLOW_LOCAL.ics_land_appl_bmp (
     [ics_land_appl_bmp_id]
   , [ics_cafo_prmt_id]
   , [ics_cafo_insp_id]
   , [land_appl_bmp_type_code]
   , [othr_land_appl_bmp_type_name]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_land_appl_bmp_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_cafo_insp_id, 
   , null /* no mapping */ --land_appl_bmp_type_code, LandApplicationBMPTypeCode
   , null /* no mapping */ --othr_land_appl_bmp_type_name, OtherLandApplicationBMPTypeName
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CAFO_PRMT/ICS_MNUR_LTTR_PRCSS_WW_STOR
INSERT INTO ICS_FLOW_LOCAL.ics_mnur_lttr_prcss_ww_stor (
     [ics_mnur_lttr_prcss_ww_stor_id]
   , [ics_cafo_prmt_id]
   , [ics_cafo_insp_id]
   , [mnur_lttr_prcss_ww_stor_type]
   , [othr_stor_type_name]
   , [stor_ttl_cpcty_meas]
   , [days_of_stor]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_mnur_lttr_prcss_ww_stor_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_cafo_insp_id, 
   , null /* no mapping */ --mnur_lttr_prcss_ww_stor_type, ManureLitterProcessedWastewaterStorageType
   , null /* no mapping */ --othr_stor_type_name, OtherStorageTypeName
   , null /* no mapping */ --stor_ttl_cpcty_meas, StorageTotalCapacityMeasure
   , null /* no mapping */ --days_of_stor, DaysOfStorage
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

