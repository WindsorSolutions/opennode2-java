﻿IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'ICS_FLOW_LOCAL.ics_etl_permittrackingevent') AND type in (N'P', N'PC'))
DROP PROCEDURE ICS_FLOW_LOCAL.ics_etl_permittrackingevent
GO


/*************************************************************************************************
** ObjectName: ics_etl_permittrackingevent
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the PermitTrackingEventSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE PROCEDURE ICS_FLOW_LOCAL.ics_etl_permittrackingevent

AS

---------------------------- 
-- ICS_PRMT_TRACK_EVT
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_PRMT_TRACK_EVT
DELETE
  FROM ICS_FLOW_LOCAL.ics_prmt_track_evt;


-- /ICS_PRMT_TRACK_EVT
INSERT INTO ICS_FLOW_LOCAL.ics_prmt_track_evt (
     [ics_prmt_track_evt_id]
   , [ics_payload_id]
   , [src_systm_ident]
   , [transaction_type]
   , [transaction_timestamp]
   , [prmt_ident]
   , [prmt_track_evt_code]
   , [prmt_track_evt_date]
   , [prmt_track_cmnts_txt]
   , [key_hash]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_prmt_track_evt_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --prmt_track_evt_code, PermitTrackingEventCode
   , null /* no mapping */ --prmt_track_evt_date, PermitTrackingEventDate
   , null /* no mapping */ --prmt_track_cmnts_txt, PermitTrackingCommentsText
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

