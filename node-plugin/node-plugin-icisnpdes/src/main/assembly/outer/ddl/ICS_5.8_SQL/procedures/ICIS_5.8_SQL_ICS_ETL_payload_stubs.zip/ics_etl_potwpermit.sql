﻿IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'ICS_FLOW_LOCAL.ics_etl_potwpermit') AND type in (N'P', N'PC'))
DROP PROCEDURE ICS_FLOW_LOCAL.ics_etl_potwpermit
GO


/*************************************************************************************************
** ObjectName: ics_etl_potwpermit
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the POTWPermitSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE PROCEDURE ICS_FLOW_LOCAL.ics_etl_potwpermit

AS

---------------------------- 
-- ICS_POTW_PRMT
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_POTW_PRMT/ICS_SATL_COLL_SYSTM
DELETE
  FROM ICS_FLOW_LOCAL.ics_satl_coll_systm
 WHERE ics_potw_prmt_id IN
          (SELECT ics_potw_prmt.ics_potw_prmt_id
             FROM ICS_FLOW_LOCAL.ics_potw_prmt
          );

-- /ICS_POTW_PRMT
DELETE
  FROM ICS_FLOW_LOCAL.ics_potw_prmt;


-- /ICS_POTW_PRMT
INSERT INTO ICS_FLOW_LOCAL.ics_potw_prmt (
     [ics_potw_prmt_id]
   , [ics_payload_id]
   , [src_systm_ident]
   , [transaction_type]
   , [transaction_timestamp]
   , [prmt_ident]
   , [sscs_popl_served_num]
   , [combined_sscs_systm_length]
   , [key_hash]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_potw_prmt_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --sscs_popl_served_num, SSCSPopulationServedNumber
   , null /* no mapping */ --combined_sscs_systm_length, CombinedSSCSSystemLength
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_POTW_PRMT/ICS_SATL_COLL_SYSTM
INSERT INTO ICS_FLOW_LOCAL.ics_satl_coll_systm (
     [ics_satl_coll_systm_id]
   , [ics_cso_prmt_id]
   , [ics_potw_prmt_id]
   , [satl_coll_systm_ident]
   , [satl_coll_systm_name]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_satl_coll_systm_id, 
   , null /* no mapping */ --ics_cso_prmt_id, 
   , null /* no mapping */ --ics_potw_prmt_id, 
   , null /* no mapping */ --satl_coll_systm_ident, SatelliteCollectionSystemIdentifier
   , null /* no mapping */ --satl_coll_systm_name, SatelliteCollectionSystemName
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

