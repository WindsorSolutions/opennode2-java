﻿IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'ICS_FLOW_LOCAL.ics_etl_csopermit') AND type in (N'P', N'PC'))
DROP PROCEDURE ICS_FLOW_LOCAL.ics_etl_csopermit
GO


/*************************************************************************************************
** ObjectName: ics_etl_csopermit
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the CSOPermitSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE PROCEDURE ICS_FLOW_LOCAL.ics_etl_csopermit

AS

---------------------------- 
-- ICS_CSO_PRMT
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_CSO_PRMT/ICS_SATL_COLL_SYSTM
DELETE
  FROM ICS_FLOW_LOCAL.ics_satl_coll_systm
 WHERE ics_cso_prmt_id IN
          (SELECT ics_cso_prmt.ics_cso_prmt_id
             FROM ICS_FLOW_LOCAL.ics_cso_prmt
          );

-- /ICS_CSO_PRMT
DELETE
  FROM ICS_FLOW_LOCAL.ics_cso_prmt;


-- /ICS_CSO_PRMT
INSERT INTO ICS_FLOW_LOCAL.ics_cso_prmt (
     [ics_cso_prmt_id]
   , [ics_payload_id]
   , [src_systm_ident]
   , [transaction_type]
   , [transaction_timestamp]
   , [prmt_ident]
   , [css_popl_served_num]
   , [combined_sewer_systm_length]
   , [coll_systm_combined_percent]
   , [key_hash]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_cso_prmt_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --css_popl_served_num, CSSPopulationServedNumber
   , null /* no mapping */ --combined_sewer_systm_length, CombinedSewerSystemLength
   , null /* no mapping */ --coll_systm_combined_percent, CollectionSystemCombinedPercent
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CSO_PRMT/ICS_SATL_COLL_SYSTM
INSERT INTO ICS_FLOW_LOCAL.ics_satl_coll_systm (
     [ics_satl_coll_systm_id]
   , [ics_cso_prmt_id]
   , [ics_potw_prmt_id]
   , [satl_coll_systm_ident]
   , [satl_coll_systm_name]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_satl_coll_systm_id, 
   , null /* no mapping */ --ics_cso_prmt_id, 
   , null /* no mapping */ --ics_potw_prmt_id, 
   , null /* no mapping */ --satl_coll_systm_ident, SatelliteCollectionSystemIdentifier
   , null /* no mapping */ --satl_coll_systm_name, SatelliteCollectionSystemName
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

