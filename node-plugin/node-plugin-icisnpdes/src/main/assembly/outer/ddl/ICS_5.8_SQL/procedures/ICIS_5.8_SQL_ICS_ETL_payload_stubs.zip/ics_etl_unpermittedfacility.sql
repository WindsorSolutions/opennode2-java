﻿IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'ICS_FLOW_LOCAL.ics_etl_unpermittedfacility') AND type in (N'P', N'PC'))
DROP PROCEDURE ICS_FLOW_LOCAL.ics_etl_unpermittedfacility
GO


/*************************************************************************************************
** ObjectName: ics_etl_unpermittedfacility
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the UnpermittedFacilitySubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE PROCEDURE ICS_FLOW_LOCAL.ics_etl_unpermittedfacility

AS

---------------------------- 
-- ICS_UNPRMT_FAC
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_UNPRMT_FAC/ICS_ADDR/ICS_TELEPH
DELETE
  FROM ICS_FLOW_LOCAL.ics_teleph
 WHERE ics_addr_id IN
          (SELECT ics_addr.ics_addr_id
             FROM ICS_FLOW_LOCAL.ics_unprmt_fac
                  JOIN ICS_FLOW_LOCAL.ics_addr ON ics_addr.ics_unprmt_fac_id = ics_unprmt_fac.ics_unprmt_fac_id
          );

-- /ICS_UNPRMT_FAC/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM ICS_FLOW_LOCAL.ics_teleph
 WHERE ics_contact_id IN
          (SELECT ics_contact.ics_contact_id
             FROM ICS_FLOW_LOCAL.ics_unprmt_fac
                  JOIN ICS_FLOW_LOCAL.ics_contact ON ics_contact.ics_unprmt_fac_id = ics_unprmt_fac.ics_unprmt_fac_id
          );

-- /ICS_UNPRMT_FAC/ICS_ADDR
DELETE
  FROM ICS_FLOW_LOCAL.ics_addr
 WHERE ics_unprmt_fac_id IN
          (SELECT ics_unprmt_fac.ics_unprmt_fac_id
             FROM ICS_FLOW_LOCAL.ics_unprmt_fac
          );

-- /ICS_UNPRMT_FAC/ICS_CONTACT
DELETE
  FROM ICS_FLOW_LOCAL.ics_contact
 WHERE ics_unprmt_fac_id IN
          (SELECT ics_unprmt_fac.ics_unprmt_fac_id
             FROM ICS_FLOW_LOCAL.ics_unprmt_fac
          );

-- /ICS_UNPRMT_FAC/ICS_FAC_CLASS
DELETE
  FROM ICS_FLOW_LOCAL.ics_fac_class
 WHERE ics_unprmt_fac_id IN
          (SELECT ics_unprmt_fac.ics_unprmt_fac_id
             FROM ICS_FLOW_LOCAL.ics_unprmt_fac
          );

-- /ICS_UNPRMT_FAC/ICS_GEO_COORD
DELETE
  FROM ICS_FLOW_LOCAL.ics_geo_coord
 WHERE ics_unprmt_fac_id IN
          (SELECT ics_unprmt_fac.ics_unprmt_fac_id
             FROM ICS_FLOW_LOCAL.ics_unprmt_fac
          );

-- /ICS_UNPRMT_FAC/ICS_NAICS_CODE
DELETE
  FROM ICS_FLOW_LOCAL.ics_naics_code
 WHERE ics_unprmt_fac_id IN
          (SELECT ics_unprmt_fac.ics_unprmt_fac_id
             FROM ICS_FLOW_LOCAL.ics_unprmt_fac
          );

-- /ICS_UNPRMT_FAC/ICS_ORIG_PROGS
DELETE
  FROM ICS_FLOW_LOCAL.ics_orig_progs
 WHERE ics_unprmt_fac_id IN
          (SELECT ics_unprmt_fac.ics_unprmt_fac_id
             FROM ICS_FLOW_LOCAL.ics_unprmt_fac
          );

-- /ICS_UNPRMT_FAC/ICS_PLCY
DELETE
  FROM ICS_FLOW_LOCAL.ics_plcy
 WHERE ics_unprmt_fac_id IN
          (SELECT ics_unprmt_fac.ics_unprmt_fac_id
             FROM ICS_FLOW_LOCAL.ics_unprmt_fac
          );

-- /ICS_UNPRMT_FAC/ICS_PRMT_COMP_TYPE
DELETE
  FROM ICS_FLOW_LOCAL.ics_prmt_comp_type
 WHERE ics_unprmt_fac_id IN
          (SELECT ics_unprmt_fac.ics_unprmt_fac_id
             FROM ICS_FLOW_LOCAL.ics_unprmt_fac
          );

-- /ICS_UNPRMT_FAC/ICS_SIC_CODE
DELETE
  FROM ICS_FLOW_LOCAL.ics_sic_code
 WHERE ics_unprmt_fac_id IN
          (SELECT ics_unprmt_fac.ics_unprmt_fac_id
             FROM ICS_FLOW_LOCAL.ics_unprmt_fac
          );

-- /ICS_UNPRMT_FAC
DELETE
  FROM ICS_FLOW_LOCAL.ics_unprmt_fac;


-- /ICS_UNPRMT_FAC
INSERT INTO ICS_FLOW_LOCAL.ics_unprmt_fac (
     [ics_unprmt_fac_id]
   , [ics_payload_id]
   , [src_systm_ident]
   , [transaction_type]
   , [transaction_timestamp]
   , [prmt_ident]
   , [fac_site_name]
   , [loc_addr_txt]
   , [suppl_loc_txt]
   , [locality_name]
   , [loc_addr_city_code]
   , [loc_addr_county_code]
   , [loc_st_code]
   , [loc_zip_code]
   , [loc_country_code]
   , [org_duns_num]
   , [st_fac_ident]
   , [st_rgn_code]
   , [fac_congr_district_num]
   , [fac_type_of_ownership_code]
   , [fedr_fac_ident_num]
   , [fedr_agncy_code]
   , [tribal_land_code]
   , [cnst_proj_name]
   , [cnst_proj_lat_meas]
   , [cnst_proj_long_meas]
   , [section_township_rng]
   , [fac_cmnts]
   , [fac_usr_dfnd_fld_1]
   , [fac_usr_dfnd_fld_2]
   , [fac_usr_dfnd_fld_3]
   , [fac_usr_dfnd_fld_4]
   , [fac_usr_dfnd_fld_5]
   , [prmt_cmnts_txt]
   , [key_hash]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --fac_site_name, FacilitySiteName
   , null /* no mapping */ --loc_addr_txt, LocationAddressText
   , null /* no mapping */ --suppl_loc_txt, SupplementalLocationText
   , null /* no mapping */ --locality_name, LocalityName
   , null /* no mapping */ --loc_addr_city_code, LocationAddressCityCode
   , null /* no mapping */ --loc_addr_county_code, LocationAddressCountyCode
   , null /* no mapping */ --loc_st_code, LocationStateCode
   , null /* no mapping */ --loc_zip_code, LocationZipCode
   , null /* no mapping */ --loc_country_code, LocationCountryCode
   , null /* no mapping */ --org_duns_num, OrganizationDUNSNumber
   , null /* no mapping */ --st_fac_ident, StateFacilityIdentifier
   , null /* no mapping */ --st_rgn_code, StateRegionCode
   , null /* no mapping */ --fac_congr_district_num, FacilityCongressionalDistrictNumber
   , null /* no mapping */ --fac_type_of_ownership_code, FacilityTypeOfOwnershipCode
   , null /* no mapping */ --fedr_fac_ident_num, FederalFacilityIdentificationNumber
   , null /* no mapping */ --fedr_agncy_code, FederalAgencyCode
   , null /* no mapping */ --tribal_land_code, TribalLandCode
   , null /* no mapping */ --cnst_proj_name, ConstructionProjectName
   , null /* no mapping */ --cnst_proj_lat_meas, ConstructionProjectLatitudeMeasure
   , null /* no mapping */ --cnst_proj_long_meas, ConstructionProjectLongitudeMeasure
   , null /* no mapping */ --section_township_rng, SectionTownshipRange
   , null /* no mapping */ --fac_cmnts, FacilityComments
   , null /* no mapping */ --fac_usr_dfnd_fld_1, FacilityUserDefinedField1
   , null /* no mapping */ --fac_usr_dfnd_fld_2, FacilityUserDefinedField2
   , null /* no mapping */ --fac_usr_dfnd_fld_3, FacilityUserDefinedField3
   , null /* no mapping */ --fac_usr_dfnd_fld_4, FacilityUserDefinedField4
   , null /* no mapping */ --fac_usr_dfnd_fld_5, FacilityUserDefinedField5
   , null /* no mapping */ --prmt_cmnts_txt, PermitCommentsText
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_UNPRMT_FAC/ICS_ADDR
INSERT INTO ICS_FLOW_LOCAL.ics_addr (
     [ics_addr_id]
   , [ics_fac_id]
   , [ics_basic_prmt_id]
   , [ics_prmt_featr_id]
   , [ics_bs_mgmt_practices_id]
   , [ics_bs_prmt_id]
   , [ics_cafo_prmt_id]
   , [ics_gnrl_prmt_id]
   , [ics_sw_cnst_prmt_id]
   , [ics_sw_evt_rep_id]
   , [ics_sw_indst_prmt_id]
   , [ics_swms_4_large_prmt_id]
   , [ics_swms_4_prog_rep_id]
   , [ics_swms_4_small_prmt_id]
   , [ics_unprmt_fac_id]
   , [affil_type_txt]
   , [org_frml_name]
   , [org_duns_num]
   , [mailing_addr_txt]
   , [suppl_addr_txt]
   , [mailing_addr_city_name]
   , [mailing_addr_st_code]
   , [mailing_addr_zip_code]
   , [county_name]
   , [mailing_addr_country_code]
   , [division_name]
   , [loc_province]
   , [elec_addr_txt]
   , [start_date_of_addr_assc]
   , [end_date_of_addr_assc]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --ics_bs_mgmt_practices_id, 
   , null /* no mapping */ --ics_bs_prmt_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_sw_cnst_prmt_id, 
   , null /* no mapping */ --ics_sw_evt_rep_id, 
   , null /* no mapping */ --ics_sw_indst_prmt_id, 
   , null /* no mapping */ --ics_swms_4_large_prmt_id, 
   , null /* no mapping */ --ics_swms_4_prog_rep_id, 
   , null /* no mapping */ --ics_swms_4_small_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --affil_type_txt, AffiliationTypeText
   , null /* no mapping */ --org_frml_name, OrganizationFormalName
   , null /* no mapping */ --org_duns_num, OrganizationDUNSNumber
   , null /* no mapping */ --mailing_addr_txt, MailingAddressText
   , null /* no mapping */ --suppl_addr_txt, SupplementalAddressText
   , null /* no mapping */ --mailing_addr_city_name, MailingAddressCityName
   , null /* no mapping */ --mailing_addr_st_code, MailingAddressStateCode
   , null /* no mapping */ --mailing_addr_zip_code, MailingAddressZipCode
   , null /* no mapping */ --county_name, CountyName
   , null /* no mapping */ --mailing_addr_country_code, MailingAddressCountryCode
   , null /* no mapping */ --division_name, DivisionName
   , null /* no mapping */ --loc_province, LocationProvince
   , null /* no mapping */ --elec_addr_txt, ElectronicAddressText
   , null /* no mapping */ --start_date_of_addr_assc, StartDateOfAddressAssociation
   , null /* no mapping */ --end_date_of_addr_assc, EndDateOfAddressAssociation
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_UNPRMT_FAC/ICS_ADDR/ICS_TELEPH
INSERT INTO ICS_FLOW_LOCAL.ics_teleph (
     [ics_teleph_id]
   , [ics_contact_id]
   , [ics_addr_id]
   , [ics_efflu_trade_prtner_addr_id]
   , [teleph_num_type_code]
   , [teleph_num]
   , [teleph_ext_num]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_teleph_id, 
   , null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_efflu_trade_prtner_addr_id, 
   , null /* no mapping */ --teleph_num_type_code, TelephoneNumberTypeCode
   , null /* no mapping */ --teleph_num, TelephoneNumber
   , null /* no mapping */ --teleph_ext_num, TelephoneExtensionNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_UNPRMT_FAC/ICS_CONTACT
INSERT INTO ICS_FLOW_LOCAL.ics_contact (
     [ics_contact_id]
   , [ics_fac_id]
   , [ics_basic_prmt_id]
   , [ics_prmt_featr_id]
   , [ics_bs_mgmt_practices_id]
   , [ics_bs_annul_prog_rep_id]
   , [ics_bs_prmt_id]
   , [ics_cafo_prmt_id]
   , [ics_cmpl_mon_id]
   , [ics_gnrl_prmt_id]
   , [ics_master_gnrl_prmt_id]
   , [ics_pretr_prmt_id]
   , [ics_sw_cnst_prmt_id]
   , [ics_sw_evt_rep_id]
   , [ics_sw_indst_prmt_id]
   , [ics_swms_4_large_prmt_id]
   , [ics_swms_4_prog_rep_id]
   , [ics_swms_4_small_prmt_id]
   , [ics_unprmt_fac_id]
   , [affil_type_txt]
   , [first_name]
   , [middle_name]
   , [last_name]
   , [indvl_title_txt]
   , [org_frml_name]
   , [st_code]
   , [rgn_code]
   , [elec_addr_txt]
   , [start_date_of_contact_assc]
   , [end_date_of_contact_assc]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --ics_bs_mgmt_practices_id, 
   , null /* no mapping */ --ics_bs_annul_prog_rep_id, 
   , null /* no mapping */ --ics_bs_prmt_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_cmpl_mon_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_master_gnrl_prmt_id, 
   , null /* no mapping */ --ics_pretr_prmt_id, 
   , null /* no mapping */ --ics_sw_cnst_prmt_id, 
   , null /* no mapping */ --ics_sw_evt_rep_id, 
   , null /* no mapping */ --ics_sw_indst_prmt_id, 
   , null /* no mapping */ --ics_swms_4_large_prmt_id, 
   , null /* no mapping */ --ics_swms_4_prog_rep_id, 
   , null /* no mapping */ --ics_swms_4_small_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --affil_type_txt, AffiliationTypeText
   , null /* no mapping */ --first_name, FirstName
   , null /* no mapping */ --middle_name, MiddleName
   , null /* no mapping */ --last_name, LastName
   , null /* no mapping */ --indvl_title_txt, IndividualTitleText
   , null /* no mapping */ --org_frml_name, OrganizationFormalName
   , null /* no mapping */ --st_code, StateCode
   , null /* no mapping */ --rgn_code, RegionCode
   , null /* no mapping */ --elec_addr_txt, ElectronicAddressText
   , null /* no mapping */ --start_date_of_contact_assc, StartDateOfContactAssociation
   , null /* no mapping */ --end_date_of_contact_assc, EndDateOfContactAssociation
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_UNPRMT_FAC/ICS_CONTACT/ICS_TELEPH
INSERT INTO ICS_FLOW_LOCAL.ics_teleph (
     [ics_teleph_id]
   , [ics_contact_id]
   , [ics_addr_id]
   , [ics_efflu_trade_prtner_addr_id]
   , [teleph_num_type_code]
   , [teleph_num]
   , [teleph_ext_num]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_teleph_id, 
   , null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_efflu_trade_prtner_addr_id, 
   , null /* no mapping */ --teleph_num_type_code, TelephoneNumberTypeCode
   , null /* no mapping */ --teleph_num, TelephoneNumber
   , null /* no mapping */ --teleph_ext_num, TelephoneExtensionNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_UNPRMT_FAC/ICS_FAC_CLASS
INSERT INTO ICS_FLOW_LOCAL.ics_fac_class (
     [ics_fac_class_id]
   , [ics_fac_id]
   , [ics_unprmt_fac_id]
   , [fac_class]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_fac_class_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --fac_class, FacilityClassification
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_UNPRMT_FAC/ICS_GEO_COORD
INSERT INTO ICS_FLOW_LOCAL.ics_geo_coord (
     [ics_geo_coord_id]
   , [ics_fac_id]
   , [ics_prmt_featr_id]
   , [ics_unprmt_fac_id]
   , [lat_meas]
   , [long_meas]
   , [horz_accuracy_meas]
   , [geometric_type_code]
   , [horz_coll_method_code]
   , [horz_ref_datum_code]
   , [ref_point_code]
   , [src_map_scale_num]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_geo_coord_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --lat_meas, LatitudeMeasure
   , null /* no mapping */ --long_meas, LongitudeMeasure
   , null /* no mapping */ --horz_accuracy_meas, HorizontalAccuracyMeasure
   , null /* no mapping */ --geometric_type_code, GeometricTypeCode
   , null /* no mapping */ --horz_coll_method_code, HorizontalCollectionMethodCode
   , null /* no mapping */ --horz_ref_datum_code, HorizontalReferenceDatumCode
   , null /* no mapping */ --ref_point_code, ReferencePointCode
   , null /* no mapping */ --src_map_scale_num, SourceMapScaleNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_UNPRMT_FAC/ICS_NAICS_CODE
INSERT INTO ICS_FLOW_LOCAL.ics_naics_code (
     [ics_naics_code_id]
   , [ics_basic_prmt_id]
   , [ics_fac_id]
   , [ics_gnrl_prmt_id]
   , [ics_master_gnrl_prmt_id]
   , [ics_unprmt_fac_id]
   , [naics_code]
   , [naics_primary_ind_code]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_naics_code_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_master_gnrl_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --naics_code, NAICSCode
   , null /* no mapping */ --naics_primary_ind_code, NAICSPrimaryIndicatorCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_UNPRMT_FAC/ICS_ORIG_PROGS
INSERT INTO ICS_FLOW_LOCAL.ics_orig_progs (
     [ics_orig_progs_id]
   , [ics_fac_id]
   , [ics_unprmt_fac_id]
   , [orig_progs_code]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_orig_progs_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --orig_progs_code, OriginatingProgramsCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_UNPRMT_FAC/ICS_PLCY
INSERT INTO ICS_FLOW_LOCAL.ics_plcy (
     [ics_plcy_id]
   , [ics_fac_id]
   , [ics_unprmt_fac_id]
   , [plcy_code]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_plcy_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --plcy_code, PolicyCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_UNPRMT_FAC/ICS_PRMT_COMP_TYPE
INSERT INTO ICS_FLOW_LOCAL.ics_prmt_comp_type (
     [ics_prmt_comp_type_id]
   , [ics_master_gnrl_prmt_id]
   , [ics_unprmt_fac_id]
   , [prmt_comp_type_code]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_prmt_comp_type_id, 
   , null /* no mapping */ --ics_master_gnrl_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --prmt_comp_type_code, PermitComponentTypeCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_UNPRMT_FAC/ICS_SIC_CODE
INSERT INTO ICS_FLOW_LOCAL.ics_sic_code (
     [ics_sic_code_id]
   , [ics_basic_prmt_id]
   , [ics_fac_id]
   , [ics_gnrl_prmt_id]
   , [ics_master_gnrl_prmt_id]
   , [ics_unprmt_fac_id]
   , [sic_code]
   , [sic_primary_ind_code]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_sic_code_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_master_gnrl_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --sic_code, SICCode
   , null /* no mapping */ --sic_primary_ind_code, SICPrimaryIndicatorCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

