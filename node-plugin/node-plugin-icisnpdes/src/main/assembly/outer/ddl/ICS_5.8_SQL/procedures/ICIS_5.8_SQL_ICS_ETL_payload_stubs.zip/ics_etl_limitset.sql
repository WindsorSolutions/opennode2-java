﻿IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'ICS_FLOW_LOCAL.ics_etl_limitset') AND type in (N'P', N'PC'))
DROP PROCEDURE ICS_FLOW_LOCAL.ics_etl_limitset
GO


/*************************************************************************************************
** ObjectName: ics_etl_limitset
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the LimitSetSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE PROCEDURE ICS_FLOW_LOCAL.ics_etl_limitset

AS

---------------------------- 
-- ICS_LMT_SET
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_LMT_SET/ICS_LMT_SET_MONTHS_APPL
DELETE
  FROM ICS_FLOW_LOCAL.ics_lmt_set_months_appl
 WHERE ics_lmt_set_id IN
          (SELECT ics_lmt_set.ics_lmt_set_id
             FROM ICS_FLOW_LOCAL.ics_lmt_set
          );

-- /ICS_LMT_SET/ICS_LMT_SET_SCHD
DELETE
  FROM ICS_FLOW_LOCAL.ics_lmt_set_schd
 WHERE ics_lmt_set_id IN
          (SELECT ics_lmt_set.ics_lmt_set_id
             FROM ICS_FLOW_LOCAL.ics_lmt_set
          );

-- /ICS_LMT_SET/ICS_LMT_SET_STAT
DELETE
  FROM ICS_FLOW_LOCAL.ics_lmt_set_stat
 WHERE ics_lmt_set_id IN
          (SELECT ics_lmt_set.ics_lmt_set_id
             FROM ICS_FLOW_LOCAL.ics_lmt_set
          );

-- /ICS_LMT_SET
DELETE
  FROM ICS_FLOW_LOCAL.ics_lmt_set;


-- /ICS_LMT_SET
INSERT INTO ICS_FLOW_LOCAL.ics_lmt_set (
     [ics_lmt_set_id]
   , [ics_payload_id]
   , [src_systm_ident]
   , [transaction_type]
   , [transaction_timestamp]
   , [prmt_ident]
   , [prmt_featr_ident]
   , [lmt_set_designator]
   , [lmt_set_type]
   , [lmt_set_name_txt]
   , [dmr_pre_print_cmnts_txt]
   , [agncy_reviewer]
   , [lmt_set_usr_dfnd_dat_elm_1_txt]
   , [lmt_set_usr_dfnd_dat_elm_2_txt]
   , [key_hash]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_lmt_set_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --prmt_featr_ident, PermittedFeatureIdentifier
   , null /* no mapping */ --lmt_set_designator, LimitSetDesignator
   , null /* no mapping */ --lmt_set_type, LimitSetType
   , null /* no mapping */ --lmt_set_name_txt, LimitSetNameText
   , null /* no mapping */ --dmr_pre_print_cmnts_txt, DMRPrePrintCommentsText
   , null /* no mapping */ --agncy_reviewer, AgencyReviewer
   , null /* no mapping */ --lmt_set_usr_dfnd_dat_elm_1_txt, LimitSetUserDefinedDataElement1Text
   , null /* no mapping */ --lmt_set_usr_dfnd_dat_elm_2_txt, LimitSetUserDefinedDataElement2Text
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_LMT_SET/ICS_LMT_SET_MONTHS_APPL
INSERT INTO ICS_FLOW_LOCAL.ics_lmt_set_months_appl (
     [ics_lmt_set_months_appl_id]
   , [ics_lmt_set_id]
   , [lmt_set_months_appl]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_lmt_set_months_appl_id, 
   , null /* no mapping */ --ics_lmt_set_id, 
   , null /* no mapping */ --lmt_set_months_appl, LimitSetMonthsApplicable
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_LMT_SET/ICS_LMT_SET_SCHD
INSERT INTO ICS_FLOW_LOCAL.ics_lmt_set_schd (
     [ics_lmt_set_schd_id]
   , [ics_lmt_set_id]
   , [num_units_rep_period_integer]
   , [num_subm_units_integer]
   , [initial_mon_date]
   , [initial_dmr_due_date]
   , [lmt_set_mod_type_code]
   , [lmt_set_mod_effective_date]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_lmt_set_schd_id, 
   , null /* no mapping */ --ics_lmt_set_id, 
   , null /* no mapping */ --num_units_rep_period_integer, NumberUnitsReportPeriodInteger
   , null /* no mapping */ --num_subm_units_integer, NumberSubmissionUnitsInteger
   , null /* no mapping */ --initial_mon_date, InitialMonitoringDate
   , null /* no mapping */ --initial_dmr_due_date, InitialDMRDueDate
   , null /* no mapping */ --lmt_set_mod_type_code, LimitSetModificationTypeCode
   , null /* no mapping */ --lmt_set_mod_effective_date, LimitSetModificationEffectiveDate
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_LMT_SET/ICS_LMT_SET_STAT
INSERT INTO ICS_FLOW_LOCAL.ics_lmt_set_stat (
     [ics_lmt_set_stat_id]
   , [ics_lmt_set_id]
   , [lmt_set_stat_ind]
   , [lmt_set_stat_start_date]
   , [lmt_set_stat_reason_txt]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_lmt_set_stat_id, 
   , null /* no mapping */ --ics_lmt_set_id, 
   , null /* no mapping */ --lmt_set_stat_ind, LimitSetStatusIndicator
   , null /* no mapping */ --lmt_set_stat_start_date, LimitSetStatusStartDate
   , null /* no mapping */ --lmt_set_stat_reason_txt, LimitSetStatusReasonText
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

