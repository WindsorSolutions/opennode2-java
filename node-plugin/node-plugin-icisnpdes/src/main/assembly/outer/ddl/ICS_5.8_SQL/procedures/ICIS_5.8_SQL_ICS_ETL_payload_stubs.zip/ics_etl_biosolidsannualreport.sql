﻿IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'ICS_FLOW_LOCAL.ics_etl_biosolidsannualreport') AND type in (N'P', N'PC'))
DROP PROCEDURE ICS_FLOW_LOCAL.ics_etl_biosolidsannualreport
GO


/*************************************************************************************************
** ObjectName: ics_etl_biosolidsannualreport
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the BiosolidsAnnualReport module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE PROCEDURE ICS_FLOW_LOCAL.ics_etl_biosolidsannualreport

AS

---------------------------- 
-- ICS_BS_ANNUL_PROG_REP
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICES/ICS_ADDR/ICS_TELEPH
DELETE
  FROM ICS_FLOW_LOCAL.ics_teleph
 WHERE ics_addr_id IN
          (SELECT ics_addr.ics_addr_id
             FROM ICS_FLOW_LOCAL.ics_bs_annul_prog_rep
                  JOIN ICS_FLOW_LOCAL.ics_bs_mgmt_practices ON ics_bs_mgmt_practices.ics_bs_annul_prog_rep_id = ics_bs_annul_prog_rep.ics_bs_annul_prog_rep_id
                  JOIN ICS_FLOW_LOCAL.ics_addr ON ics_addr.ics_bs_mgmt_practices_id = ics_bs_mgmt_practices.ics_bs_mgmt_practices_id
          );

-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICES/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM ICS_FLOW_LOCAL.ics_teleph
 WHERE ics_contact_id IN
          (SELECT ics_contact.ics_contact_id
             FROM ICS_FLOW_LOCAL.ics_bs_annul_prog_rep
                  JOIN ICS_FLOW_LOCAL.ics_bs_mgmt_practices ON ics_bs_mgmt_practices.ics_bs_annul_prog_rep_id = ics_bs_annul_prog_rep.ics_bs_annul_prog_rep_id
                  JOIN ICS_FLOW_LOCAL.ics_contact ON ics_contact.ics_bs_mgmt_practices_id = ics_bs_mgmt_practices.ics_bs_mgmt_practices_id
          );

-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICES/ICS_ADDR
DELETE
  FROM ICS_FLOW_LOCAL.ics_addr
 WHERE ics_bs_mgmt_practices_id IN
          (SELECT ics_bs_mgmt_practices.ics_bs_mgmt_practices_id
             FROM ICS_FLOW_LOCAL.ics_bs_annul_prog_rep
                  JOIN ICS_FLOW_LOCAL.ics_bs_mgmt_practices ON ics_bs_mgmt_practices.ics_bs_annul_prog_rep_id = ics_bs_annul_prog_rep.ics_bs_annul_prog_rep_id
          );

-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICES/ICS_CONTACT
DELETE
  FROM ICS_FLOW_LOCAL.ics_contact
 WHERE ics_bs_mgmt_practices_id IN
          (SELECT ics_bs_mgmt_practices.ics_bs_mgmt_practices_id
             FROM ICS_FLOW_LOCAL.ics_bs_annul_prog_rep
                  JOIN ICS_FLOW_LOCAL.ics_bs_mgmt_practices ON ics_bs_mgmt_practices.ics_bs_annul_prog_rep_id = ics_bs_annul_prog_rep.ics_bs_annul_prog_rep_id
          );

-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICES/ICS_MGMT_PRC_DEFCY_TYPE
DELETE
  FROM ICS_FLOW_LOCAL.ics_mgmt_prc_defcy_type
 WHERE ics_bs_mgmt_practices_id IN
          (SELECT ics_bs_mgmt_practices.ics_bs_mgmt_practices_id
             FROM ICS_FLOW_LOCAL.ics_bs_annul_prog_rep
                  JOIN ICS_FLOW_LOCAL.ics_bs_mgmt_practices ON ics_bs_mgmt_practices.ics_bs_annul_prog_rep_id = ics_bs_annul_prog_rep.ics_bs_annul_prog_rep_id
          );

-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICES/ICS_PATHOGEN_REDUCTION_TYPE
DELETE
  FROM ICS_FLOW_LOCAL.ics_pathogen_reduction_type
 WHERE ics_bs_mgmt_practices_id IN
          (SELECT ics_bs_mgmt_practices.ics_bs_mgmt_practices_id
             FROM ICS_FLOW_LOCAL.ics_bs_annul_prog_rep
                  JOIN ICS_FLOW_LOCAL.ics_bs_mgmt_practices ON ics_bs_mgmt_practices.ics_bs_annul_prog_rep_id = ics_bs_annul_prog_rep.ics_bs_annul_prog_rep_id
          );

-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICES/ICS_VECTOR_A_REDUCTION_TYPE
DELETE
  FROM ICS_FLOW_LOCAL.ics_vector_a_reduction_type
 WHERE ics_bs_mgmt_practices_id IN
          (SELECT ics_bs_mgmt_practices.ics_bs_mgmt_practices_id
             FROM ICS_FLOW_LOCAL.ics_bs_annul_prog_rep
                  JOIN ICS_FLOW_LOCAL.ics_bs_mgmt_practices ON ics_bs_mgmt_practices.ics_bs_annul_prog_rep_id = ics_bs_annul_prog_rep.ics_bs_annul_prog_rep_id
          );

-- /ICS_BS_ANNUL_PROG_REP/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM ICS_FLOW_LOCAL.ics_teleph
 WHERE ics_contact_id IN
          (SELECT ics_contact.ics_contact_id
             FROM ICS_FLOW_LOCAL.ics_bs_annul_prog_rep
                  JOIN ICS_FLOW_LOCAL.ics_contact ON ics_contact.ics_bs_annul_prog_rep_id = ics_bs_annul_prog_rep.ics_bs_annul_prog_rep_id
          );

-- /ICS_BS_ANNUL_PROG_REP/ICS_ANLYTCL_METHOD
DELETE
  FROM ICS_FLOW_LOCAL.ics_anlytcl_method
 WHERE ics_bs_annul_prog_rep_id IN
          (SELECT ics_bs_annul_prog_rep.ics_bs_annul_prog_rep_id
             FROM ICS_FLOW_LOCAL.ics_bs_annul_prog_rep
          );

-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICES
DELETE
  FROM ICS_FLOW_LOCAL.ics_bs_mgmt_practices
 WHERE ics_bs_annul_prog_rep_id IN
          (SELECT ics_bs_annul_prog_rep.ics_bs_annul_prog_rep_id
             FROM ICS_FLOW_LOCAL.ics_bs_annul_prog_rep
          );

-- /ICS_BS_ANNUL_PROG_REP/ICS_CONTACT
DELETE
  FROM ICS_FLOW_LOCAL.ics_contact
 WHERE ics_bs_annul_prog_rep_id IN
          (SELECT ics_bs_annul_prog_rep.ics_bs_annul_prog_rep_id
             FROM ICS_FLOW_LOCAL.ics_bs_annul_prog_rep
          );

-- /ICS_BS_ANNUL_PROG_REP/ICS_REP_OBLGTN_TYPE
DELETE
  FROM ICS_FLOW_LOCAL.ics_rep_oblgtn_type
 WHERE ics_bs_annul_prog_rep_id IN
          (SELECT ics_bs_annul_prog_rep.ics_bs_annul_prog_rep_id
             FROM ICS_FLOW_LOCAL.ics_bs_annul_prog_rep
          );

-- /ICS_BS_ANNUL_PROG_REP/ICS_TRTMNT_PRCSS_TYPE
DELETE
  FROM ICS_FLOW_LOCAL.ics_trtmnt_prcss_type
 WHERE ics_bs_annul_prog_rep_id IN
          (SELECT ics_bs_annul_prog_rep.ics_bs_annul_prog_rep_id
             FROM ICS_FLOW_LOCAL.ics_bs_annul_prog_rep
          );

-- /ICS_BS_ANNUL_PROG_REP
DELETE
  FROM ICS_FLOW_LOCAL.ics_bs_annul_prog_rep;


-- /ICS_BS_ANNUL_PROG_REP
INSERT INTO ICS_FLOW_LOCAL.ics_bs_annul_prog_rep (
     [ics_bs_annul_prog_rep_id]
   , [ics_payload_id]
   , [src_systm_ident]
   , [transaction_type]
   , [transaction_timestamp]
   , [prmt_ident]
   , [bs_annul_rep_rcvd_date]
   , [elec_subm_type_code]
   , [rep_period_start_date]
   , [rep_period_end_date]
   , [trtmnt_prcss_othr_txt]
   , [ttl_vol_amt]
   , [bs_addl_info_cmnt_txt]
   , [key_hash]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_bs_annul_prog_rep_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --bs_annul_rep_rcvd_date, BiosolidsAnnualReportReceivedDate
   , null /* no mapping */ --elec_subm_type_code, ElectronicSubmissionTypeCode
   , null /* no mapping */ --rep_period_start_date, ReportingPeriodStartDate
   , null /* no mapping */ --rep_period_end_date, ReportingPeriodEndDate
   , null /* no mapping */ --trtmnt_prcss_othr_txt, TreatmentProcessOtherText
   , null /* no mapping */ --ttl_vol_amt, TotalVolumeAmount
   , null /* no mapping */ --bs_addl_info_cmnt_txt, BiosolidsAdditionalInformationCommentText
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BS_ANNUL_PROG_REP/ICS_ANLYTCL_METHOD
INSERT INTO ICS_FLOW_LOCAL.ics_anlytcl_method (
     [ics_anlytcl_method_id]
   , [ics_bs_annul_prog_rep_id]
   , [anlytcl_method_type_code]
   , [anlytcl_method_othr_type_txt]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_anlytcl_method_id, 
   , null /* no mapping */ --ics_bs_annul_prog_rep_id, 
   , null /* no mapping */ --anlytcl_method_type_code, AnalyticalMethodTypeCode
   , null /* no mapping */ --anlytcl_method_othr_type_txt, AnalyticalMethodOtherTypeText
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICES
INSERT INTO ICS_FLOW_LOCAL.ics_bs_mgmt_practices (
     [ics_bs_mgmt_practices_id]
   , [ics_bs_annul_prog_rep_id]
   , [ssu_ident]
   , [bs_mgmt_prc_type_code]
   , [hndlr_prepr_type_code]
   , [land_appl_sub_catg_code]
   , [othr_sub_catg_code]
   , [sub_catg_othr_txt]
   , [bs_cntnr_type_code]
   , [vol_amt]
   , [pathogen_class_type_code]
   , [polut_concen_exceedance_ind]
   , [polut_loading_r_exceedance_ind]
   , [active_dspl_site_ind]
   , [site_spec_lmt_ind]
   , [min_bndry_dist_ind]
   , [min_bndry_dist_type_code]
   , [assc_prmt_ident]
   , [mgmt_prc_cmnt_txt]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_bs_mgmt_practices_id, 
   , null /* no mapping */ --ics_bs_annul_prog_rep_id, 
   , null /* no mapping */ --ssu_ident, SSUIdentifier
   , null /* no mapping */ --bs_mgmt_prc_type_code, BiosolidsManagementPracticeTypeCode
   , null /* no mapping */ --hndlr_prepr_type_code, HandlerPreparerTypeCode
   , null /* no mapping */ --land_appl_sub_catg_code, LandApplicationSubCategoryCode
   , null /* no mapping */ --othr_sub_catg_code, OtherSubCategoryCode
   , null /* no mapping */ --sub_catg_othr_txt, SubCategoryOtherText
   , null /* no mapping */ --bs_cntnr_type_code, BiosolidsContainerTypeCode
   , null /* no mapping */ --vol_amt, VolumeAmount
   , null /* no mapping */ --pathogen_class_type_code, PathogenClassTypeCode
   , null /* no mapping */ --polut_concen_exceedance_ind, PollutantConcentrationExceedanceIndicator
   , null /* no mapping */ --polut_loading_r_exceedance_ind, PollutantLoadingRatesExceedanceIndicator
   , null /* no mapping */ --active_dspl_site_ind, ActiveDisposalSiteIndicator
   , null /* no mapping */ --site_spec_lmt_ind, SiteSpecificLimitIndicator
   , null /* no mapping */ --min_bndry_dist_ind, MinimumBoundaryDistanceIndicator
   , null /* no mapping */ --min_bndry_dist_type_code, MinimumBoundaryDistanceTypeCode
   , null /* no mapping */ --assc_prmt_ident, AssociatedPermitIdentifier
   , null /* no mapping */ --mgmt_prc_cmnt_txt, ManagementPracticeCommentText
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICES/ICS_ADDR
INSERT INTO ICS_FLOW_LOCAL.ics_addr (
     [ics_addr_id]
   , [ics_fac_id]
   , [ics_basic_prmt_id]
   , [ics_prmt_featr_id]
   , [ics_bs_mgmt_practices_id]
   , [ics_bs_prmt_id]
   , [ics_cafo_prmt_id]
   , [ics_gnrl_prmt_id]
   , [ics_sw_cnst_prmt_id]
   , [ics_sw_evt_rep_id]
   , [ics_sw_indst_prmt_id]
   , [ics_swms_4_large_prmt_id]
   , [ics_swms_4_prog_rep_id]
   , [ics_swms_4_small_prmt_id]
   , [ics_unprmt_fac_id]
   , [affil_type_txt]
   , [org_frml_name]
   , [org_duns_num]
   , [mailing_addr_txt]
   , [suppl_addr_txt]
   , [mailing_addr_city_name]
   , [mailing_addr_st_code]
   , [mailing_addr_zip_code]
   , [county_name]
   , [mailing_addr_country_code]
   , [division_name]
   , [loc_province]
   , [elec_addr_txt]
   , [start_date_of_addr_assc]
   , [end_date_of_addr_assc]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --ics_bs_mgmt_practices_id, 
   , null /* no mapping */ --ics_bs_prmt_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_sw_cnst_prmt_id, 
   , null /* no mapping */ --ics_sw_evt_rep_id, 
   , null /* no mapping */ --ics_sw_indst_prmt_id, 
   , null /* no mapping */ --ics_swms_4_large_prmt_id, 
   , null /* no mapping */ --ics_swms_4_prog_rep_id, 
   , null /* no mapping */ --ics_swms_4_small_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --affil_type_txt, AffiliationTypeText
   , null /* no mapping */ --org_frml_name, OrganizationFormalName
   , null /* no mapping */ --org_duns_num, OrganizationDUNSNumber
   , null /* no mapping */ --mailing_addr_txt, MailingAddressText
   , null /* no mapping */ --suppl_addr_txt, SupplementalAddressText
   , null /* no mapping */ --mailing_addr_city_name, MailingAddressCityName
   , null /* no mapping */ --mailing_addr_st_code, MailingAddressStateCode
   , null /* no mapping */ --mailing_addr_zip_code, MailingAddressZipCode
   , null /* no mapping */ --county_name, CountyName
   , null /* no mapping */ --mailing_addr_country_code, MailingAddressCountryCode
   , null /* no mapping */ --division_name, DivisionName
   , null /* no mapping */ --loc_province, LocationProvince
   , null /* no mapping */ --elec_addr_txt, ElectronicAddressText
   , null /* no mapping */ --start_date_of_addr_assc, StartDateOfAddressAssociation
   , null /* no mapping */ --end_date_of_addr_assc, EndDateOfAddressAssociation
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICES/ICS_ADDR/ICS_TELEPH
INSERT INTO ICS_FLOW_LOCAL.ics_teleph (
     [ics_teleph_id]
   , [ics_contact_id]
   , [ics_addr_id]
   , [ics_efflu_trade_prtner_addr_id]
   , [teleph_num_type_code]
   , [teleph_num]
   , [teleph_ext_num]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_teleph_id, 
   , null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_efflu_trade_prtner_addr_id, 
   , null /* no mapping */ --teleph_num_type_code, TelephoneNumberTypeCode
   , null /* no mapping */ --teleph_num, TelephoneNumber
   , null /* no mapping */ --teleph_ext_num, TelephoneExtensionNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICES/ICS_CONTACT
INSERT INTO ICS_FLOW_LOCAL.ics_contact (
     [ics_contact_id]
   , [ics_fac_id]
   , [ics_basic_prmt_id]
   , [ics_prmt_featr_id]
   , [ics_bs_mgmt_practices_id]
   , [ics_bs_annul_prog_rep_id]
   , [ics_bs_prmt_id]
   , [ics_cafo_prmt_id]
   , [ics_cmpl_mon_id]
   , [ics_gnrl_prmt_id]
   , [ics_master_gnrl_prmt_id]
   , [ics_pretr_prmt_id]
   , [ics_sw_cnst_prmt_id]
   , [ics_sw_evt_rep_id]
   , [ics_sw_indst_prmt_id]
   , [ics_swms_4_large_prmt_id]
   , [ics_swms_4_prog_rep_id]
   , [ics_swms_4_small_prmt_id]
   , [ics_unprmt_fac_id]
   , [affil_type_txt]
   , [first_name]
   , [middle_name]
   , [last_name]
   , [indvl_title_txt]
   , [org_frml_name]
   , [st_code]
   , [rgn_code]
   , [elec_addr_txt]
   , [start_date_of_contact_assc]
   , [end_date_of_contact_assc]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --ics_bs_mgmt_practices_id, 
   , null /* no mapping */ --ics_bs_annul_prog_rep_id, 
   , null /* no mapping */ --ics_bs_prmt_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_cmpl_mon_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_master_gnrl_prmt_id, 
   , null /* no mapping */ --ics_pretr_prmt_id, 
   , null /* no mapping */ --ics_sw_cnst_prmt_id, 
   , null /* no mapping */ --ics_sw_evt_rep_id, 
   , null /* no mapping */ --ics_sw_indst_prmt_id, 
   , null /* no mapping */ --ics_swms_4_large_prmt_id, 
   , null /* no mapping */ --ics_swms_4_prog_rep_id, 
   , null /* no mapping */ --ics_swms_4_small_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --affil_type_txt, AffiliationTypeText
   , null /* no mapping */ --first_name, FirstName
   , null /* no mapping */ --middle_name, MiddleName
   , null /* no mapping */ --last_name, LastName
   , null /* no mapping */ --indvl_title_txt, IndividualTitleText
   , null /* no mapping */ --org_frml_name, OrganizationFormalName
   , null /* no mapping */ --st_code, StateCode
   , null /* no mapping */ --rgn_code, RegionCode
   , null /* no mapping */ --elec_addr_txt, ElectronicAddressText
   , null /* no mapping */ --start_date_of_contact_assc, StartDateOfContactAssociation
   , null /* no mapping */ --end_date_of_contact_assc, EndDateOfContactAssociation
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICES/ICS_CONTACT/ICS_TELEPH
INSERT INTO ICS_FLOW_LOCAL.ics_teleph (
     [ics_teleph_id]
   , [ics_contact_id]
   , [ics_addr_id]
   , [ics_efflu_trade_prtner_addr_id]
   , [teleph_num_type_code]
   , [teleph_num]
   , [teleph_ext_num]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_teleph_id, 
   , null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_efflu_trade_prtner_addr_id, 
   , null /* no mapping */ --teleph_num_type_code, TelephoneNumberTypeCode
   , null /* no mapping */ --teleph_num, TelephoneNumber
   , null /* no mapping */ --teleph_ext_num, TelephoneExtensionNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICES/ICS_MGMT_PRC_DEFCY_TYPE
INSERT INTO ICS_FLOW_LOCAL.ics_mgmt_prc_defcy_type (
     [ics_mgmt_prc_defcy_type_id]
   , [ics_bs_mgmt_practices_id]
   , [mgmt_prc_defcy_type_code]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_mgmt_prc_defcy_type_id, 
   , null /* no mapping */ --ics_bs_mgmt_practices_id, 
   , null /* no mapping */ --mgmt_prc_defcy_type_code, ManagementPracticeDeficiencyTypeCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICES/ICS_PATHOGEN_REDUCTION_TYPE
INSERT INTO ICS_FLOW_LOCAL.ics_pathogen_reduction_type (
     [ics_pathogen_reduction_type_id]
   , [ics_bs_mgmt_practices_id]
   , [pathogen_reduction_type_code]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_pathogen_reduction_type_id, 
   , null /* no mapping */ --ics_bs_mgmt_practices_id, 
   , null /* no mapping */ --pathogen_reduction_type_code, PathogenReductionTypeCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICES/ICS_VECTOR_A_REDUCTION_TYPE
INSERT INTO ICS_FLOW_LOCAL.ics_vector_a_reduction_type (
     [ics_vector_a_reduction_type_id]
   , [ics_bs_mgmt_practices_id]
   , [vector_a_reduction_type_code]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_vector_a_reduction_type_id, 
   , null /* no mapping */ --ics_bs_mgmt_practices_id, 
   , null /* no mapping */ --vector_a_reduction_type_code, VectorAttractionReductionTypeCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BS_ANNUL_PROG_REP/ICS_CONTACT
INSERT INTO ICS_FLOW_LOCAL.ics_contact (
     [ics_contact_id]
   , [ics_fac_id]
   , [ics_basic_prmt_id]
   , [ics_prmt_featr_id]
   , [ics_bs_mgmt_practices_id]
   , [ics_bs_annul_prog_rep_id]
   , [ics_bs_prmt_id]
   , [ics_cafo_prmt_id]
   , [ics_cmpl_mon_id]
   , [ics_gnrl_prmt_id]
   , [ics_master_gnrl_prmt_id]
   , [ics_pretr_prmt_id]
   , [ics_sw_cnst_prmt_id]
   , [ics_sw_evt_rep_id]
   , [ics_sw_indst_prmt_id]
   , [ics_swms_4_large_prmt_id]
   , [ics_swms_4_prog_rep_id]
   , [ics_swms_4_small_prmt_id]
   , [ics_unprmt_fac_id]
   , [affil_type_txt]
   , [first_name]
   , [middle_name]
   , [last_name]
   , [indvl_title_txt]
   , [org_frml_name]
   , [st_code]
   , [rgn_code]
   , [elec_addr_txt]
   , [start_date_of_contact_assc]
   , [end_date_of_contact_assc]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_fac_id, 
   , null /* no mapping */ --ics_basic_prmt_id, 
   , null /* no mapping */ --ics_prmt_featr_id, 
   , null /* no mapping */ --ics_bs_mgmt_practices_id, 
   , null /* no mapping */ --ics_bs_annul_prog_rep_id, 
   , null /* no mapping */ --ics_bs_prmt_id, 
   , null /* no mapping */ --ics_cafo_prmt_id, 
   , null /* no mapping */ --ics_cmpl_mon_id, 
   , null /* no mapping */ --ics_gnrl_prmt_id, 
   , null /* no mapping */ --ics_master_gnrl_prmt_id, 
   , null /* no mapping */ --ics_pretr_prmt_id, 
   , null /* no mapping */ --ics_sw_cnst_prmt_id, 
   , null /* no mapping */ --ics_sw_evt_rep_id, 
   , null /* no mapping */ --ics_sw_indst_prmt_id, 
   , null /* no mapping */ --ics_swms_4_large_prmt_id, 
   , null /* no mapping */ --ics_swms_4_prog_rep_id, 
   , null /* no mapping */ --ics_swms_4_small_prmt_id, 
   , null /* no mapping */ --ics_unprmt_fac_id, 
   , null /* no mapping */ --affil_type_txt, AffiliationTypeText
   , null /* no mapping */ --first_name, FirstName
   , null /* no mapping */ --middle_name, MiddleName
   , null /* no mapping */ --last_name, LastName
   , null /* no mapping */ --indvl_title_txt, IndividualTitleText
   , null /* no mapping */ --org_frml_name, OrganizationFormalName
   , null /* no mapping */ --st_code, StateCode
   , null /* no mapping */ --rgn_code, RegionCode
   , null /* no mapping */ --elec_addr_txt, ElectronicAddressText
   , null /* no mapping */ --start_date_of_contact_assc, StartDateOfContactAssociation
   , null /* no mapping */ --end_date_of_contact_assc, EndDateOfContactAssociation
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BS_ANNUL_PROG_REP/ICS_CONTACT/ICS_TELEPH
INSERT INTO ICS_FLOW_LOCAL.ics_teleph (
     [ics_teleph_id]
   , [ics_contact_id]
   , [ics_addr_id]
   , [ics_efflu_trade_prtner_addr_id]
   , [teleph_num_type_code]
   , [teleph_num]
   , [teleph_ext_num]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_teleph_id, 
   , null /* no mapping */ --ics_contact_id, 
   , null /* no mapping */ --ics_addr_id, 
   , null /* no mapping */ --ics_efflu_trade_prtner_addr_id, 
   , null /* no mapping */ --teleph_num_type_code, TelephoneNumberTypeCode
   , null /* no mapping */ --teleph_num, TelephoneNumber
   , null /* no mapping */ --teleph_ext_num, TelephoneExtensionNumber
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BS_ANNUL_PROG_REP/ICS_REP_OBLGTN_TYPE
INSERT INTO ICS_FLOW_LOCAL.ics_rep_oblgtn_type (
     [ics_rep_oblgtn_type_id]
   , [ics_bs_annul_prog_rep_id]
   , [rep_oblgtn_type_code]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_rep_oblgtn_type_id, 
   , null /* no mapping */ --ics_bs_annul_prog_rep_id, 
   , null /* no mapping */ --rep_oblgtn_type_code, ReportingObligationTypeCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BS_ANNUL_PROG_REP/ICS_TRTMNT_PRCSS_TYPE
INSERT INTO ICS_FLOW_LOCAL.ics_trtmnt_prcss_type (
     [ics_trtmnt_prcss_type_id]
   , [ics_bs_annul_prog_rep_id]
   , [trtmnt_prcss_type_code]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_trtmnt_prcss_type_id, 
   , null /* no mapping */ --ics_bs_annul_prog_rep_id, 
   , null /* no mapping */ --trtmnt_prcss_type_code, TreatmentProcessTypeCode
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

