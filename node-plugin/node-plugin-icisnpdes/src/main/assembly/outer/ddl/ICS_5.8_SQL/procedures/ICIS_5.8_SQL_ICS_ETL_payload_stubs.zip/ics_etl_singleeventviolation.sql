﻿IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'ICS_FLOW_LOCAL.ics_etl_singleeventviolation') AND type in (N'P', N'PC'))
DROP PROCEDURE ICS_FLOW_LOCAL.ics_etl_singleeventviolation
GO


/*************************************************************************************************
** ObjectName: ics_etl_singleeventviolation
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the SingleEventViolationSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE PROCEDURE ICS_FLOW_LOCAL.ics_etl_singleeventviolation

AS

---------------------------- 
-- ICS_SNGL_EVT_VIOL
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_SNGL_EVT_VIOL
DELETE
  FROM ICS_FLOW_LOCAL.ics_sngl_evt_viol;


-- /ICS_SNGL_EVT_VIOL
INSERT INTO ICS_FLOW_LOCAL.ics_sngl_evt_viol (
     [ics_sngl_evt_viol_id]
   , [ics_payload_id]
   , [src_systm_ident]
   , [transaction_type]
   , [transaction_timestamp]
   , [prmt_ident]
   , [sngl_evt_viol_code]
   , [sngl_evt_viol_date]
   , [sngl_evt_viol_end_date]
   , [rep_non_cmpl_detect_code]
   , [rep_non_cmpl_detect_date]
   , [rep_non_cmpl_resl_code]
   , [rep_non_cmpl_resl_date]
   , [sngl_evt_usr_dfnd_fld_1]
   , [sngl_evt_usr_dfnd_fld_2]
   , [sngl_evt_usr_dfnd_fld_3]
   , [sngl_evt_usr_dfnd_fld_4]
   , [sngl_evt_usr_dfnd_fld_5]
   , [sngl_evt_cmnt_txt]
   , [key_hash]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_sngl_evt_viol_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --sngl_evt_viol_code, SingleEventViolationCode
   , null /* no mapping */ --sngl_evt_viol_date, SingleEventViolationDate
   , null /* no mapping */ --sngl_evt_viol_end_date, SingleEventViolationEndDate
   , null /* no mapping */ --rep_non_cmpl_detect_code, ReportableNonComplianceDetectionCode
   , null /* no mapping */ --rep_non_cmpl_detect_date, ReportableNonComplianceDetectionDate
   , null /* no mapping */ --rep_non_cmpl_resl_code, ReportableNonComplianceResolutionCode
   , null /* no mapping */ --rep_non_cmpl_resl_date, ReportableNonComplianceResolutionDate
   , null /* no mapping */ --sngl_evt_usr_dfnd_fld_1, SingleEventUserDefinedField1
   , null /* no mapping */ --sngl_evt_usr_dfnd_fld_2, SingleEventUserDefinedField2
   , null /* no mapping */ --sngl_evt_usr_dfnd_fld_3, SingleEventUserDefinedField3
   , null /* no mapping */ --sngl_evt_usr_dfnd_fld_4, SingleEventUserDefinedField4
   , null /* no mapping */ --sngl_evt_usr_dfnd_fld_5, SingleEventUserDefinedField5
   , null /* no mapping */ --sngl_evt_cmnt_txt, SingleEventCommentText
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

