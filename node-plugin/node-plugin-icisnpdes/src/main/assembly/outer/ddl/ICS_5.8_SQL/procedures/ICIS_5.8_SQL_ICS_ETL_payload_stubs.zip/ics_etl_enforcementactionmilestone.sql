﻿IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'ICS_FLOW_LOCAL.ics_etl_enforcementactionmilestone') AND type in (N'P', N'PC'))
DROP PROCEDURE ICS_FLOW_LOCAL.ics_etl_enforcementactionmilestone
GO


/*************************************************************************************************
** ObjectName: ics_etl_enforcementactionmilestone
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the EnforcementActionMilestoneSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE PROCEDURE ICS_FLOW_LOCAL.ics_etl_enforcementactionmilestone

AS

---------------------------- 
-- ICS_ENFRC_ACTN_MILESTONE
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_ENFRC_ACTN_MILESTONE
DELETE
  FROM ICS_FLOW_LOCAL.ics_enfrc_actn_milestone;


-- /ICS_ENFRC_ACTN_MILESTONE
INSERT INTO ICS_FLOW_LOCAL.ics_enfrc_actn_milestone (
     [ics_enfrc_actn_milestone_id]
   , [ics_payload_id]
   , [src_systm_ident]
   , [transaction_type]
   , [transaction_timestamp]
   , [enfrc_actn_ident]
   , [milestone_type_code]
   , [milestone_planned_date]
   , [milestone_actul_date]
   , [key_hash]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_enfrc_actn_milestone_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --enfrc_actn_ident, EnforcementActionIdentifier
   , null /* no mapping */ --milestone_type_code, MilestoneTypeCode
   , null /* no mapping */ --milestone_planned_date, MilestonePlannedDate
   , null /* no mapping */ --milestone_actul_date, MilestoneActualDate
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

