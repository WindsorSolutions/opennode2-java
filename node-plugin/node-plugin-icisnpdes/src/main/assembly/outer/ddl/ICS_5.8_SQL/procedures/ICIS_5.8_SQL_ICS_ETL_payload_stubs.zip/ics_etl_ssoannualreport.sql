﻿IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'ICS_FLOW_LOCAL.ics_etl_ssoannualreport') AND type in (N'P', N'PC'))
DROP PROCEDURE ICS_FLOW_LOCAL.ics_etl_ssoannualreport
GO


/*************************************************************************************************
** ObjectName: ics_etl_ssoannualreport
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the SSOAnnualReportSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE PROCEDURE ICS_FLOW_LOCAL.ics_etl_ssoannualreport

AS

---------------------------- 
-- ICS_SSO_ANNUL_REP
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_SSO_ANNUL_REP
DELETE
  FROM ICS_FLOW_LOCAL.ics_sso_annul_rep;


-- /ICS_SSO_ANNUL_REP
INSERT INTO ICS_FLOW_LOCAL.ics_sso_annul_rep (
     [ics_sso_annul_rep_id]
   , [ics_payload_id]
   , [src_systm_ident]
   , [transaction_type]
   , [transaction_timestamp]
   , [prmt_ident]
   , [sso_annul_rep_rcvd_date]
   , [sso_annul_rep_year]
   , [num_sso_evts_per_year]
   , [vol_sso_evts_per_year]
   , [key_hash]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_sso_annul_rep_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --sso_annul_rep_rcvd_date, SSOAnnualReportReceivedDate
   , null /* no mapping */ --sso_annul_rep_year, SSOAnnualReportYear
   , null /* no mapping */ --num_sso_evts_per_year, NumberSSOEventsPerYear
   , null /* no mapping */ --vol_sso_evts_per_year, VolumeSSOEventsPerYear
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

