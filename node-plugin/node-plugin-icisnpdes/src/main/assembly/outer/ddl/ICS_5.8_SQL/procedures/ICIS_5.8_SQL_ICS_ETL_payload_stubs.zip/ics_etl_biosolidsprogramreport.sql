﻿IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'ICS_FLOW_LOCAL.ics_etl_biosolidsprogramreport') AND type in (N'P', N'PC'))
DROP PROCEDURE ICS_FLOW_LOCAL.ics_etl_biosolidsprogramreport
GO


/*************************************************************************************************
** ObjectName: ics_etl_biosolidsprogramreport
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the BiosolidsProgramReportSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/13/2017   Windsor      Created 
**
***************************************************************************************************/
CREATE PROCEDURE ICS_FLOW_LOCAL.ics_etl_biosolidsprogramreport

AS

---------------------------- 
-- ICS_BS_PROG_REP
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_BS_PROG_REP
DELETE
  FROM ICS_FLOW_LOCAL.ics_bs_prog_rep;


-- /ICS_BS_PROG_REP
INSERT INTO ICS_FLOW_LOCAL.ics_bs_prog_rep (
     [ics_bs_prog_rep_id]
   , [ics_payload_id]
   , [src_systm_ident]
   , [transaction_type]
   , [transaction_timestamp]
   , [prmt_ident]
   , [rep_coverage_end_date]
   , [num_of_rep_units]
   , [eq_prod_dist_marketed_amt]
   , [land_applied_amt]
   , [incinerated_amt]
   , [codisposed_in_msw_landfill_amt]
   , [surf_dspl_amt]
   , [mnged_othr_mthds_amt]
   , [rcvd_offsite_srcs_amt]
   , [transferred_amt]
   , [disposed_out_of_st_amt]
   , [benef_used_out_of_st_amt]
   , [mnged_othr_mthds_out_of_st_amt]
   , [ttl_removed_amt]
   , [annul_dry_sldg_prod_num]
   , [annul_loading_param_date]
   , [annul_loading_bs_gal]
   , [annul_loading_bs_dmt]
   , [annul_loading_nutr_nitrogen]
   , [annul_loading_nutr_phosph]
   , [ttl_num_land_appl_viol]
   , [ttl_num_incin_viol]
   , [ttl_num_dist_marketing_viol]
   , [ttl_num_sldg_rlt_mgmt_prc_viol]
   , [ttl_num_surf_dspl_viol]
   , [ttl_num_othr_sldg_viol]
   , [ttl_num_codisposal_viol]
   , [bs_rep_cmnts]
   , [key_hash]
   , [data_hash])
SELECT 
     null /* no mapping */ --ics_bs_prog_rep_id, 
   , null /* no mapping */ --ics_payload_id, 
   , null /* no mapping */ --src_systm_ident, SourceSystemIdentifier
   , null /* no mapping */ --transaction_type, TransactionType
   , null /* no mapping */ --transaction_timestamp, TransactionTimestamp
   , null /* no mapping */ --prmt_ident, PermitIdentifier
   , null /* no mapping */ --rep_coverage_end_date, ReportCoverageEndDate
   , null /* no mapping */ --num_of_rep_units, NumberOfReportUnits
   , null /* no mapping */ --eq_prod_dist_marketed_amt, EQProductDistributedMarketedAmount
   , null /* no mapping */ --land_applied_amt, LandAppliedAmount
   , null /* no mapping */ --incinerated_amt, IncineratedAmount
   , null /* no mapping */ --codisposed_in_msw_landfill_amt, CodisposedInMSWLandfillAmount
   , null /* no mapping */ --surf_dspl_amt, SurfaceDisposalAmount
   , null /* no mapping */ --mnged_othr_mthds_amt, ManagedOtherMethodsAmount
   , null /* no mapping */ --rcvd_offsite_srcs_amt, ReceivedOffsiteSourcesAmount
   , null /* no mapping */ --transferred_amt, TransferredAmount
   , null /* no mapping */ --disposed_out_of_st_amt, DisposedOutOfStateAmount
   , null /* no mapping */ --benef_used_out_of_st_amt, BeneficiallyUsedOutOfStateAmount
   , null /* no mapping */ --mnged_othr_mthds_out_of_st_amt, ManagedOtherMethodsOutOfStateAmount
   , null /* no mapping */ --ttl_removed_amt, TotalRemovedAmount
   , null /* no mapping */ --annul_dry_sldg_prod_num, AnnualDrySludgeProductionNumber
   , null /* no mapping */ --annul_loading_param_date, AnnualLoadingParameterDate
   , null /* no mapping */ --annul_loading_bs_gal, AnnualLoadingBiosolidGallons
   , null /* no mapping */ --annul_loading_bs_dmt, AnnualLoadingBiosolidDMT
   , null /* no mapping */ --annul_loading_nutr_nitrogen, AnnualLoadingNutrientNitrogen
   , null /* no mapping */ --annul_loading_nutr_phosph, AnnualLoadingNutrientPhosphorous
   , null /* no mapping */ --ttl_num_land_appl_viol, TotalNumberLandApplicationViolations
   , null /* no mapping */ --ttl_num_incin_viol, TotalNumberIncineratorViolations
   , null /* no mapping */ --ttl_num_dist_marketing_viol, TotalNumberDistributionMarketingViolations
   , null /* no mapping */ --ttl_num_sldg_rlt_mgmt_prc_viol, TotalNumberSludgeRelatedManagementPracticeViolations
   , null /* no mapping */ --ttl_num_surf_dspl_viol, TotalNumberSurfaceDisposalViolations
   , null /* no mapping */ --ttl_num_othr_sldg_viol, TotalNumberOtherSludgeViolations
   , null /* no mapping */ --ttl_num_codisposal_viol, TotalNumberCodisposalViolations
   , null /* no mapping */ --bs_rep_cmnts, BiosolidsReportComments
   , null /* no mapping */ --key_hash, 
   , null /* no mapping */ --data_hash, 
WHERE 1 = 0; --mapping row not found!

